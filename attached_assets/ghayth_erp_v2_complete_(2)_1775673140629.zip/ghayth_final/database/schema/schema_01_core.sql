-- ══════════════════════════════════════════════════════════════
-- ghayth_erp — schema_01_core.sql
-- المرحلة 1: البنية الأساسية
-- ══════════════════════════════════════════════════════════════

SET NAMES utf8mb4;
SET foreign_key_checks = 0;

-- ─────────────────────────────────────────────
-- الشركات والفروع والأقسام
-- ─────────────────────────────────────────────

CREATE TABLE IF NOT EXISTS companies (
  id            INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  name          VARCHAR(200) NOT NULL,
  nameEn        VARCHAR(200),
  crNumber      VARCHAR(50),
  vatNumber     VARCHAR(50),
  domain        VARCHAR(100),
  pbxPrefix     VARCHAR(20),
  logoUrl       VARCHAR(500),
  address       TEXT,
  phone         VARCHAR(30),
  email         VARCHAR(200),
  status        ENUM('active','suspended','inactive') DEFAULT 'active',
  createdAt     DATETIME NOT NULL DEFAULT NOW(),
  INDEX idx_status (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS branches (
  id            INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  companyId     INT UNSIGNED NOT NULL,
  name          VARCHAR(200) NOT NULL,
  address       TEXT,
  lat           DECIMAL(10,7),
  lon           DECIMAL(10,7),
  phone         VARCHAR(30),
  status        ENUM('active','inactive') DEFAULT 'active',
  createdAt     DATETIME NOT NULL DEFAULT NOW(),
  FOREIGN KEY (companyId) REFERENCES companies(id),
  INDEX idx_company (companyId)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS departments (
  id            INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  companyId     INT UNSIGNED NOT NULL,
  branchId      INT UNSIGNED,
  name          VARCHAR(200) NOT NULL,
  slug          VARCHAR(100),
  parentId      INT UNSIGNED,
  managerId     INT UNSIGNED,
  status        ENUM('active','inactive') DEFAULT 'active',
  createdAt     DATETIME NOT NULL DEFAULT NOW(),
  FOREIGN KEY (companyId) REFERENCES companies(id),
  INDEX idx_company_branch (companyId, branchId)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ─────────────────────────────────────────────
-- الإعدادات (3 مستويات: نظام → شركة → فرع)
-- ─────────────────────────────────────────────

CREATE TABLE IF NOT EXISTS system_settings (
  id            INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  companyId     INT UNSIGNED,
  branchId      INT UNSIGNED,
  `key`         VARCHAR(200) NOT NULL,
  `value`       TEXT,
  dataType      ENUM('string','number','boolean','json') DEFAULT 'string',
  updatedAt     DATETIME NOT NULL DEFAULT NOW() ON UPDATE NOW(),
  UNIQUE KEY uk_setting (companyId, branchId, `key`),
  INDEX idx_key (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ─────────────────────────────────────────────
-- الموظفون والتعيينات
-- ─────────────────────────────────────────────

CREATE TABLE IF NOT EXISTS employees (
  id              INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  nationalId      VARCHAR(20) UNIQUE,
  name            VARCHAR(200) NOT NULL,
  nameEn          VARCHAR(200),
  phone           VARCHAR(30) UNIQUE,
  email           VARCHAR(200),
  gender          ENUM('male','female'),
  nationality     VARCHAR(50),
  dateOfBirth     DATE,
  photoUrl        VARCHAR(500),
  lat             DECIMAL(10,7),
  lon             DECIMAL(10,7),
  status          ENUM('active','inactive','terminated') DEFAULT 'active',
  activationToken VARCHAR(100),
  createdAt       DATETIME NOT NULL DEFAULT NOW(),
  INDEX idx_phone (phone),
  INDEX idx_email (email)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS employee_assignments (
  id              INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  employeeId      INT UNSIGNED NOT NULL,
  companyId       INT UNSIGNED NOT NULL,
  branchId        INT UNSIGNED NOT NULL,
  departmentId    INT UNSIGNED,
  jobTitle        VARCHAR(200) NOT NULL,
  role            ENUM('owner','system_admin','branch_manager','hr','finance_manager',
                       'department_manager','employee','sales','support','property_manager',
                       'fleet_manager','warehouse_manager','legal_manager','gm','pm') DEFAULT 'employee',
  salary          DECIMAL(12,2) DEFAULT 0,
  isPrimary       TINYINT(1) DEFAULT 0,
  hireDate        DATE,
  probationEndDate DATE,
  endDate         DATE,
  endReason       TEXT,
  sipExtension    VARCHAR(10),
  workEmail       VARCHAR(200),
  resolvedTickets INT DEFAULT 0,
  slaScore        DECIMAL(5,2) DEFAULT 100,
  status          ENUM('active','inactive','terminated') DEFAULT 'active',
  createdAt       DATETIME NOT NULL DEFAULT NOW(),
  FOREIGN KEY (employeeId)  REFERENCES employees(id),
  FOREIGN KEY (companyId)   REFERENCES companies(id),
  FOREIGN KEY (branchId)    REFERENCES branches(id),
  INDEX idx_emp_company (employeeId, companyId),
  INDEX idx_company_branch (companyId, branchId),
  INDEX idx_role (role)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ─────────────────────────────────────────────
-- العملاء
-- ─────────────────────────────────────────────

CREATE TABLE IF NOT EXISTS clients (
  id               INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  companyId        INT UNSIGNED NOT NULL,
  code             VARCHAR(50),
  type             ENUM('individual','company') DEFAULT 'individual',
  name             VARCHAR(200),
  phone            VARCHAR(30),
  email            VARCHAR(200),
  nationality      VARCHAR(50),
  language         VARCHAR(10) DEFAULT 'ar',
  lat              DECIMAL(10,7),
  lon              DECIMAL(10,7),
  classification   ENUM('vip','premium','regular','prospect','churned') DEFAULT 'prospect',
  source           ENUM('whatsapp','call','email','referral','web','walk_in') DEFAULT 'whatsapp',
  assignedTo       INT UNSIGNED,
  totalRevenue     DECIMAL(15,2) DEFAULT 0,
  avgRating        DECIMAL(3,2),
  tags             JSON,
  isBlacklisted    TINYINT(1) DEFAULT 0,
  lastActivityAt   DATETIME,
  lastPaymentAt    DATETIME,
  lastMaintenanceRequest DATETIME,
  createdAt        DATETIME NOT NULL DEFAULT NOW(),
  FOREIGN KEY (companyId) REFERENCES companies(id),
  INDEX idx_phone (phone),
  INDEX idx_company_class (companyId, classification)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ─────────────────────────────────────────────
-- المهام (قلب النظام)
-- ─────────────────────────────────────────────

CREATE TABLE IF NOT EXISTS tasks (
  id               INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  companyId        INT UNSIGNED NOT NULL,
  branchId         INT UNSIGNED,
  assignedTo       INT UNSIGNED,           -- assignmentId
  type             VARCHAR(100) NOT NULL,
  refType          VARCHAR(100),
  refId            INT UNSIGNED,
  title            VARCHAR(500) NOT NULL,
  description      TEXT,
  clientId         INT UNSIGNED,
  lat              DECIMAL(10,7),
  lon              DECIMAL(10,7),
  priority         ENUM('low','normal','high','urgent') DEFAULT 'normal',
  status           ENUM('pending','in_progress','completed','cancelled','blocked') DEFAULT 'pending',
  scheduledStart   DATETIME,
  scheduledEnd     DATETIME,
  scheduledDate    DATE,
  estimatedDuration INT,                   -- دقائق
  actualDuration   INT,
  slaDeadline      DATETIME,
  slaBreachNotified TINYINT(1) DEFAULT 0,
  silentAlertSent  TINYINT(1) DEFAULT 0,
  lastUpdatedAt    DATETIME DEFAULT NOW() ON UPDATE NOW(),
  completedAt      DATETIME,
  notes            TEXT,
  createdAt        DATETIME NOT NULL DEFAULT NOW(),
  FOREIGN KEY (companyId) REFERENCES companies(id),
  INDEX idx_assignedTo (assignedTo),
  INDEX idx_status_date (status, scheduledDate),
  INDEX idx_ref (refType, refId),
  INDEX idx_sla (slaDeadline, status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS task_dependencies (
  taskId           INT UNSIGNED NOT NULL,
  dependsOnTaskId  INT UNSIGNED NOT NULL,
  PRIMARY KEY (taskId, dependsOnTaskId)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS task_ratings (
  id           INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  taskId       INT UNSIGNED NOT NULL,
  assignedTo   INT UNSIGNED NOT NULL,
  clientId     INT UNSIGNED,
  companyId    INT UNSIGNED NOT NULL,
  rating       TINYINT NOT NULL CHECK (rating BETWEEN 1 AND 5),
  comment      TEXT,
  createdAt    DATETIME NOT NULL DEFAULT NOW(),
  INDEX idx_assignedTo (assignedTo),
  INDEX idx_companyId (companyId)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ─────────────────────────────────────────────
-- الإشعارات
-- ─────────────────────────────────────────────

CREATE TABLE IF NOT EXISTS notifications (
  id           INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  companyId    INT UNSIGNED NOT NULL,
  assignmentId INT UNSIGNED,
  type         VARCHAR(100) NOT NULL,
  title        VARCHAR(300) NOT NULL,
  body         TEXT,
  priority     ENUM('low','normal','high','urgent') DEFAULT 'normal',
  targetRole   VARCHAR(100),
  actionUrl    VARCHAR(500),
  refType      VARCHAR(100),
  refId        INT UNSIGNED,
  actions      JSON,
  isRead       TINYINT(1) DEFAULT 0,
  readAt       DATETIME,
  createdAt    DATETIME NOT NULL DEFAULT NOW(),
  INDEX idx_assignment (assignmentId, isRead),
  INDEX idx_company_type (companyId, type)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS scheduled_notifications (
  id           INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  companyId    INT UNSIGNED NOT NULL,
  assignmentId INT UNSIGNED,
  type         VARCHAR(100) NOT NULL,
  refType      VARCHAR(100),
  refId        INT UNSIGNED,
  scheduledAt  DATETIME NOT NULL,
  body         TEXT,
  sent         TINYINT(1) DEFAULT 0,
  sentAt       DATETIME,
  createdAt    DATETIME NOT NULL DEFAULT NOW(),
  INDEX idx_scheduled (scheduledAt, sent)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ─────────────────────────────────────────────
-- سجل الأحداث والتدقيق
-- ─────────────────────────────────────────────

CREATE TABLE IF NOT EXISTS audit_logs (
  id           INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  companyId    INT UNSIGNED,
  branchId     INT UNSIGNED,
  userId       INT UNSIGNED,
  action       VARCHAR(200) NOT NULL,
  entity       VARCHAR(100),
  entityId     INT UNSIGNED,
  before       JSON,
  after        JSON,
  reason       TEXT,
  scope        JSON,
  ipAddress    VARCHAR(50),
  createdAt    DATETIME NOT NULL DEFAULT NOW(),
  INDEX idx_entity (entity, entityId),
  INDEX idx_company_action (companyId, action),
  INDEX idx_created (createdAt)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS event_logs (
  id           INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  eventName    VARCHAR(200) NOT NULL,
  payload      JSON,
  processedAt  DATETIME,
  status       ENUM('pending','processed','failed') DEFAULT 'pending',
  error        TEXT,
  createdAt    DATETIME NOT NULL DEFAULT NOW(),
  INDEX idx_event (eventName, status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ─────────────────────────────────────────────
-- قوائم الإرسال
-- ─────────────────────────────────────────────

CREATE TABLE IF NOT EXISTS sms_queue (
  id           INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  companyId    INT UNSIGNED NOT NULL,
  phone        VARCHAR(30),
  clientId     INT UNSIGNED,
  assignmentId INT UNSIGNED,
  message      VARCHAR(500) NOT NULL,
  status       ENUM('queued','sent','failed') DEFAULT 'queued',
  sentAt       DATETIME,
  scheduledAt  DATETIME DEFAULT NOW(),
  createdAt    DATETIME NOT NULL DEFAULT NOW(),
  INDEX idx_status (status, scheduledAt)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS email_queue (
  id            INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  companyId     INT UNSIGNED NOT NULL,
  toEmail       VARCHAR(200) NOT NULL,
  recipientName VARCHAR(200),
  subject       VARCHAR(500) NOT NULL,
  body          TEXT NOT NULL,
  clientId      INT UNSIGNED,
  priority      ENUM('low','normal','high') DEFAULT 'normal',
  refType       VARCHAR(100),
  refId         INT UNSIGNED,
  status        ENUM('queued','sent','failed') DEFAULT 'queued',
  sentAt        DATETIME,
  scheduledAt   DATETIME DEFAULT NOW(),
  createdAt     DATETIME NOT NULL DEFAULT NOW(),
  INDEX idx_status (status, scheduledAt)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS whatsapp_queue (
  id            INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  companyId     INT UNSIGNED NOT NULL,
  phone         VARCHAR(30) NOT NULL,
  recipientName VARCHAR(200),
  clientId      INT UNSIGNED,
  assignmentId  INT UNSIGNED,
  message       TEXT NOT NULL,
  templateName  VARCHAR(100),
  templateParams JSON,
  sentBy        VARCHAR(50),
  status        ENUM('queued','sent','delivered','read','failed') DEFAULT 'queued',
  messageId     VARCHAR(200),
  sentAt        DATETIME,
  deliveredAt   DATETIME,
  scheduledAt   DATETIME DEFAULT NOW(),
  createdAt     DATETIME NOT NULL DEFAULT NOW(),
  INDEX idx_status (status, scheduledAt),
  INDEX idx_phone (phone)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS notification_log (
  id           INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  companyId    INT UNSIGNED NOT NULL,
  assignmentId INT UNSIGNED,
  clientId     INT UNSIGNED,
  type         VARCHAR(100),
  title        VARCHAR(300),
  channels     JSON,
  status       ENUM('sent','delivered','failed') DEFAULT 'sent',
  sentAt       DATETIME NOT NULL DEFAULT NOW(),
  INDEX idx_company (companyId, sentAt)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Cron logs
CREATE TABLE IF NOT EXISTS cron_logs (
  id           INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  companyId    INT UNSIGNED,
  jobName      VARCHAR(200) NOT NULL,
  lastRunAt    DATETIME,
  lastStatus   ENUM('success','failed','running') DEFAULT 'success',
  lastDuration INT,    -- milliseconds
  lastCount    INT DEFAULT 0,
  error        TEXT,
  UNIQUE KEY uk_job (companyId, jobName)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS cron_manual_triggers (
  id          INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  companyId   INT UNSIGNED,
  cronId      INT,
  cronName    VARCHAR(200),
  triggeredBy INT UNSIGNED,
  createdAt   DATETIME NOT NULL DEFAULT NOW()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS system_jobs (
  id          INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  companyId   INT UNSIGNED,
  jobType     VARCHAR(100) NOT NULL,
  refType     VARCHAR(100),
  refId       INT UNSIGNED,
  status      ENUM('pending','processing','done','failed') DEFAULT 'pending',
  scheduledAt DATETIME DEFAULT NOW(),
  processedAt DATETIME,
  error       TEXT,
  createdAt   DATETIME NOT NULL DEFAULT NOW(),
  INDEX idx_status (status, scheduledAt)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS approval_requests (
  id           INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  companyId    INT UNSIGNED NOT NULL,
  branchId     INT UNSIGNED,
  refType      VARCHAR(100) NOT NULL,
  refId        INT UNSIGNED NOT NULL,
  requiredRole VARCHAR(100),
  assignedTo   INT UNSIGNED,
  status       ENUM('pending','approved','rejected','escalated') DEFAULT 'pending',
  decision     TEXT,
  decidedBy    INT UNSIGNED,
  decidedAt    DATETIME,
  expiresAt    DATETIME,
  createdAt    DATETIME NOT NULL DEFAULT NOW(),
  INDEX idx_ref (refType, refId),
  INDEX idx_status (status, expiresAt)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

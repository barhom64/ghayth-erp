-- ══════════════════════════════════════════════════════════════
-- ghayth_erp — schema_02_hr_finance.sql
-- المرحلة 2+3: الموارد البشرية والمالية
-- ══════════════════════════════════════════════════════════════

-- ─────────────────────────────────────────────
-- الورديات والحضور
-- ─────────────────────────────────────────────

CREATE TABLE IF NOT EXISTS shifts (
  id           INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  companyId    INT UNSIGNED NOT NULL,
  branchId     INT UNSIGNED,
  name         VARCHAR(100) NOT NULL,
  startTime    TIME NOT NULL,
  endTime      TIME NOT NULL,
  breakMinutes INT DEFAULT 60,
  workDays     JSON,   -- [0,1,2,3,4] أيام الأسبوع
  isDefault    TINYINT(1) DEFAULT 0,
  createdAt    DATETIME NOT NULL DEFAULT NOW(),
  INDEX idx_company (companyId, branchId)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS employee_shift_assignments (
  id           INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  assignmentId INT UNSIGNED NOT NULL,
  shiftId      INT UNSIGNED NOT NULL,
  startDate    DATE,
  endDate      DATE,
  UNIQUE KEY uk_active (assignmentId, shiftId)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS attendance (
  id            INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  companyId     INT UNSIGNED NOT NULL,
  branchId      INT UNSIGNED,
  employeeId    INT UNSIGNED NOT NULL,
  assignmentId  INT UNSIGNED NOT NULL,
  date          DATE NOT NULL,
  checkIn       DATETIME,
  checkOut      DATETIME,
  checkInLat    DECIMAL(10,7),
  checkInLon    DECIMAL(10,7),
  lateMinutes   INT DEFAULT 0,
  earlyLeaveMin INT DEFAULT 0,
  status        ENUM('present','absent','late','leave','holiday','remote') DEFAULT 'present',
  method        ENUM('gps','qr','manual','auto') DEFAULT 'gps',
  notes         TEXT,
  createdAt     DATETIME NOT NULL DEFAULT NOW(),
  UNIQUE KEY uk_emp_date (assignmentId, date),
  INDEX idx_company_date (companyId, date),
  INDEX idx_employee (employeeId)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS attendance_deductions (
  id           INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  companyId    INT UNSIGNED NOT NULL,
  assignmentId INT UNSIGNED NOT NULL,
  attendanceId INT UNSIGNED,
  type         ENUM('late','absence','early_leave') NOT NULL,
  minutes      INT,
  amount       DECIMAL(10,2) NOT NULL,
  period       VARCHAR(7),   -- YYYY-MM
  status       ENUM('pending_payroll','applied','cancelled') DEFAULT 'pending_payroll',
  createdAt    DATETIME NOT NULL DEFAULT NOW(),
  INDEX idx_assignment_period (assignmentId, period)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ─────────────────────────────────────────────
-- الإجازات
-- ─────────────────────────────────────────────

CREATE TABLE IF NOT EXISTS hr_leave_types (
  id           INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  companyId    INT UNSIGNED NOT NULL,
  name         VARCHAR(100) NOT NULL,
  nameEn       VARCHAR(100),
  annualDays   INT DEFAULT 0,
  isPaid       TINYINT(1) DEFAULT 1,
  requiresDoc  TINYINT(1) DEFAULT 0,
  genderLimit  ENUM('all','male','female') DEFAULT 'all',
  maxPerYear   INT,
  status       ENUM('active','inactive') DEFAULT 'active',
  INDEX idx_company (companyId)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS hr_leave_balances (
  id           INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  companyId    INT UNSIGNED NOT NULL,
  employeeId   INT UNSIGNED NOT NULL,
  assignmentId INT UNSIGNED,
  leaveTypeId  INT UNSIGNED NOT NULL,
  year         YEAR NOT NULL,
  entitled     DECIMAL(6,2) DEFAULT 0,
  used         DECIMAL(6,2) DEFAULT 0,
  reserved     DECIMAL(6,2) DEFAULT 0,
  remaining    DECIMAL(6,2) GENERATED ALWAYS AS (entitled - used - reserved) VIRTUAL,
  UNIQUE KEY uk_balance (assignmentId, leaveTypeId, year),
  INDEX idx_employee (employeeId)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS hr_leave_requests (
  id           INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  companyId    INT UNSIGNED NOT NULL,
  employeeId   INT UNSIGNED NOT NULL,
  assignmentId INT UNSIGNED,    -- NULL = يتبع الشخص
  leaveTypeId  INT UNSIGNED NOT NULL,
  startDate    DATE NOT NULL,
  endDate      DATE NOT NULL,
  days         INT NOT NULL,
  reason       TEXT,
  documentUrl  VARCHAR(500),
  status       ENUM('pending','approved','rejected','cancelled') DEFAULT 'pending',
  approvedBy   INT UNSIGNED,
  approvedAt   DATETIME,
  rejectedReason TEXT,
  autoApproved TINYINT(1) DEFAULT 0,
  createdAt    DATETIME NOT NULL DEFAULT NOW(),
  INDEX idx_employee (employeeId, status),
  INDEX idx_company (companyId, status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ─────────────────────────────────────────────
-- المخالفات والعقوبات
-- ─────────────────────────────────────────────

CREATE TABLE IF NOT EXISTS employee_violations (
  id           INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  companyId    INT UNSIGNED NOT NULL,
  assignmentId INT UNSIGNED,
  driverId     INT UNSIGNED,
  type         VARCHAR(100) NOT NULL,
  description  TEXT,
  severity     ENUM('low','medium','high','critical') DEFAULT 'medium',
  deduction    DECIMAL(10,2) DEFAULT 0,
  period       VARCHAR(7),
  status       ENUM('active','appealed','cancelled') DEFAULT 'active',
  createdAt    DATETIME NOT NULL DEFAULT NOW(),
  INDEX idx_assignment (assignmentId, period)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ─────────────────────────────────────────────
-- الرواتب
-- ─────────────────────────────────────────────

CREATE TABLE IF NOT EXISTS salary_components (
  id           INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  companyId    INT UNSIGNED NOT NULL,
  name         VARCHAR(100) NOT NULL,
  type         ENUM('fixed','percentage','variable') NOT NULL,
  value        DECIMAL(10,2),
  taxable      TINYINT(1) DEFAULT 1,
  status       ENUM('active','inactive') DEFAULT 'active'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS payroll_runs (
  id           INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  companyId    INT UNSIGNED NOT NULL,
  branchId     INT UNSIGNED,
  period       VARCHAR(7) NOT NULL,   -- YYYY-MM
  status       ENUM('draft','approved','paid') DEFAULT 'draft',
  totalGross   DECIMAL(15,2) DEFAULT 0,
  totalNet     DECIMAL(15,2) DEFAULT 0,
  totalGosi    DECIMAL(15,2) DEFAULT 0,
  runBy        INT UNSIGNED,
  approvedBy   INT UNSIGNED,
  paidAt       DATETIME,
  createdAt    DATETIME NOT NULL DEFAULT NOW(),
  UNIQUE KEY uk_period (companyId, branchId, period)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS payroll_lines (
  id           INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  runId        INT UNSIGNED NOT NULL,
  assignmentId INT UNSIGNED NOT NULL,
  basic        DECIMAL(12,2) DEFAULT 0,
  housing      DECIMAL(12,2) DEFAULT 0,
  transport    DECIMAL(12,2) DEFAULT 0,
  otherAllowances DECIMAL(12,2) DEFAULT 0,
  grossSalary  DECIMAL(12,2) DEFAULT 0,
  lateDeduction  DECIMAL(12,2) DEFAULT 0,
  absenceDeduction DECIMAL(12,2) DEFAULT 0,
  violationDeduction DECIMAL(12,2) DEFAULT 0,
  advance      DECIMAL(12,2) DEFAULT 0,
  gosi         DECIMAL(12,2) DEFAULT 0,
  overtime     DECIMAL(12,2) DEFAULT 0,
  netSalary    DECIMAL(12,2) DEFAULT 0,
  notes        TEXT,
  FOREIGN KEY (runId) REFERENCES payroll_runs(id),
  INDEX idx_run (runId)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ─────────────────────────────────────────────
-- المالية
-- ─────────────────────────────────────────────

CREATE TABLE IF NOT EXISTS chart_of_accounts (
  id           INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  companyId    INT UNSIGNED NOT NULL,
  code         VARCHAR(20) NOT NULL,
  name         VARCHAR(200) NOT NULL,
  type         ENUM('asset','liability','equity','revenue','expense') NOT NULL,
  parentCode   VARCHAR(20),
  level        TINYINT DEFAULT 1,
  isLeaf       TINYINT(1) DEFAULT 1,
  balance      DECIMAL(15,2) DEFAULT 0,
  UNIQUE KEY uk_code (companyId, code),
  INDEX idx_company (companyId)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS journal_entries (
  id           INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  companyId    INT UNSIGNED NOT NULL,
  branchId     INT UNSIGNED,
  ref          VARCHAR(100),
  description  TEXT,
  status       ENUM('draft','posted','reversed') DEFAULT 'posted',
  createdBy    INT UNSIGNED,
  approvedBy   INT UNSIGNED,
  createdAt    DATETIME NOT NULL DEFAULT NOW(),
  INDEX idx_company (companyId),
  INDEX idx_ref (ref)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS journal_lines (
  id           INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  journalId    INT UNSIGNED NOT NULL,
  accountCode  VARCHAR(20) NOT NULL,
  debit        DECIMAL(15,2) DEFAULT 0,
  credit       DECIMAL(15,2) DEFAULT 0,
  description  VARCHAR(300),
  FOREIGN KEY (journalId) REFERENCES journal_entries(id),
  INDEX idx_journal (journalId),
  INDEX idx_account (accountCode)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS invoices (
  id           INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  companyId    INT UNSIGNED NOT NULL,
  branchId     INT UNSIGNED,
  clientId     INT UNSIGNED NOT NULL,
  ref          VARCHAR(100) UNIQUE,
  type         ENUM('sale','purchase','proforma') DEFAULT 'sale',
  description  TEXT,
  subtotal     DECIMAL(15,2) NOT NULL DEFAULT 0,
  vatRate      DECIMAL(5,2) DEFAULT 15,
  vatAmount    DECIMAL(15,2) DEFAULT 0,
  total        DECIMAL(15,2) NOT NULL DEFAULT 0,
  paidAmount   DECIMAL(15,2) DEFAULT 0,
  status       ENUM('draft','sent','partial','paid','overdue','cancelled') DEFAULT 'draft',
  dueDate      DATE,
  paidAt       DATETIME,
  qrData       TEXT,
  pdfUrl       VARCHAR(500),
  createdBy    INT UNSIGNED,
  createdAt    DATETIME NOT NULL DEFAULT NOW(),
  FOREIGN KEY (companyId) REFERENCES companies(id),
  INDEX idx_client (clientId, status),
  INDEX idx_due (dueDate, status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS budgets (
  id           INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  companyId    INT UNSIGNED NOT NULL,
  branchId     INT UNSIGNED,
  departmentId INT UNSIGNED,
  projectId    INT UNSIGNED,
  accountCode  VARCHAR(20),
  period       VARCHAR(7),
  amount       DECIMAL(15,2) NOT NULL DEFAULT 0,
  used         DECIMAL(15,2) DEFAULT 0,
  status       ENUM('active','frozen','closed') DEFAULT 'active',
  createdAt    DATETIME NOT NULL DEFAULT NOW(),
  INDEX idx_company_period (companyId, period)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS monthly_closes (
  id           INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  companyId    INT UNSIGNED NOT NULL,
  period       VARCHAR(7) NOT NULL,
  totalDebits  DECIMAL(15,2) DEFAULT 0,
  totalCredits DECIMAL(15,2) DEFAULT 0,
  journalCount INT DEFAULT 0,
  status       ENUM('draft','approved') DEFAULT 'draft',
  approvedBy   INT UNSIGNED,
  approvedAt   DATETIME,
  createdAt    DATETIME NOT NULL DEFAULT NOW(),
  UNIQUE KEY uk_period (companyId, period)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS cash_flow_items (
  id           INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  companyId    INT UNSIGNED NOT NULL,
  type         ENUM('receivable','payable') NOT NULL,
  amount       DECIMAL(15,2) NOT NULL,
  description  VARCHAR(300),
  expectedDate DATE NOT NULL,
  refType      VARCHAR(100),
  refId        INT UNSIGNED,
  status       ENUM('pending','received','cancelled') DEFAULT 'pending',
  createdAt    DATETIME NOT NULL DEFAULT NOW(),
  INDEX idx_company_date (companyId, expectedDate)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS suppliers (
  id           INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  companyId    INT UNSIGNED NOT NULL,
  name         VARCHAR(200) NOT NULL,
  phone        VARCHAR(30),
  email        VARCHAR(200),
  vatNumber    VARCHAR(50),
  status       ENUM('active','inactive') DEFAULT 'active',
  createdAt    DATETIME NOT NULL DEFAULT NOW()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS purchase_requests (
  id               INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  companyId        INT UNSIGNED NOT NULL,
  branchId         INT UNSIGNED,
  productId        INT UNSIGNED,
  quantity         INT NOT NULL,
  estimatedUnitCost DECIMAL(12,2),
  totalEstimated   DECIMAL(12,2),
  supplierId       INT UNSIGNED,
  reason           VARCHAR(300),
  status           ENUM('pending','approved','rejected','po_created') DEFAULT 'pending',
  isAutoGenerated  TINYINT(1) DEFAULT 0,
  createdAt        DATETIME NOT NULL DEFAULT NOW(),
  INDEX idx_company_status (companyId, status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS purchase_orders (
  id               INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  companyId        INT UNSIGNED NOT NULL,
  branchId         INT UNSIGNED,
  poNumber         VARCHAR(100) UNIQUE,
  purchaseRequestId INT UNSIGNED,
  productId        INT UNSIGNED,
  quantity         INT NOT NULL,
  receivedQty      INT DEFAULT 0,
  confirmedUnitCost DECIMAL(12,2),
  totalConfirmed   DECIMAL(12,2),
  supplierId       INT UNSIGNED,
  expectedDeliveryDate DATE,
  status           ENUM('draft','sent','partial','received','cancelled') DEFAULT 'draft',
  receivedAt       DATETIME,
  createdBy        INT UNSIGNED,
  createdAt        DATETIME NOT NULL DEFAULT NOW()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- KPIs الصيانة
CREATE TABLE IF NOT EXISTS maintenance_kpis (
  id           INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  companyId    INT UNSIGNED NOT NULL,
  branchId     INT UNSIGNED,
  metric       VARCHAR(100) NOT NULL,
  value        DECIMAL(15,2) DEFAULT 0,
  period       VARCHAR(7),
  createdAt    DATETIME NOT NULL DEFAULT NOW(),
  UNIQUE KEY uk_metric (companyId, branchId, metric, period)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

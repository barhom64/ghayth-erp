-- ══════════════════════════════════════════════════════════════
-- ghayth_erp — schema_03_operations.sql
-- المرحلة 4+5: العمليات والتواصل
-- ══════════════════════════════════════════════════════════════

-- ─────────────────────────────────────────────
-- الأسطول
-- ─────────────────────────────────────────────

CREATE TABLE IF NOT EXISTS fleet_vehicles (
  id                    INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  companyId             INT UNSIGNED NOT NULL,
  branchId              INT UNSIGNED NOT NULL,
  plate                 VARCHAR(20) NOT NULL,
  type                  VARCHAR(50),
  brand                 VARCHAR(100),
  model                 VARCHAR(100),
  year                  YEAR,
  color                 VARCHAR(50),
  maxPayloadKg          INT,
  odometer              INT DEFAULT 0,
  normalConsumptionPer100 DECIMAL(5,2) DEFAULT 12,
  currentLat            DECIMAL(10,7),
  currentLon            DECIMAL(10,7),
  nextMaintenanceDate   DATE,
  lastMaintenanceDate   DATE,
  status                ENUM('available','on_trip','maintenance','suspended') DEFAULT 'available',
  createdAt             DATETIME NOT NULL DEFAULT NOW(),
  INDEX idx_company_status (companyId, status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS fleet_drivers (
  id            INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  companyId     INT UNSIGNED NOT NULL,
  branchId      INT UNSIGNED NOT NULL,
  assignmentId  INT UNSIGNED,
  name          VARCHAR(200) NOT NULL,
  phone         VARCHAR(30),
  licenseNumber VARCHAR(50),
  licenseExpiry DATE,
  rating        DECIMAL(3,2) DEFAULT 4.0,
  skills        TEXT,
  specialties   TEXT,
  vehicleId     INT UNSIGNED,
  lat           DECIMAL(10,7),
  lon           DECIMAL(10,7),
  completedTasks INT DEFAULT 0,
  avgDuration   INT DEFAULT 0,
  status        ENUM('available','on_trip','off_duty','suspended') DEFAULT 'available',
  createdAt     DATETIME NOT NULL DEFAULT NOW()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS fleet_insurance (
  id         INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  companyId  INT UNSIGNED NOT NULL,
  vehicleId  INT UNSIGNED NOT NULL,
  provider   VARCHAR(200),
  policyNumber VARCHAR(100),
  expiresAt  DATE NOT NULL,
  status     ENUM('active','expired') DEFAULT 'active',
  createdAt  DATETIME NOT NULL DEFAULT NOW(),
  INDEX idx_vehicle (vehicleId, status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS fleet_trips (
  id              INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  companyId       INT UNSIGNED NOT NULL,
  branchId        INT UNSIGNED NOT NULL,
  vehicleId       INT UNSIGNED NOT NULL,
  driverId        INT UNSIGNED NOT NULL,
  clientId        INT UNSIGNED,
  fromLat         DECIMAL(10,7), fromLon DECIMAL(10,7),
  toLat           DECIMAL(10,7), toLon   DECIMAL(10,7),
  distanceKm      DECIMAL(8,2),
  travelMin       INT,
  totalMin        INT,
  actualDistanceKm DECIMAL(8,2),
  actualDurationMin INT,
  scheduledStart  DATETIME,
  estimatedArrival DATETIME,
  completedAt     DATETIME,
  cargoDescription TEXT,
  fuelCost        DECIMAL(10,2),
  driverWageCost  DECIMAL(10,2),
  depreciationCost DECIMAL(10,2),
  totalCost       DECIMAL(10,2),
  signatureBase64  MEDIUMTEXT,
  photoUrls        JSON,
  trackingToken    VARCHAR(200),
  status          ENUM('scheduled','in_progress','completed','cancelled') DEFAULT 'scheduled',
  requestedBy     INT UNSIGNED,
  createdAt       DATETIME NOT NULL DEFAULT NOW(),
  INDEX idx_company_status (companyId, status),
  INDEX idx_driver (driverId)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS fleet_maintenance (
  id           INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  companyId    INT UNSIGNED NOT NULL,
  branchId     INT UNSIGNED,
  vehicleId    INT UNSIGNED NOT NULL,
  type         ENUM('periodic','emergency') NOT NULL,
  workshopName VARCHAR(200),
  parts        JSON,
  laborCost    DECIMAL(10,2) DEFAULT 0,
  totalCost    DECIMAL(10,2) DEFAULT 0,
  notes        TEXT,
  performedAt  DATETIME,
  createdBy    INT UNSIGNED,
  createdAt    DATETIME NOT NULL DEFAULT NOW(),
  INDEX idx_vehicle (vehicleId)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS fleet_fuel_logs (
  id           INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  companyId    INT UNSIGNED NOT NULL,
  branchId     INT UNSIGNED,
  vehicleId    INT UNSIGNED NOT NULL,
  litersFilled DECIMAL(8,2) NOT NULL,
  pricePerLiter DECIMAL(6,2),
  totalCost    DECIMAL(10,2),
  stationName  VARCHAR(200),
  loggedBy     INT UNSIGNED,
  createdAt    DATETIME NOT NULL DEFAULT NOW(),
  INDEX idx_vehicle (vehicleId)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS fleet_gps_tracking (
  id         INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  companyId  INT UNSIGNED NOT NULL,
  vehicleId  INT UNSIGNED NOT NULL,
  driverId   INT UNSIGNED,
  lat        DECIMAL(10,7) NOT NULL,
  lon        DECIMAL(10,7) NOT NULL,
  speed      DECIMAL(6,2),
  heading    DECIMAL(6,2),
  alertSent  TINYINT(1) DEFAULT 0,
  recordedAt DATETIME NOT NULL DEFAULT NOW(),
  INDEX idx_vehicle_time (vehicleId, recordedAt)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS fleet_geofence_violations (
  id          INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  companyId   INT UNSIGNED NOT NULL,
  vehicleId   INT UNSIGNED NOT NULL,
  geofenceName VARCHAR(200),
  violationType ENUM('entry','exit') NOT NULL,
  alertSent   TINYINT(1) DEFAULT 0,
  recordedAt  DATETIME NOT NULL DEFAULT NOW()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS fleet_kpis (
  id          INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  companyId   INT UNSIGNED NOT NULL,
  branchId    INT UNSIGNED,
  metric      VARCHAR(100) NOT NULL,
  value       DECIMAL(15,2) DEFAULT 0,
  period      VARCHAR(7),
  createdAt   DATETIME NOT NULL DEFAULT NOW(),
  UNIQUE KEY uk_metric (companyId, branchId, metric, period)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ─────────────────────────────────────────────
-- المستودعات
-- ─────────────────────────────────────────────

CREATE TABLE IF NOT EXISTS warehouse_categories (
  id        INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  companyId INT UNSIGNED NOT NULL,
  name      VARCHAR(200) NOT NULL,
  parentId  INT UNSIGNED
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS warehouse_products (
  id                INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  companyId         INT UNSIGNED NOT NULL,
  branchId          INT UNSIGNED NOT NULL,
  sku               VARCHAR(100),
  name              VARCHAR(300) NOT NULL,
  unit              VARCHAR(50) DEFAULT 'piece',
  categoryId        INT UNSIGNED,
  currentQty        INT DEFAULT 0,
  minQty            INT DEFAULT 5,
  reorderQty        INT,
  unitCost          DECIMAL(12,2) DEFAULT 0,
  defaultSupplierId INT UNSIGNED,
  lastReceivedAt    DATETIME,
  status            ENUM('active','inactive') DEFAULT 'active',
  createdAt         DATETIME NOT NULL DEFAULT NOW(),
  INDEX idx_company_branch (companyId, branchId),
  INDEX idx_stock (companyId, currentQty)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS warehouse_movements (
  id            INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  companyId     INT UNSIGNED NOT NULL,
  branchId      INT UNSIGNED,
  productId     INT UNSIGNED NOT NULL,
  movementType  ENUM('receive','issue','transfer_in','transfer_out','adjust','return') NOT NULL,
  quantity      INT NOT NULL,
  unitCost      DECIMAL(12,2),
  totalCost     DECIMAL(12,2),
  refType       VARCHAR(100),
  refId         INT UNSIGNED,
  batchNumber   VARCHAR(100),
  expiryDate    DATE,
  locationCode  VARCHAR(100),
  performedBy   INT UNSIGNED,
  createdAt     DATETIME NOT NULL DEFAULT NOW(),
  INDEX idx_product (productId, createdAt),
  INDEX idx_ref (refType, refId)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS warehouse_stock_batches (
  id           INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  companyId    INT UNSIGNED NOT NULL,
  productId    INT UNSIGNED NOT NULL,
  batchNumber  VARCHAR(100),
  quantity     INT NOT NULL,
  remainingQty INT NOT NULL,
  unitCost     DECIMAL(12,2),
  expiryDate   DATE,
  createdAt    DATETIME NOT NULL DEFAULT NOW(),
  INDEX idx_product (productId, remainingQty)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS inventory_snapshots (
  id             INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  companyId      INT UNSIGNED NOT NULL,
  branchId       INT UNSIGNED,
  period         VARCHAR(7) NOT NULL,
  totalProducts  INT DEFAULT 0,
  totalValue     DECIMAL(15,2) DEFAULT 0,
  lowStockCount  INT DEFAULT 0,
  outOfStockCount INT DEFAULT 0,
  snapshotAt     DATETIME NOT NULL DEFAULT NOW(),
  UNIQUE KEY uk_snapshot (companyId, branchId, period)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ─────────────────────────────────────────────
-- الأملاك
-- ─────────────────────────────────────────────

CREATE TABLE IF NOT EXISTS property_units (
  id          INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  companyId   INT UNSIGNED NOT NULL,
  branchId    INT UNSIGNED NOT NULL,
  unitNumber  VARCHAR(50) NOT NULL,
  type        ENUM('apartment','villa','office','shop','warehouse') DEFAULT 'apartment',
  address     TEXT,
  lat         DECIMAL(10,7),
  lon         DECIMAL(10,7),
  area        DECIMAL(10,2),
  floor       INT,
  bedrooms    INT,
  status      ENUM('vacant','occupied','maintenance','reserved') DEFAULT 'vacant',
  createdAt   DATETIME NOT NULL DEFAULT NOW(),
  INDEX idx_company_branch (companyId, branchId)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS rental_contracts (
  id              INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  companyId       INT UNSIGNED NOT NULL,
  unitId          INT UNSIGNED NOT NULL,
  clientId        INT UNSIGNED NOT NULL,
  amount          DECIMAL(12,2) NOT NULL,
  startDate       DATE NOT NULL,
  endDate         DATE NOT NULL,
  nextPaymentDate DATE,
  lastPaymentDate DATE,
  daysLate        INT DEFAULT 0,
  status          ENUM('active','overdue','terminated','eviction_notice') DEFAULT 'active',
  autoRenew       TINYINT(1) DEFAULT 0,
  createdAt       DATETIME NOT NULL DEFAULT NOW(),
  INDEX idx_unit (unitId),
  INDEX idx_status (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS rent_payments (
  id            INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  companyId     INT UNSIGNED NOT NULL,
  branchId      INT UNSIGNED,
  contractId    INT UNSIGNED NOT NULL,
  clientId      INT UNSIGNED NOT NULL,
  amount        DECIMAL(12,2) NOT NULL,
  paymentMethod ENUM('bank_transfer','cash','cheque','online') DEFAULT 'cash',
  reference     VARCHAR(200),
  paidAt        DATETIME NOT NULL,
  recordedBy    INT UNSIGNED,
  createdAt     DATETIME NOT NULL DEFAULT NOW()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS maintenance_requests (
  id                INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  companyId         INT UNSIGNED NOT NULL,
  branchId          INT UNSIGNED,
  mrNumber          VARCHAR(100) UNIQUE,
  unitId            INT UNSIGNED NOT NULL,
  clientId          INT UNSIGNED NOT NULL,
  category          VARCHAR(100) NOT NULL,
  description       TEXT NOT NULL,
  reportedVia       ENUM('portal','whatsapp','phone','app') DEFAULT 'portal',
  photos            JSON,
  priority          ENUM('emergency','high','medium','low') DEFAULT 'medium',
  slaDeadline       DATETIME,
  assignedTechId    INT UNSIGNED,
  scheduledStart    DATETIME,
  distanceKm        DECIMAL(8,2),
  travelMin         INT,
  actualDurationMin INT,
  totalCost         DECIMAL(12,2),
  partsUsed         JSON,
  laborCost         DECIMAL(12,2),
  completionPhotos  JSON,
  completionNotes   TEXT,
  completedWithinSla TINYINT(1),
  status            ENUM('new','assigned','in_progress','completed','cancelled') DEFAULT 'new',
  completedAt       DATETIME,
  createdAt         DATETIME NOT NULL DEFAULT NOW(),
  INDEX idx_unit (unitId, status),
  INDEX idx_client (clientId)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS technicians (
  id            INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  companyId     INT UNSIGNED NOT NULL,
  branchId      INT UNSIGNED NOT NULL,
  assignmentId  INT UNSIGNED,
  name          VARCHAR(200) NOT NULL,
  specialties   TEXT,
  rating        DECIMAL(3,2) DEFAULT 4.0,
  lat           DECIMAL(10,7),
  lon           DECIMAL(10,7),
  completedTasks INT DEFAULT 0,
  avgDuration   INT DEFAULT 0,
  status        ENUM('available','on_task','off_duty') DEFAULT 'available',
  createdAt     DATETIME NOT NULL DEFAULT NOW()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS late_rent_penalties (
  id         INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  companyId  INT UNSIGNED NOT NULL,
  contractId INT UNSIGNED NOT NULL,
  clientId   INT UNSIGNED NOT NULL,
  amount     DECIMAL(10,2) NOT NULL,
  reason     VARCHAR(300),
  createdAt  DATETIME NOT NULL DEFAULT NOW()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS formal_notices (
  id           INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  companyId    INT UNSIGNED NOT NULL,
  contractId   INT UNSIGNED,
  clientId     INT UNSIGNED NOT NULL,
  type         VARCHAR(100) NOT NULL,
  noticeNumber VARCHAR(100) UNIQUE,
  amount       DECIMAL(12,2),
  daysLate     INT,
  status       ENUM('draft','sent','acknowledged') DEFAULT 'sent',
  createdAt    DATETIME NOT NULL DEFAULT NOW()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS eviction_notices (
  id           INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  companyId    INT UNSIGNED NOT NULL,
  contractId   INT UNSIGNED NOT NULL,
  clientId     INT UNSIGNED NOT NULL,
  unitId       INT UNSIGNED NOT NULL,
  daysLate     INT,
  totalArrears DECIMAL(12,2),
  status       ENUM('pending','issued','executed','cancelled') DEFAULT 'pending',
  createdAt    DATETIME NOT NULL DEFAULT NOW()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ─────────────────────────────────────────────
-- القانونية
-- ─────────────────────────────────────────────

CREATE TABLE IF NOT EXISTS legal_contracts (
  id               INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  companyId        INT UNSIGNED NOT NULL,
  branchId         INT UNSIGNED,
  contractNumber   VARCHAR(100) UNIQUE,
  type             VARCHAR(100) NOT NULL,
  title            VARCHAR(300) NOT NULL,
  partyAId         INT UNSIGNED,
  partyBName       VARCHAR(200),
  value            DECIMAL(15,2),
  startDate        DATE,
  endDate          DATE,
  autoRenew        TINYINT(1) DEFAULT 0,
  renewNoticeDays  INT DEFAULT 30,
  documentUrl      VARCHAR(500),
  notes            TEXT,
  status           ENUM('active','expired','terminated','draft') DEFAULT 'active',
  reminderSent     TINYINT(1) DEFAULT 0,
  createdBy        INT UNSIGNED,
  createdAt        DATETIME NOT NULL DEFAULT NOW(),
  INDEX idx_company_status (companyId, status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS legal_cases (
  id               INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  companyId        INT UNSIGNED NOT NULL,
  branchId         INT UNSIGNED,
  caseNumber       VARCHAR(100) UNIQUE,
  type             VARCHAR(100) NOT NULL,
  title            VARCHAR(300) NOT NULL,
  clientId         INT UNSIGNED,
  contractId       INT UNSIGNED,
  courtName        VARCHAR(200),
  amount           DECIMAL(15,2),
  assignedLawyerId INT UNSIGNED,
  description      TEXT,
  filedDate        DATE,
  status           ENUM('open','in_progress','won','lost','settled','closed') DEFAULT 'open',
  createdBy        INT UNSIGNED,
  createdAt        DATETIME NOT NULL DEFAULT NOW()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS legal_sessions (
  id              INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  companyId       INT UNSIGNED NOT NULL,
  branchId        INT UNSIGNED,
  caseId          INT UNSIGNED NOT NULL,
  sessionDate     DATETIME NOT NULL,
  courtName       VARCHAR(200),
  courtLat        DECIMAL(10,7),
  courtLon        DECIMAL(10,7),
  distanceKm      DECIMAL(8,2),
  travelMin       INT,
  notes           TEXT,
  status          ENUM('scheduled','completed','postponed','cancelled') DEFAULT 'scheduled',
  reminderSent    TINYINT(1) DEFAULT 0,
  tomorrowAlertSent TINYINT(1) DEFAULT 0,
  createdBy       INT UNSIGNED,
  createdAt       DATETIME NOT NULL DEFAULT NOW()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ─────────────────────────────────────────────
-- المشاريع
-- ─────────────────────────────────────────────

CREATE TABLE IF NOT EXISTS projects (
  id           INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  companyId    INT UNSIGNED NOT NULL,
  branchId     INT UNSIGNED,
  projectCode  VARCHAR(100) UNIQUE,
  name         VARCHAR(300) NOT NULL,
  clientId     INT UNSIGNED,
  budget       DECIMAL(15,2) DEFAULT 0,
  budgetUsed   DECIMAL(15,2) DEFAULT 0,
  startDate    DATE,
  endDate      DATE,
  description  TEXT,
  status       ENUM('planning','active','on_hold','completed','cancelled') DEFAULT 'planning',
  createdBy    INT UNSIGNED,
  createdAt    DATETIME NOT NULL DEFAULT NOW()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS project_phases (
  id             INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  companyId      INT UNSIGNED NOT NULL,
  projectId      INT UNSIGNED NOT NULL,
  name           VARCHAR(200) NOT NULL,
  phaseOrder     INT NOT NULL,
  estimatedDays  INT,
  status         ENUM('pending','active','completed','blocked') DEFAULT 'pending',
  completedAt    DATETIME,
  createdAt      DATETIME NOT NULL DEFAULT NOW(),
  FOREIGN KEY (projectId) REFERENCES projects(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS project_task_phases (
  taskId   INT UNSIGNED NOT NULL,
  phaseId  INT UNSIGNED NOT NULL,
  PRIMARY KEY (taskId, phaseId)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ─────────────────────────────────────────────
-- الدعم
-- ─────────────────────────────────────────────

CREATE TABLE IF NOT EXISTS support_tickets (
  id                  INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  companyId           INT UNSIGNED NOT NULL,
  branchId            INT UNSIGNED,
  ticketNumber        VARCHAR(100) UNIQUE,
  clientId            INT UNSIGNED NOT NULL,
  subject             VARCHAR(500) NOT NULL,
  body                TEXT,
  channel             ENUM('whatsapp','email','phone','portal','app') DEFAULT 'portal',
  attachments         JSON,
  priority            ENUM('urgent','high','medium','low') DEFAULT 'medium',
  assignedTo          INT UNSIGNED,
  slaReplyDeadline    DATETIME,
  slaResolveDeadline  DATETIME,
  firstReplyAt        DATETIME,
  closedAt            DATETIME,
  closedBy            INT UNSIGNED,
  resolution          TEXT,
  resolvedWithinSla   TINYINT(1),
  slaReplyAlertSent   TINYINT(1) DEFAULT 0,
  slaWarningAlertSent TINYINT(1) DEFAULT 0,
  status              ENUM('open','assigned','in_progress','closed','cancelled') DEFAULT 'open',
  createdAt           DATETIME NOT NULL DEFAULT NOW(),
  INDEX idx_client (clientId, status),
  INDEX idx_sla (slaResolveDeadline, status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS ticket_replies (
  id         INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  ticketId   INT UNSIGNED NOT NULL,
  message    TEXT NOT NULL,
  isInternal TINYINT(1) DEFAULT 0,
  attachments JSON,
  sentBy     INT UNSIGNED,
  sentAt     DATETIME NOT NULL DEFAULT NOW(),
  FOREIGN KEY (ticketId) REFERENCES support_tickets(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ─────────────────────────────────────────────
-- CRM
-- ─────────────────────────────────────────────

CREATE TABLE IF NOT EXISTS crm_opportunities (
  id                INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  companyId         INT UNSIGNED NOT NULL,
  branchId          INT UNSIGNED,
  oppNumber         VARCHAR(100) UNIQUE,
  clientId          INT UNSIGNED NOT NULL,
  title             VARCHAR(300) NOT NULL,
  value             DECIMAL(15,2) DEFAULT 0,
  assignedTo        INT UNSIGNED,
  source            VARCHAR(100),
  expectedCloseDate DATE,
  stage             ENUM('prospecting','qualification','proposal','negotiation','closed_won','closed_lost') DEFAULT 'prospecting',
  probability       INT DEFAULT 10,
  lostReason        TEXT,
  notes             TEXT,
  lastAdvancedAt    DATETIME,
  createdBy         INT UNSIGNED,
  createdAt         DATETIME NOT NULL DEFAULT NOW(),
  INDEX idx_company_stage (companyId, stage)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS crm_loss_analysis (
  id        INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  companyId INT UNSIGNED NOT NULL,
  oppId     INT UNSIGNED NOT NULL,
  reason    TEXT,
  value     DECIMAL(15,2),
  competitor VARCHAR(200),
  createdAt DATETIME NOT NULL DEFAULT NOW()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS crm_kpis (
  id           INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  companyId    INT UNSIGNED NOT NULL,
  assignmentId INT UNSIGNED NOT NULL,
  metric       VARCHAR(100) NOT NULL,
  value        DECIMAL(15,2) DEFAULT 0,
  period       VARCHAR(7),
  createdAt    DATETIME NOT NULL DEFAULT NOW(),
  UNIQUE KEY uk_kpi (assignmentId, metric, period)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ─────────────────────────────────────────────
-- التواصل (ملف 09)
-- ─────────────────────────────────────────────

CREATE TABLE IF NOT EXISTS communications (
  id           INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  companyId    INT UNSIGNED NOT NULL,
  clientId     INT UNSIGNED,
  channel      ENUM('whatsapp','email','phone','web','app') NOT NULL,
  direction    ENUM('inbound','outbound') NOT NULL,
  message      TEXT,
  subject      VARCHAR(500),
  messageId    VARCHAR(200),
  department   VARCHAR(100),
  language     VARCHAR(10) DEFAULT 'ar',
  sentiment    ENUM('positive','neutral','negative','angry') DEFAULT 'neutral',
  urgency      ENUM('low','medium','high','emergency') DEFAULT 'medium',
  analysis     JSON,
  rules        JSON,
  assignedTo   INT UNSIGNED,
  firstReplyAt DATETIME,
  sentBy       INT UNSIGNED,
  status       ENUM('open','assigned','closed') DEFAULT 'open',
  receivedAt   DATETIME NOT NULL DEFAULT NOW(),
  UNIQUE KEY uk_msgid (messageId),
  INDEX idx_company_client (companyId, clientId),
  INDEX idx_status (status, receivedAt)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS pbx_calls (
  id            INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  companyId     INT UNSIGNED NOT NULL,
  callId        VARCHAR(200) UNIQUE,
  callerPhone   VARCHAR(30),
  clientId      INT UNSIGNED,
  assignedTo    INT UNSIGNED,
  duration      INT,
  isKnown       TINYINT(1) DEFAULT 0,
  aiSummary     TEXT,
  aiCommitments JSON,
  status        ENUM('ringing','active','completed','missed','voicemail') DEFAULT 'ringing',
  startedAt     DATETIME NOT NULL DEFAULT NOW(),
  endedAt       DATETIME
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS sip_accounts (
  id           INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  companyId    INT UNSIGNED NOT NULL,
  assignmentId INT UNSIGNED NOT NULL,
  sipUser      VARCHAR(100) NOT NULL,
  sipPassword  VARCHAR(100),
  extension    VARCHAR(10),
  displayName  VARCHAR(200),
  department   VARCHAR(100),
  status       ENUM('active','inactive') DEFAULT 'active',
  createdAt    DATETIME NOT NULL DEFAULT NOW(),
  UNIQUE KEY uk_sip (companyId, sipUser)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ─────────────────────────────────────────────
-- الذكاء التشغيلي
-- ─────────────────────────────────────────────

CREATE TABLE IF NOT EXISTS kpi_snapshots (
  id              INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  companyId       INT UNSIGNED NOT NULL,
  assignmentId    INT UNSIGNED NOT NULL,
  period          VARCHAR(7) NOT NULL,
  completionRate  DECIMAL(5,2),
  speedRatio      DECIMAL(5,2),
  onTimeRate      DECIMAL(5,2),
  slaRate         DECIMAL(5,2),
  avgRating       DECIMAL(3,2),
  reopenRate      DECIMAL(5,2),
  overallScore    DECIMAL(5,2),
  snapshotAt      DATETIME NOT NULL DEFAULT NOW(),
  UNIQUE KEY uk_kpi (assignmentId, period)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

SET foreign_key_checks = 1;

/**
 * seed.ts — منصة غيث ERP
 * بيانات تجريبية: شركة + فرع + مستخدم + موظف + تعيين + إعدادات
 */

import "dotenv/config";
import { rawExecute, rawQuery, closeDb } from "../../src/core/db.js";
import { hashPassword } from "../../src/core/auth.js";

async function seed() {
  console.log("🌱 بدء Seed...");

  // 1. شركة تجريبية
  const company = await rawExecute(
    `INSERT INTO companies (name, nameEn, crNumber, domain, status, createdAt)
     VALUES (?,?,?,?,?,NOW())
     ON DUPLICATE KEY UPDATE id=LAST_INSERT_ID(id)`,
    ["مجموعة الدور الحديثة", "Al-Door Modern Group", "1010123456", "aldoor.sa", "active"]
  );
  const companyId = company.insertId || 1;
  console.log(`✓ الشركة: ${companyId}`);

  // 2. فرع الرياض
  const branch = await rawExecute(
    `INSERT INTO branches (companyId, name, lat, lon, status, createdAt)
     VALUES (?,?,?,?,?,NOW())
     ON DUPLICATE KEY UPDATE id=LAST_INSERT_ID(id)`,
    [companyId, "فرع الرياض", 24.7136, 46.6753, "active"]
  );
  const branchId = branch.insertId || 1;
  console.log(`✓ الفرع: ${branchId}`);

  // 3. موظف مدير
  const emp = await rawExecute(
    `INSERT INTO employees (nationalId, name, phone, email, gender, status, createdAt)
     VALUES (?,?,?,?,?,?,NOW())
     ON DUPLICATE KEY UPDATE id=LAST_INSERT_ID(id)`,
    ["1234567890", "أحمد الدور", "0501234567", "ahmed@aldoor.sa", "male", "active"]
  );
  const employeeId = emp.insertId || 1;
  console.log(`✓ الموظف: ${employeeId}`);

  // 4. تعيين: مالك
  const assignment = await rawExecute(
    `INSERT INTO employee_assignments
       (employeeId, companyId, branchId, jobTitle, role, salary, isPrimary, hireDate, status, createdAt)
     VALUES (?,?,?,?,?,?,?,?,?,NOW())
     ON DUPLICATE KEY UPDATE id=LAST_INSERT_ID(id)`,
    [employeeId, companyId, branchId, "المدير العام", "gm", 25000, true, "2024-01-01", "active"]
  );
  const assignmentId = assignment.insertId || 1;
  console.log(`✓ التعيين: ${assignmentId}`);

  // 5. مستخدم
  const passwordHash = await hashPassword("Admin@1234");
  await rawExecute(
    `INSERT INTO users (email, passwordHash, employeeId, role, isActive, createdAt)
     VALUES (?,?,?,?,?,NOW())
     ON DUPLICATE KEY UPDATE passwordHash=VALUES(passwordHash)`,
    ["ahmed@aldoor.sa", passwordHash, employeeId, "gm", true]
  );
  console.log("✓ المستخدم: ahmed@aldoor.sa / Admin@1234");

  // 6. الإعدادات الأساسية
  const settings = [
    ["hr.lateLimitMinutes",       "15",    "number",  companyId, null],
    ["hr.deductionPerMinute",      "2",    "number",  companyId, null],
    ["hr.gpsRadiusMeters",       "200",    "number",  null,      branchId],
    ["hr.approvalTimeoutHours",   "24",    "number",  companyId, null],
    ["hr.autoApproval",         "true",   "boolean", companyId, null],
    ["finance.vatRate",           "15",    "number",  companyId, null],
    ["finance.invoiceDueDays",    "30",    "number",  companyId, null],
    ["finance.purchaseLimit",    "5000",   "number",  companyId, null],
    ["fleet.speedLimitKmh",      "120",    "number",  companyId, null],
    ["fleet.travelSpeedKmh",      "40",    "number",  companyId, null],
    ["intelligence.maxDailyTasks", "6",    "number",  companyId, null],
    ["crm.escalateDays",           "2",    "number",  companyId, null],
  ];

  for (const [key, value, dataType, cId, bId] of settings) {
    await rawExecute(
      `INSERT INTO system_settings (companyId, branchId, \`key\`, value, dataType, updatedAt)
       VALUES (?,?,?,?,?,NOW())
       ON DUPLICATE KEY UPDATE value=VALUES(value)`,
      [cId, bId, key, value, dataType]
    );
  }
  console.log(`✓ ${settings.length} إعداد`);

  // 7. عميل تجريبي
  await rawExecute(
    `INSERT INTO clients (companyId, code, name, phone, classification, source, createdAt)
     VALUES (?,?,?,?,?,?,NOW())
     ON DUPLICATE KEY UPDATE id=id`,
    [companyId, "CLT-001", "أحمد المطيري", "0551234567", "regular", "whatsapp"]
  );
  console.log("✓ عميل تجريبي");

  // 8. 3 ورديات افتراضية
  for (const [name, start, end] of [
    ["صباحية", "08:00", "16:00"],
    ["مسائية", "16:00", "00:00"],
    ["ليلية",  "00:00", "08:00"],
  ]) {
    await rawExecute(
      `INSERT INTO shifts (companyId, branchId, name, startTime, endTime, workDays, isDefault, createdAt)
       VALUES (?,?,?,?,?,?,?,NOW())
       ON DUPLICATE KEY UPDATE id=id`,
      [companyId, branchId, name, start, end, JSON.stringify([0,1,2,3,4]), name === "صباحية" ? 1 : 0]
    );
  }
  console.log("✓ 3 ورديات");

  console.log("\n✅ Seed مكتمل!");
  console.log("📧 البريد: ahmed@aldoor.sa");
  console.log("🔑 كلمة المرور: Admin@1234");
  console.log(`🏢 الشركة: ${companyId} | الفرع: ${branchId} | التعيين: ${assignmentId}`);
}

seed()
  .catch(err => { console.error("❌ Seed فشل:", err); process.exit(1); })
  .finally(() => closeDb());

/**
 * server.ts — منصة غيث ERP
 * نقطة الدخول الرئيسية
 */

import "dotenv/config";
import express from "express";
import { createExpressMiddleware } from "@trpc/server/adapters/express";
import { appRouter }   from "./routers/appRouter.js";
import { createContext } from "./core/context.js";
import { checkDbConnection } from "./core/db.js";
import { registerCronJobs }  from "./cron/scheduler.js";

const app  = express();
const PORT = Number(process.env.PORT) || 3000;

app.use(express.json());

// ─── tRPC ────────────────────────────────────

app.use(
  "/api/trpc",
  createExpressMiddleware({
    router:     appRouter,
    createContext: ({ req, res }) => createContext(req),
  })
);

// ─── Health check ─────────────────────────────

app.get("/health", async (_, res) => {
  const dbOk = await checkDbConnection();
  res.json({
    status: dbOk ? "ok" : "degraded",
    db:     dbOk ? "connected" : "error",
    ts:     new Date().toISOString(),
  });
});

// ─── WhatsApp Webhook ─────────────────────────

app.get("/webhook/whatsapp", (req, res) => {
  const mode      = req.query["hub.mode"];
  const token     = req.query["hub.verify_token"];
  const challenge = req.query["hub.challenge"];
  if (mode === "subscribe" && token === process.env.WHATSAPP_VERIFY_TOKEN) {
    res.status(200).send(challenge);
  } else {
    res.sendStatus(403);
  }
});

// ─── Start ────────────────────────────────────

async function start() {
  const dbOk = await checkDbConnection();
  if (!dbOk) {
    console.error("❌ فشل الاتصال بقاعدة البيانات");
    process.exit(1);
  }
  console.log("✅ قاعدة البيانات متصلة");

  registerCronJobs();
  console.log("✅ وظائف Cron مسجلة");

  app.listen(PORT, () => {
    console.log(`🚀 غيث ERP يعمل على http://localhost:${PORT}`);
    console.log(`📡 tRPC: http://localhost:${PORT}/api/trpc`);
  });
}

start();

process.on("SIGTERM", async () => {
  console.log("إيقاف السيرفر...");
  const { closeDb } = await import("./core/db.js");
  await closeDb();
  process.exit(0);
});

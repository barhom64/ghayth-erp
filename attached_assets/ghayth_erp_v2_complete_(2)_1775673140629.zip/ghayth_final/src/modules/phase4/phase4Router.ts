/**
 * phase4Router.ts — منصة غيث ERP
 * تجميع كل راوترات المرحلة 4
 */

import { router } from "../../core/trpc.js";
import { fleetRouter }               from "./fleetEngine";
import { warehouseRouter }           from "./warehouseEngine";
import { propertiesRouter }          from "./propertiesEngine";
import { legalRouter }               from "./legalEngine";
import { projectsSupportCrmRouter }  from "./projectsSupportCrmEngine";

// استيراد معالجات الأحداث (تُسجَّل تلقائياً عند الاستيراد)
import "./phase4EventHandlers";

export const phase4Router = router({
  fleet:    fleetRouter,
  warehouse: warehouseRouter,
  properties: propertiesRouter,
  legal:    legalRouter,
  projects: projectsSupportCrmRouter,
});

// ── إضافة في appRouter الرئيسي:
// import { phase4Router } from "./phase4Router";
// export const appRouter = router({
//   ...existingRouters,
//   fleet:      phase4Router.fleet,
//   warehouse:  phase4Router.warehouse,
//   properties: phase4Router.properties,
//   legal:      phase4Router.legal,
//   projects:   phase4Router.projects,
// });

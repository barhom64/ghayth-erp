/**
 * phase4CronJobs.ts — منصة غيث ERP
 * المرجع: ملف 08 — الأتمتة الشاملة
 * وظائف Cron للمرحلة 4: أسطول + مستودعات + أملاك + قانونية + مشاريع + دعم + CRM
 */

import { db } from "../../core/db.js";
import { checkMinStockLevels } from "./warehouseEngine";

// ─────────────────────────────────────────────
// مساعد: جلب كل الشركات النشطة
// ─────────────────────────────────────────────

async function getActiveCompanies(): Promise<Array<{ id: number; branchId: number }>> {
  return db.query(`
    SELECT c.id, b.id AS branchId
    FROM companies c
    JOIN branches b ON b.companyId = c.id AND b.status = 'active'
    WHERE c.status = 'active'
  `);
}

// ─────────────────────────────────────────────
// Cron #3 — 6 صباحاً: أسطول (صيانة + تأمين + رخص)
// ─────────────────────────────────────────────

export async function cronFleetAlerts() {
  const companies = await getActiveCompanies();
  let total = 0;

  for (const { id: companyId } of companies) {
    // تأمين ينتهي 90، 30، 14، 7 يوم
    for (const days of [90, 30, 14, 7]) {
      const expiring = await db.query(`
        SELECT v.id, v.plate, i.expiresAt
        FROM fleet_vehicles v
        JOIN fleet_insurance i ON i.vehicleId = v.id AND i.status = 'active'
        WHERE v.companyId=?
          AND DATEDIFF(i.expiresAt, NOW()) = ?
      `, [companyId, days]);

      for (const v of expiring) {
        await db.execute(`
          INSERT INTO notifications (companyId, type, title, body, targetRole, createdAt)
          VALUES (?,'insurance_expiry','تأمين مركبة',
            CONCAT(?,': ينتهي بعد ',?' يوم'),'fleet_manager',NOW())
        `, [companyId, v.plate, days]);
        total++;
      }
    }

    // تأمين انتهى اليوم = حظر فوري
    await db.execute(`
      UPDATE fleet_vehicles v
      JOIN fleet_insurance i ON i.vehicleId = v.id AND i.status = 'active'
      SET v.status = 'suspended'
      WHERE v.companyId=? AND DATE(i.expiresAt) = CURDATE()
    `, [companyId]);

    // رخصة سائق تنتهي 30، 14، 7 يوم
    for (const days of [30, 14, 7]) {
      const expiring = await db.query(`
        SELECT id, name, licenseExpiry
        FROM fleet_drivers
        WHERE companyId=? AND DATEDIFF(licenseExpiry, NOW()) = ?
      `, [companyId, days]);

      for (const d of expiring) {
        await db.execute(`
          INSERT INTO notifications (companyId, type, title, body, targetRole, createdAt)
          VALUES (?,'license_expiry','رخصة سائق',
            CONCAT(?,': ينتهي بعد ',?' يوم'),'fleet_manager',NOW())
        `, [companyId, d.name, days]);
        total++;
      }
    }

    // رخصة سائق انتهت = حظر قيادة
    await db.execute(`
      UPDATE fleet_drivers
      SET status='suspended'
      WHERE companyId=? AND licenseExpiry < NOW() AND status='available'
    `, [companyId]);

    // صيانة دورية تستحق خلال 7 أيام
    const maintenanceDue = await db.query(`
      SELECT id, plate, nextMaintenanceDate
      FROM fleet_vehicles
      WHERE companyId=? AND status != 'suspended'
        AND DATEDIFF(nextMaintenanceDate, NOW()) = 7
    `, [companyId]);

    for (const v of maintenanceDue) {
      await db.execute(`
        INSERT INTO notifications (companyId, type, title, body, targetRole, createdAt)
        VALUES (?,'maintenance_due','صيانة دورية',
          CONCAT(?,': موعد الصيانة بعد 7 أيام'),'fleet_manager',NOW())
      `, [companyId, v.plate]);
      total++;
    }
  }

  console.log(`[Cron #3] Fleet alerts: ${total} تنبيه`);
  return total;
}

// ─────────────────────────────────────────────
// Cron #10 — يومياً: استهلاك وقود > 120%
// ─────────────────────────────────────────────

export async function cronFuelAnomalies() {
  const companies = await getActiveCompanies();
  let total = 0;

  for (const { id: companyId } of companies) {
    const anomalies = await db.query(`
      SELECT v.id, v.plate, v.normalConsumptionPer100,
        (SUM(f.litersFilled) / NULLIF(SUM(t.actualDistanceKm), 0) * 100) AS actualConsumption
      FROM fleet_vehicles v
      LEFT JOIN fleet_fuel_logs f ON f.vehicleId=v.id
        AND f.createdAt > DATE_SUB(NOW(), INTERVAL 7 DAY)
      LEFT JOIN fleet_trips t ON t.vehicleId=v.id AND t.status='completed'
        AND t.completedAt > DATE_SUB(NOW(), INTERVAL 7 DAY)
      WHERE v.companyId=?
      GROUP BY v.id
      HAVING actualConsumption > v.normalConsumptionPer100 * 1.2
    `, [companyId]);

    for (const a of anomalies) {
      await db.execute(`
        INSERT INTO notifications (companyId, type, title, body, targetRole, createdAt)
        VALUES (?,'fuel_anomaly','استهلاك وقود غير طبيعي',
          CONCAT(?,': ',ROUND(?),?' لتر/100كم بدلاً من ',?),
          'fleet_manager',NOW())
      `, [companyId, a.plate, a.actualConsumption, a.normalConsumptionPer100]);

      await db.execute(`
        INSERT INTO tasks (companyId, type, title, priority, status, createdAt)
        VALUES (?,'inspection',CONCAT('فحص استهلاك وقود — ',?),'high','pending',NOW())
      `, [companyId, a.plate]);

      total++;
    }
  }

  console.log(`[Cron #10] Fuel anomalies: ${total}`);
  return total;
}

// ─────────────────────────────────────────────
// Cron #11 — يومياً: حد أدنى مخزون
// ─────────────────────────────────────────────

export async function cronWarehouseMinStock() {
  const companies = await getActiveCompanies();
  let total = 0;

  for (const { id: companyId, branchId } of companies) {
    const results = await checkMinStockLevels(companyId, branchId);
    total += results.length;
  }

  console.log(`[Cron #11] Low stock items: ${total}`);
  return total;
}

// ─────────────────────────────────────────────
// Cron #12 — يومياً: عقود إيجار
// ─────────────────────────────────────────────

export async function cronRentalContracts() {
  const companies = await getActiveCompanies();
  let total = 0;

  for (const { id: companyId } of companies) {
    // إيجارات مستحقة اليوم ولم تُدفع
    const overdueRents = await db.query(`
      SELECT rc.id, rc.clientId, rc.unitId, rc.amount, rc.nextPaymentDate,
        u.unitNumber, cl.name AS tenantName,
        DATEDIFF(NOW(), rc.nextPaymentDate) AS daysLate
      FROM rental_contracts rc
      JOIN property_units u ON u.id = rc.unitId
      JOIN clients cl ON cl.id = rc.clientId
      WHERE rc.companyId=?
        AND rc.status IN ('active', 'overdue')
        AND rc.nextPaymentDate < NOW()
        AND rc.lastPaymentDate < rc.nextPaymentDate
    `, [companyId]);

    for (const rent of overdueRents) {
      const days = rent.daysLate;

      if (days === 1) {
        await db.execute(`
          INSERT INTO sms_queue (companyId, clientId, message, scheduledAt)
          VALUES (?,?,CONCAT('تذكير: إيجار ',?,' مستحق منذ أمس — يرجى السداد'),NOW())
        `, [companyId, rent.clientId, rent.unitNumber]);
        total++;
      }

      // تحديث حالة العقد
      await db.execute(`
        UPDATE rental_contracts SET status='overdue', daysLate=? WHERE id=?
      `, [days, rent.id]);
    }

    // عقود تنتهي 90، 30، 14 يوم
    for (const days of [90, 30, 14]) {
      const expiring = await db.query(`
        SELECT rc.id, u.unitNumber, cl.name AS tenantName, rc.endDate
        FROM rental_contracts rc
        JOIN property_units u ON u.id = rc.unitId
        JOIN clients cl ON cl.id = rc.clientId
        WHERE rc.companyId=?
          AND DATEDIFF(rc.endDate, NOW()) = ?
          AND rc.status='active'
      `, [companyId, days]);

      for (const c of expiring) {
        await db.execute(`
          INSERT INTO notifications (companyId, type, title, body, targetRole, createdAt)
          VALUES (?,'contract_expiry','عقد إيجار ينتهي',
            CONCAT(?,': ',?,' — ينتهي بعد ',?' يوم'),'property_manager',NOW())
        `, [companyId, c.unitNumber, c.tenantName, days]);
        total++;
      }
    }
  }

  console.log(`[Cron #12] Rental contracts: ${total}`);
  return total;
}

// ─────────────────────────────────────────────
// Cron #13 — يومياً: عقود قانونية + جلسات
// ─────────────────────────────────────────────

export async function cronLegalAlerts() {
  const companies = await getActiveCompanies();
  let total = 0;

  for (const { id: companyId } of companies) {
    // عقود تنتهي
    for (const days of [90, 30, 14, 7]) {
      const expiring = await db.query(`
        SELECT contractNumber, title
        FROM legal_contracts
        WHERE companyId=? AND DATEDIFF(endDate, NOW()) = ? AND status='active'
      `, [companyId, days]);

      for (const c of expiring) {
        await db.execute(`
          INSERT INTO notifications (companyId, type, title, body, targetRole, createdAt)
          VALUES (?,'contract_expiry','عقد قانوني ينتهي',
            CONCAT(?,': بعد ',?' يوم'),'legal_manager',NOW())
        `, [companyId, c.contractNumber, days]);
        total++;
      }
    }

    // جلسات غداً
    const tomorrowSessions = await db.query(`
      SELECT ls.id, ls.caseId, ls.courtName, ls.sessionDate,
        lc.caseNumber, lc.assignedLawyerId
      FROM legal_sessions ls
      JOIN legal_cases lc ON lc.id = ls.caseId
      WHERE ls.companyId=?
        AND DATE(ls.sessionDate) = DATE_ADD(CURDATE(), INTERVAL 1 DAY)
        AND ls.status = 'scheduled'
        AND ls.tomorrowAlertSent = 0
    `, [companyId]);

    for (const s of tomorrowSessions) {
      await db.execute(`
        INSERT INTO notifications (companyId, assignmentId, type, title, body, createdAt)
        VALUES (?,?,'session_tomorrow','جلسة محكمة غداً',
          CONCAT(?,': ',?,' الساعة ',?),NOW())
      `, [
        companyId, s.assignedLawyerId,
        s.caseNumber, s.courtName,
        new Date(s.sessionDate).toLocaleTimeString("ar"),
      ]);
      await db.execute(`UPDATE legal_sessions SET tomorrowAlertSent=1 WHERE id=?`, [s.id]);
      total++;
    }
  }

  console.log(`[Cron #13] Legal alerts: ${total}`);
  return total;
}

// ─────────────────────────────────────────────
// Cron #14 — يومياً: مهام مشاريع متأخرة
// ─────────────────────────────────────────────

export async function cronProjectDelays() {
  const companies = await getActiveCompanies();
  let total = 0;

  for (const { id: companyId } of companies) {
    // مهام متأخرة في المشاريع
    const delayedTasks = await db.query(`
      SELECT t.id, t.title, t.assignedTo, t.scheduledStart,
        p.name AS projectName, p.budget, p.budgetUsed,
        TIMESTAMPDIFF(HOUR, t.scheduledStart, NOW()) AS delayHours
      FROM tasks t
      JOIN project_task_phases ptp ON ptp.taskId = t.id
      JOIN project_phases pp ON pp.id = ptp.phaseId
      JOIN projects p ON p.id = pp.projectId
      WHERE t.companyId=?
        AND t.status IN ('pending','in_progress')
        AND t.scheduledStart < NOW()
        AND p.status != 'completed'
    `, [companyId]);

    for (const t of delayedTasks) {
      // حساب الأثر المالي للتأخر
      const delayDays = Math.ceil(t.delayHours / 24);
      const financialImpact = delayDays > 0
        ? `تأخر ${delayDays} يوم — أثر مالي محتمل`
        : null;

      await db.execute(`
        INSERT INTO notifications (companyId, assignmentId, type, title, body, createdAt)
        VALUES (?,?,'task_delayed','مهمة متأخرة',
          CONCAT(?,': ',?,' متأخرة ',?,' ساعة',COALESCE(CONCAT(' — ',?),'')  ),NOW())
      `, [companyId, t.assignedTo, t.projectName, t.title, t.delayHours, financialImpact]);

      total++;
    }
  }

  console.log(`[Cron #14] Project delays: ${total}`);
  return total;
}

// ─────────────────────────────────────────────
// Cron #15 — يومياً: تذكير متابعات CRM
// ─────────────────────────────────────────────

export async function cronCrmFollowups() {
  const companies = await getActiveCompanies();
  let total = 0;

  for (const { id: companyId } of companies) {
    const overdueFollowups = await db.query(`
      SELECT o.id, o.oppNumber, o.title, o.assignedTo, o.stage,
        DATEDIFF(NOW(), t.scheduledDate) AS daysOverdue
      FROM crm_opportunities o
      JOIN tasks t ON t.refType='crm_opportunity' AND t.refId=o.id
        AND t.type='crm_followup' AND t.status='pending'
      WHERE o.companyId=?
        AND o.stage NOT IN ('closed_won','closed_lost')
        AND t.scheduledDate < NOW()
    `, [companyId]);

    for (const opp of overdueFollowups) {
      if (opp.daysOverdue >= 2) {
        // تصعيد لمدير المبيعات
        await db.execute(`
          INSERT INTO notifications (companyId, type, title, body, targetRole, createdAt)
          VALUES (?,'crm_escalation','تصعيد متابعة',
            CONCAT(?,': لم تُتابع منذ ',?,' أيام'),'sales_manager',NOW())
        `, [companyId, opp.oppNumber, opp.daysOverdue]);
      } else {
        await db.execute(`
          INSERT INTO notifications (companyId, assignmentId, type, title, body, createdAt)
          VALUES (?,?,'followup_due','متابعة CRM مستحقة',
            CONCAT(?,': ',?),NOW())
        `, [companyId, opp.assignedTo, opp.oppNumber, opp.title]);
      }
      total++;
    }
  }

  console.log(`[Cron #15] CRM followups: ${total}`);
  return total;
}

// ─────────────────────────────────────────────
// Cron #16 — يومياً: مهام متأخرة عن SLA
// ─────────────────────────────────────────────

export async function cronSlaBreaches() {
  const companies = await getActiveCompanies();
  let total = 0;

  for (const { id: companyId } of companies) {
    const breaches = await db.query(`
      SELECT t.id, t.title, t.assignedTo, t.refType, t.refId,
        TIMESTAMPDIFF(MINUTE, t.slaDeadline, NOW()) AS overdueMin
      FROM tasks t
      WHERE t.companyId=?
        AND t.slaDeadline IS NOT NULL
        AND t.slaDeadline < NOW()
        AND t.status NOT IN ('completed','cancelled')
        AND t.slaBreachNotified = 0
    `, [companyId]);

    for (const t of breaches) {
      await db.execute(`
        INSERT INTO notifications (companyId, assignmentId, type, title, body, createdAt)
        VALUES (?,?,'sla_breach','تجاوز SLA',
          CONCAT(?,': تأخر ',?,' دقيقة عن الموعد'),NOW())
      `, [companyId, t.assignedTo, t.title, t.overdueMin]);

      // إشعار المدير
      await db.execute(`
        INSERT INTO notifications (companyId, type, title, body, targetRole, createdAt)
        VALUES (?,'sla_breach_manager','تجاوز SLA',
          CONCAT(?,': تأخر ',?,' دقيقة'),'manager',NOW())
      `, [companyId, t.title, t.overdueMin]);

      await db.execute(`UPDATE tasks SET slaBreachNotified=1 WHERE id=?`, [t.id]);
      total++;
    }
  }

  console.log(`[Cron #16] SLA breaches: ${total}`);
  return total;
}

// ─────────────────────────────────────────────
// Cron #17 — يوم 1 كل شهر: إيجارات متأخرة + غرامة
// ─────────────────────────────────────────────

export async function cronMonthlyRentProcessing() {
  const companies = await getActiveCompanies();
  let total = 0;

  for (const { id: companyId } of companies) {
    // غرامة على الإيجارات المتأخرة 5 أيام فأكثر
    const overdueRents = await db.query(`
      SELECT rc.id, rc.clientId, rc.amount, rc.unitId,
        u.unitNumber, DATEDIFF(NOW(), rc.nextPaymentDate) AS daysLate
      FROM rental_contracts rc
      JOIN property_units u ON u.id = rc.unitId
      WHERE rc.companyId=?
        AND rc.status = 'overdue'
        AND DATEDIFF(NOW(), rc.nextPaymentDate) >= 5
        AND NOT EXISTS (
          SELECT 1 FROM late_rent_penalties lrp
          WHERE lrp.contractId=rc.id
            AND MONTH(lrp.createdAt)=MONTH(NOW())
            AND YEAR(lrp.createdAt)=YEAR(NOW())
        )
    `, [companyId]);

    const penaltyRate = 0.02; // 2%
    for (const rent of overdueRents) {
      const penalty = +(rent.amount * penaltyRate).toFixed(2);
      await db.execute(`
        INSERT INTO late_rent_penalties
          (companyId, contractId, clientId, amount, reason, createdAt)
        VALUES (?,?,?,?,'غرامة تأخير إيجار شهرية',NOW())
      `, [companyId, rent.id, rent.clientId, penalty]);

      await db.execute(`
        INSERT INTO sms_queue (companyId, clientId, message, scheduledAt)
        VALUES (?,?,CONCAT('إشعار: تمت إضافة غرامة تأخير ',?,' ريال على إيجار ',?),NOW())
      `, [companyId, rent.clientId, penalty, rent.unitNumber]);

      total++;
    }
  }

  console.log(`[Cron #17] Monthly rent penalties: ${total}`);
  return total;
}

// ─────────────────────────────────────────────
// تسجيل جميع وظائف Cron
// ─────────────────────────────────────────────

export const phase4CronSchedule = [
  { name: "cronFleetAlerts",          time: "0 6 * * *",  fn: cronFleetAlerts },
  { name: "cronFuelAnomalies",        time: "0 20 * * *", fn: cronFuelAnomalies },
  { name: "cronWarehouseMinStock",    time: "0 7 * * *",  fn: cronWarehouseMinStock },
  { name: "cronRentalContracts",      time: "0 7 * * *",  fn: cronRentalContracts },
  { name: "cronLegalAlerts",          time: "0 6 * * *",  fn: cronLegalAlerts },
  { name: "cronProjectDelays",        time: "0 8 * * *",  fn: cronProjectDelays },
  { name: "cronCrmFollowups",         time: "0 9 * * *",  fn: cronCrmFollowups },
  { name: "cronSlaBreaches",          time: "0 * * * *",  fn: cronSlaBreaches },      // كل ساعة
  { name: "cronMonthlyRentProcessing",time: "0 8 1 * *",  fn: cronMonthlyRentProcessing },
];

export default { cronFleetAlerts: cronFleetAlerts ?? function(){}, cronFuelAnomalies: cronFuelAnomalies ?? function(){}, cronWarehouseMinStock: cronWarehouseMinStock ?? function(){}, cronRentalContracts: cronRentalContracts ?? function(){}, cronLegalAlerts: cronLegalAlerts ?? function(){}, cronProjectDelays: cronProjectDelays ?? function(){}, cronCrmFollowups: cronCrmFollowups ?? function(){}, cronSlaBreaches: cronSlaBreaches ?? function(){}, cronMonthlyRentProcessing: cronMonthlyRentProcessing ?? function(){} };

/**
 * propertiesEngine.ts — منصة غيث ERP
 * المرجع: ملف 05 — الأملاك
 * بلاغ صيانة من العميل 12 خطوة مع Load Balancing
 * إيجار متأخر 6 مراحل
 */

import { z } from "zod";
import { scopedProcedure, router } from "../../core/trpc.js";
import { db } from "../../core/db.js";
import { eventBus } from "../../core/eventBus.js";
import { auditLogger } from "../../core/eventBus.js";
import { getSetting } from "../../core/eventBus.js";

// ─────────────────────────────────────────────
// الثوابت
// ─────────────────────────────────────────────

// كلمات تدل على الطوارئ لتحديد الأولوية تلقائياً
const EMERGENCY_KEYWORDS = [
  "تسرب", "اشتعال", "حريق", "غرق", "كهرباء", "صدمة", "انفجار",
  "عطل كامل", "بغزارة", "شديد", "خطر"
];

const SLA_BY_PRIORITY: Record<string, number> = {
  emergency: 2,   // ساعتان
  high: 4,        // 4 ساعات
  medium: 24,     // 24 ساعة
  low: 72,        // 72 ساعة
};

// ─────────────────────────────────────────────
// تحديد الأولوية من نص البلاغ
// ─────────────────────────────────────────────

function detectPriority(description: string): "emergency" | "high" | "medium" | "low" {
  const lower = description.toLowerCase();
  const emergencyHits = EMERGENCY_KEYWORDS.filter(k => lower.includes(k));
  if (emergencyHits.length >= 2) return "emergency";
  if (emergencyHits.length === 1) return "high";
  if (lower.includes("متوسط") || lower.includes("يحتاج") || lower.includes("إصلاح")) return "medium";
  return "low";
}

// ─────────────────────────────────────────────
// خوارزمية Haversine
// ─────────────────────────────────────────────

function haversineKm(lat1: number, lon1: number, lat2: number, lon2: number): number {
  const R = 6371;
  const dLat = ((lat2 - lat1) * Math.PI) / 180;
  const dLon = ((lon2 - lon1) * Math.PI) / 180;
  const a =
    Math.sin(dLat / 2) ** 2 +
    Math.cos((lat1 * Math.PI) / 180) *
    Math.cos((lat2 * Math.PI) / 180) *
    Math.sin(dLon / 2) ** 2;
  return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
}

// ─────────────────────────────────────────────
// Load Balancing للفنيين
// المعادلة: مهام 40% + مسافة 30% + تخصص 20% + تقييم 10%
// ─────────────────────────────────────────────

interface TechnicianCandidate {
  techId: number;
  name: string;
  assignmentId: number;
  activeTasks: number;
  distanceKm: number;
  hasSpecialty: boolean; // لديه تخصص في نوع البلاغ
  rating: number;
  lat: number;
  lon: number;
}

function loadBalanceTechnician(candidates: TechnicianCandidate[]): TechnicianCandidate & { score: number } {
  const maxDist = Math.max(...candidates.map(c => c.distanceKm)) || 1;
  const scored = candidates.map(c => {
    const taskScore = Math.max(0, ((6 - c.activeTasks) / 6) * 100);
    const distScore = ((maxDist - c.distanceKm) / maxDist) * 100;
    const specialtyScore = c.hasSpecialty ? 100 : 0;
    const ratingScore = (c.rating / 5) * 100;
    const total = taskScore * 0.4 + distScore * 0.3 + specialtyScore * 0.2 + ratingScore * 0.1;
    return { ...c, score: +total.toFixed(1) };
  });
  scored.sort((a, b) => b.score - a.score);
  return scored[0];
}

// ─────────────────────────────────────────────
// Moving Average — تقدير مدة العمل
// ─────────────────────────────────────────────

async function estimateDuration(db: any, taskType: string, companyId: number): Promise<number> {
  const defaults: Record<string, number> = {
    plumbing: 75, electrical: 60, ac: 90, carpentry: 120, painting: 180, general: 60,
  };

  const [result] = await db.query(`
    SELECT AVG(actualDuration) AS avg, COUNT(*) AS cnt
    FROM tasks
    WHERE companyId=? AND type=? AND status='completed'
      AND actualDuration IS NOT NULL
      AND completedAt > DATE_SUB(NOW(), INTERVAL 30 DAY)
  `, [companyId, taskType]);

  if (result?.[0]?.cnt >= 10) {
    return Math.round(result[0].avg);
  }
  return defaults[taskType] || defaults.general;
}

// ─────────────────────────────────────────────
// سيناريو بلاغ صيانة — 12 خطوة
// ─────────────────────────────────────────────

export const propertiesRouter = router({

  submitMaintenanceRequest: scopedProcedure
    .input(z.object({
      unitId: z.number(),       // معرف الوحدة العقارية
      clientId: z.number(),
      category: z.string(),     // plumbing | electrical | ac | carpentry | general
      description: z.string(),
      reportedVia: z.enum(["portal", "whatsapp", "phone", "app"]),
      photos: z.array(z.string()).optional(),
    }))
    .mutation(async ({ input, ctx }) => {
      const { companyId, branchId, userId } = ctx.scope;

      // ── خطوة 1: حفظ البلاغ ──────────────────────────────
      const mrNumber = `MR-${companyId}-${Date.now().toString(36).toUpperCase()}`;

      const [mrResult] = await db.execute(`
        INSERT INTO maintenance_requests
          (companyId, branchId, unitId, clientId, category, description,
           reportedVia, photos, status, mrNumber, createdAt)
        VALUES (?,?,?,?,?,?, ?,?,  'new',?,NOW())
      `, [
        companyId, branchId, input.unitId, input.clientId,
        input.category, input.description,
        input.reportedVia, JSON.stringify(input.photos || []),
        mrNumber,
      ]);
      const mrId = (mrResult as any).insertId;

      // ── خطوة 2: تحديد أولوية تلقائية ───────────────────
      const priority = detectPriority(input.description);

      // ── خطوة 3: حساب SLA ────────────────────────────────
      const slaHours = SLA_BY_PRIORITY[priority];
      const slaDeadline = new Date(Date.now() + slaHours * 3600000);

      await db.execute(`
        UPDATE maintenance_requests
        SET priority=?, slaDeadline=? WHERE id=?
      `, [priority, slaDeadline, mrId]);

      // ── خطوة 4: حساب المسافة للعقار ─────────────────────
      const [units] = await db.query(`
        SELECT u.*, b.lat AS branchLat, b.lon AS branchLon
        FROM property_units u
        JOIN branches b ON b.id = u.branchId
        WHERE u.id=?
      `, [input.unitId]);

      const unit = units[0];
      const distanceKm = haversineKm(
        unit.branchLat, unit.branchLon,
        unit.lat, unit.lon
      );
      const travelMin = Math.round((distanceKm / 40) * 60);

      // ── خطوة 5: تقدير مدة العمل (Moving Average) ─────────
      const estimatedWorkMin = await estimateDuration(db, input.category, companyId);

      // ── خطوة 6: اختيار أفضل فني (Load Balancing) ────────
      const techRows = await db.query(`
        SELECT
          t.id AS techId, t.name,
          t.rating, t.lat, t.lon, t.assignmentId,
          COUNT(tk.id) AS activeTasks,
          (t.specialties LIKE CONCAT('%', ?, '%')) AS hasSpecialty
        FROM technicians t
        LEFT JOIN tasks tk ON tk.assignedTo = t.assignmentId
          AND tk.scheduledDate = CURDATE()
          AND tk.status IN ('pending','in_progress')
        WHERE t.companyId=? AND t.branchId=?
          AND t.status = 'available'
        GROUP BY t.id
      `, [input.category, companyId, branchId]);

      if (!techRows.length) throw new Error("لا يوجد فني متاح");

      const candidates: TechnicianCandidate[] = techRows.map((r: any) => ({
        techId: r.techId,
        name: r.name,
        assignmentId: r.assignmentId,
        activeTasks: +r.activeTasks,
        distanceKm: haversineKm(r.lat, r.lon, unit.lat, unit.lon),
        hasSpecialty: !!r.hasSpecialty,
        rating: +r.rating || 4,
        lat: r.lat,
        lon: r.lon,
      }));

      const bestTech = loadBalanceTechnician(candidates);

      // ── خطوة 7: جدولة المهمة في تقويم الفني ─────────────
      // بعد انتهاء مهمته الحالية + وقت التنقل
      const [lastTask] = await db.query(`
        SELECT MAX(scheduledStart + INTERVAL estimatedDuration MINUTE) AS nextFreeSlot
        FROM tasks
        WHERE assignedTo=? AND scheduledDate=CURDATE()
          AND status IN ('pending','in_progress')
      `, [bestTech.assignmentId]);

      const nextFreeSlot = lastTask?.[0]?.nextFreeSlot
        ? new Date(lastTask[0].nextFreeSlot)
        : new Date();

      const scheduledStart = new Date(nextFreeSlot.getTime() + travelMin * 60000);
      const scheduledEnd = new Date(scheduledStart.getTime() + estimatedWorkMin * 60000);

      await db.execute(`
        INSERT INTO tasks
          (companyId, branchId, assignedTo, type, refType, refId,
           title, scheduledStart, scheduledEnd, estimatedDuration,
           clientId, lat, lon, priority, slaDeadline, status, createdAt)
        VALUES (?,?,?,?,?,?, ?,?,?,?, ?,?,?,?,?,'pending',NOW())
      `, [
        companyId, branchId, bestTech.assignmentId,
        'maintenance', 'maintenance_request', mrId,
        `${input.category} — ${unit.unitNumber}`,
        scheduledStart, scheduledEnd, estimatedWorkMin + travelMin,
        input.clientId, unit.lat, unit.lon,
        priority, slaDeadline,
      ]);

      // تحديث البلاغ بالفني والجدول
      await db.execute(`
        UPDATE maintenance_requests
        SET assignedTechId=?, scheduledStart=?,
            distanceKm=?, travelMin=?,
            status='assigned'
        WHERE id=?
      `, [bestTech.techId, scheduledStart, distanceKm, travelMin, mrId]);

      // ── خطوة 8: إشعار مدير الأملاك والمدير العام ─────────
      const notifBody = `بلاغ ${mrNumber} — ${input.category} — ${unit.unitNumber} — أولوية: ${priority} — الفني: ${bestTech.name} — SLA: ${slaDeadline.toLocaleTimeString("ar")}`;

      await db.execute(`
        INSERT INTO notifications (companyId, assignmentId, type, title, body, actions, createdAt)
        SELECT ?, ea.id, 'maintenance_assigned', 'بلاغ صيانة جديد', ?, '["approve","change_tech"]', NOW()
        FROM employee_assignments ea
        WHERE ea.companyId=? AND ea.role IN ('property_manager','gm') AND ea.status='active'
      `, [companyId, notifBody, companyId]);

      // ── خطوة 9: إشعار الفني ──────────────────────────────
      await db.execute(`
        INSERT INTO notifications (companyId, assignmentId, type, title, body, createdAt)
        VALUES (?,?,'task_assigned','مهمة جديدة',
          CONCAT(?, ' — ', ?, ' كم — الوصول ', ?, ' — SLA ', ?),
          NOW())
      `, [
        companyId, bestTech.assignmentId,
        input.description.slice(0, 50),
        distanceKm.toFixed(1),
        scheduledStart.toLocaleTimeString("ar"),
        slaDeadline.toLocaleTimeString("ar"),
      ]);

      // ── خطوة 10: SMS وواتساب للمستأجر ───────────────────
      await db.execute(`
        INSERT INTO sms_queue (companyId, clientId, message, scheduledAt)
        VALUES (?,?,CONCAT('تم استلام بلاغك ',?,' — الفني ',?' يصل ',?,' — رابط تتبع: https://track.door.sa/mr/?id=',?),NOW())
      `, [
        companyId, input.clientId,
        mrNumber, bestTech.name,
        scheduledStart.toLocaleTimeString("ar"), mrId,
      ]);

      // ── خطوة 11 + 12: تُنفَّذ عند إنهاء المهمة ────────────
      // (في completeMaintenance أدناه)

      await auditLogger.log({
        companyId, branchId, userId,
        action: "MAINTENANCE_REQUEST_CREATED",
        entity: "maintenance_requests",
        entityId: mrId,
        after: { mrId, mrNumber, priority, slaDeadline, techId: bestTech.techId },
        reason: "بلاغ صيانة جديد",
      });

      eventBus.emit("MAINTENANCE_REQUESTED", {
        mrId, mrNumber, priority, clientId: input.clientId,
        unitId: input.unitId, companyId, branchId,
        techId: bestTech.techId,
      });

      return {
        mrId, mrNumber, priority, slaDeadline,
        technician: { id: bestTech.techId, name: bestTech.name, score: bestTech.score },
        scheduledStart,
        distanceKm: +distanceKm.toFixed(1),
        estimatedWorkMin,
      };
    }),

  // ── إنهاء البلاغ (خطوة 11 + 12) ─────────────────────────
  completeMaintenance: scopedProcedure
    .input(z.object({
      mrId: z.number(),
      actualDurationMin: z.number(),
      partsUsed: z.array(z.object({ name: z.string(), cost: z.number() })).optional(),
      laborCost: z.number(),
      photoUrls: z.array(z.string()),
      notes: z.string().optional(),
    }))
    .mutation(async ({ input, ctx }) => {
      const { companyId, branchId, userId } = ctx.scope;

      const [mrs] = await db.query(`
        SELECT mr.*, u.lat, u.lon
        FROM maintenance_requests mr
        JOIN property_units u ON u.id = mr.unitId
        WHERE mr.id=? AND mr.companyId=?
      `, [input.mrId, companyId]);

      if (!mrs.length) throw new Error("البلاغ غير موجود");
      const mr = mrs[0];

      const partsCost = (input.partsUsed || []).reduce((s, p) => s + p.cost, 0);
      const totalCost = partsCost + input.laborCost;
      const withinSla = new Date() <= new Date(mr.slaDeadline);

      // ── خطوة 11: الفني ينهي المهمة ─────────────────────
      await db.execute(`
        UPDATE maintenance_requests
        SET status='completed', completedAt=NOW(),
            actualDurationMin=?, totalCost=?,
            partsUsed=?, laborCost=?,
            completionPhotos=?, completionNotes=?,
            completedWithinSla=?
        WHERE id=? AND companyId=?
      `, [
        input.actualDurationMin, totalCost,
        JSON.stringify(input.partsUsed || []), input.laborCost,
        JSON.stringify(input.photoUrls), input.notes || null,
        withinSla ? 1 : 0,
        input.mrId, companyId,
      ]);

      // تحديث المهمة
      await db.execute(`
        UPDATE tasks SET status='completed', completedAt=NOW(),
          actualDuration=? WHERE refType='maintenance_request' AND refId=?
      `, [input.actualDurationMin, input.mrId]);

      // ── خطوة 12: بعد الإنهاء ──────────────────────────────

      // SMS للعميل + رابط تقييم
      await db.execute(`
        INSERT INTO sms_queue (companyId, clientId, message, scheduledAt)
        VALUES (?,?,CONCAT('تم إنجاز بلاغك ',?,' ✓ قيّم الخدمة: https://rate.door.sa/mr/?id=',?),NOW())
      `, [companyId, mr.clientId, mr.mrNumber, input.mrId]);

      // تحديث KPI الفني
      await db.execute(`
        UPDATE technicians
        SET completedTasks = completedTasks + 1,
            avgDuration = (avgDuration * completedTasks + ?) / (completedTasks + 1)
        WHERE id=?
      `, [input.actualDurationMin, mr.assignedTechId]);

      // تحديث معدل المدة للنوع (Moving Average pool)
      // (مُحدَّث تلقائياً عبر الـ task الكامل)

      // قيد محاسبي
      const [journal] = await db.execute(`
        INSERT INTO journal_entries (companyId, branchId, ref, description, createdBy, createdAt)
        VALUES (?,?,CONCAT('MR-',?),'تكلفة صيانة',?,NOW())
      `, [companyId, branchId, input.mrId, userId]);
      const journalId = (journal as any).insertId;

      await db.execute(`
        INSERT INTO journal_lines (journalId, accountCode, debit, credit)
        VALUES (?, '513001', ?, 0), (?, '101001', 0, ?)
      `, [journalId, totalCost, journalId, totalCost]);

      // إشعار مدير الأملاك
      await db.execute(`
        INSERT INTO notifications (companyId, type, title, body, createdAt)
        VALUES (?,'maintenance_completed','بلاغ مكتمل',
          CONCAT(?,': تم ✓ المدة ',?' دقيقة — التكلفة ',?,' ريال'),NOW())
      `, [companyId, mr.mrNumber, input.actualDurationMin, totalCost]);

      eventBus.emit("MAINTENANCE_COMPLETED", {
        mrId: input.mrId, totalCost, withinSla, companyId, branchId,
      });

      return { success: true, totalCost, withinSla, journalId };
    }),

  // ─────────────────────────────────────────────
  // إيجار متأخر — 6 مراحل
  // يُستدعى من Cron يوم 1 كل شهر ويومياً
  // ─────────────────────────────────────────────

  processLateRent: scopedProcedure
    .mutation(async ({ ctx }) => {
      const { companyId } = ctx.scope;
      const results: any[] = [];
      const today = new Date();

      const lateContracts = await db.query(`
        SELECT rc.*, u.unitNumber, u.address,
          cl.name AS tenantName, cl.phone AS tenantPhone,
          DATEDIFF(NOW(), rc.dueDate) AS daysLate,
          rc.amount AS rentAmount
        FROM rental_contracts rc
        JOIN property_units u ON u.id = rc.unitId
        JOIN clients cl ON cl.id = rc.clientId
        WHERE rc.companyId=?
          AND rc.status IN ('active','overdue')
          AND rc.nextPaymentDate < NOW()
          AND rc.lastPaymentDate < rc.nextPaymentDate
        ORDER BY daysLate DESC
      `, [companyId]);

      for (const contract of lateContracts) {
        const days = contract.daysLate;
        let action = "";
        const penaltyRate = await getSetting("properties.lateRentPenalty", null, companyId) as number || 0.02;

        if (days === 1) {
          // ── مرحلة 1: يوم 1 — SMS ────────────────────────
          await db.execute(`
            INSERT INTO sms_queue (companyId, clientId, message, scheduledAt)
            VALUES (?,?,CONCAT('تذكير: إيجار ',?,' بتاريخ ',?' مستحق — يرجى السداد'),NOW())
          `, [companyId, contract.clientId, contract.unitNumber, contract.nextPaymentDate]);
          action = "SMS تذكير";

        } else if (days === 5) {
          // ── مرحلة 2: يوم 5 — غرامة ───────────────────────
          const penalty = +(contract.rentAmount * penaltyRate).toFixed(2);
          await db.execute(`
            INSERT INTO late_rent_penalties
              (companyId, contractId, clientId, amount, reason, createdAt)
            VALUES (?,?,?,?,'غرامة تأخير إيجار',NOW())
          `, [companyId, contract.id, contract.clientId, penalty]);
          await db.execute(`
            INSERT INTO sms_queue (companyId, clientId, message, scheduledAt)
            VALUES (?,?,CONCAT('إشعار: تمت إضافة غرامة تأخير ',?' ريال على إيجار ',?),NOW())
          `, [companyId, contract.clientId, penalty, contract.unitNumber]);
          action = `غرامة ${penalty} ريال`;

        } else if (days === 14) {
          // ── مرحلة 3: يوم 14 — مهمة متابعة ميدانية ────────
          await db.execute(`
            INSERT INTO tasks
              (companyId, type, title, clientId, priority, status, scheduledDate, createdAt)
            VALUES (?,'rent_followup',CONCAT('متابعة إيجار متأخر — ',?),?,'high','pending',CURDATE(),NOW())
          `, [companyId, contract.unitNumber, contract.clientId]);
          action = "مهمة متابعة ميدانية";

        } else if (days === 21) {
          // ── مرحلة 4: يوم 21 — إنذار رسمي ─────────────────
          const noticeNumber = `LRN-${companyId}-${contract.id}-${Date.now().toString(36).toUpperCase()}`;
          await db.execute(`
            INSERT INTO formal_notices
              (companyId, contractId, clientId, type, noticeNumber,
               amount, daysLate, status, createdAt)
            VALUES (?,?,?,'late_rent',?,?,?,'sent',NOW())
          `, [companyId, contract.id, contract.clientId, noticeNumber,
              contract.rentAmount, days]);
          await db.execute(`
            INSERT INTO sms_queue (companyId, clientId, message, scheduledAt)
            VALUES (?,?,CONCAT('إنذار رسمي ',?,' — يجب السداد خلال 7 أيام لتجنب الإخلاء'),NOW())
          `, [companyId, contract.clientId, noticeNumber]);
          action = `إنذار رسمي ${noticeNumber}`;

        } else if (days === 30) {
          // ── مرحلة 5: يوم 30 — تصعيد GM والقانونية ────────
          await db.execute(`
            INSERT INTO notifications (companyId, type, title, body, targetRole, createdAt)
            VALUES (?,'rent_escalation','إيجار متأخر 30 يوم',
              CONCAT(?,': ',?,' ريال متأخر 30 يوم'),'gm',NOW())
          `, [companyId, contract.unitNumber, contract.rentAmount]);

          await db.execute(`
            INSERT INTO legal_cases
              (companyId, clientId, contractId, type, description,
               amount, status, createdAt)
            VALUES (?,?,?,'rent_collection',
              CONCAT('تحصيل إيجار متأخر — ',?,': ',?,' ريال'),
              ?,'open',NOW())
          `, [companyId, contract.clientId, contract.id,
              contract.unitNumber, contract.rentAmount, contract.rentAmount]);

          action = "تصعيد GM + فتح قضية قانونية";

        } else if (days >= 60) {
          // ── مرحلة 6: يوم 60+ — إخلاء ─────────────────────
          await db.execute(`
            UPDATE rental_contracts SET status='eviction_notice' WHERE id=?
          `, [contract.id]);

          await db.execute(`
            INSERT INTO eviction_notices
              (companyId, contractId, clientId, unitId,
               daysLate, totalArrears, status, createdAt)
            VALUES (?,?,?,?, ?,?,'pending',NOW())
          `, [
            companyId, contract.id, contract.clientId, contract.unitId,
            days, contract.rentAmount,
          ]);

          await db.execute(`
            INSERT INTO notifications (companyId, type, title, body, targetRole, createdAt)
            VALUES (?,'eviction','إشعار إخلاء',
              CONCAT(?,': ',?,' يوم تأخير'),  'property_manager',NOW())
          `, [companyId, contract.unitNumber, days]);

          action = "إشعار إخلاء";
        }

        if (action) {
          results.push({
            contractId: contract.id,
            unit: contract.unitNumber,
            tenant: contract.tenantName,
            daysLate: days,
            action,
          });

          await db.execute(`
            UPDATE rental_contracts SET status='overdue', daysLate=? WHERE id=?
          `, [days, contract.id]);
        }
      }

      return { processed: results.length, results };
    }),

  // ── قائمة الوحدات العقارية ────────────────────────────────
  listUnits: scopedProcedure
    .input(z.object({ status: z.string().optional() }))
    .query(async ({ input, ctx }) => {
      const { companyId, branchId } = ctx.scope;
      return db.query(`
        SELECT u.*,
          rc.clientId AS tenantId, cl.name AS tenantName,
          rc.amount AS rentAmount, rc.nextPaymentDate,
          DATEDIFF(NOW(), rc.nextPaymentDate) AS daysLate,
          (SELECT COUNT(*) FROM maintenance_requests mr
           WHERE mr.unitId=u.id AND mr.status NOT IN ('completed','cancelled')) AS openRequests
        FROM property_units u
        LEFT JOIN rental_contracts rc ON rc.unitId=u.id AND rc.status IN ('active','overdue')
        LEFT JOIN clients cl ON cl.id=rc.clientId
        WHERE u.companyId=? AND u.branchId=?
          ${input.status ? "AND u.status=?" : ""}
        ORDER BY u.unitNumber
      `, input.status ? [companyId, branchId, input.status] : [companyId, branchId]);
    }),

  // ── تسجيل دفع إيجار ──────────────────────────────────────
  recordRentPayment: scopedProcedure
    .input(z.object({
      contractId: z.number(),
      amount: z.number(),
      paymentMethod: z.enum(["bank_transfer", "cash", "cheque", "online"]),
      reference: z.string().optional(),
    }))
    .mutation(async ({ input, ctx }) => {
      const { companyId, branchId, userId } = ctx.scope;

      const [contracts] = await db.query(`
        SELECT * FROM rental_contracts WHERE id=? AND companyId=?
      `, [input.contractId, companyId]);
      if (!contracts.length) throw new Error("العقد غير موجود");
      const contract = contracts[0];

      // تسجيل الدفع
      const [payResult] = await db.execute(`
        INSERT INTO rent_payments
          (companyId, branchId, contractId, clientId, amount,
           paymentMethod, reference, paidAt, recordedBy)
        VALUES (?,?,?,?,?,?,?,NOW(),?)
      `, [companyId, branchId, input.contractId, contract.clientId,
          input.amount, input.paymentMethod, input.reference || null, userId]);
      const paymentId = (payResult as any).insertId;

      // تحديث تاريخ الدفع القادم
      const nextPayment = new Date(contract.nextPaymentDate);
      nextPayment.setMonth(nextPayment.getMonth() + 1);

      await db.execute(`
        UPDATE rental_contracts
        SET lastPaymentDate=NOW(), nextPaymentDate=?, status='active', daysLate=0
        WHERE id=?
      `, [nextPayment, input.contractId]);

      // قيد محاسبي
      const [journal] = await db.execute(`
        INSERT INTO journal_entries (companyId, branchId, ref, description, createdBy, createdAt)
        VALUES (?,?,CONCAT('RENT-',?),'إيجار مقبوض',?,NOW())
      `, [companyId, branchId, paymentId, userId]);
      const journalId = (journal as any).insertId;

      await db.execute(`
        INSERT INTO journal_lines (journalId, accountCode, debit, credit)
        VALUES (?, '101001', ?, 0), (?, '411001', 0, ?)
      `, [journalId, input.amount, journalId, input.amount]);

      // SMS إيصال
      await db.execute(`
        INSERT INTO sms_queue (companyId, clientId, message, scheduledAt)
        VALUES (?,?,CONCAT('تم استلام إيجار ',?,' ريال — الدفعة القادمة ',?),NOW())
      `, [companyId, contract.clientId, input.amount, nextPayment.toLocaleDateString("ar")]);

      eventBus.emit("RENT_PAID", {
        contractId: input.contractId, amount: input.amount,
        companyId, branchId,
      });

      return { paymentId, journalId, nextPaymentDate: nextPayment };
    }),
});

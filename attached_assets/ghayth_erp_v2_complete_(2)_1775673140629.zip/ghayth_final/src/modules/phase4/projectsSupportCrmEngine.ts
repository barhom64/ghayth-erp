/**
 * projectsSupportCrmEngine.ts — منصة غيث ERP
 * المرجع: ملف 06 — المشاريع والدعم وCRM
 * مشروع 7 خطوات + Critical Path
 * تذكرة دعم 8 خطوات + SLA
 * فرصة بيع 7 مراحل
 */

import { z } from "zod";
import { scopedProcedure, router } from "../../core/trpc.js";
import { db } from "../../core/db.js";
import { eventBus } from "../../core/eventBus.js";
import { auditLogger } from "../../core/eventBus.js";
import { getSetting } from "../../core/eventBus.js";

// ─────────────────────────────────────────────
// SLA للدعم
// ─────────────────────────────────────────────

const SUPPORT_SLA: Record<string, { replyHours: number; resolveHours: number }> = {
  urgent:  { replyHours: 0.5,  resolveHours: 2  },
  high:    { replyHours: 1,    resolveHours: 4  },
  medium:  { replyHours: 4,    resolveHours: 24 },
  low:     { replyHours: 24,   resolveHours: 72 },
};

// مراحل فرص البيع
const CRM_STAGES = [
  "prospecting", "qualification", "proposal",
  "negotiation", "closed_won", "closed_lost",
];

// تلقائياً يحدد أولوية تذكرة الدعم من النص
function detectTicketPriority(subject: string, body: string): keyof typeof SUPPORT_SLA {
  const text = `${subject} ${body}`.toLowerCase();
  if (["عاجل", "urgent", "طوارئ", "حريق", "توقف", "خطأ حرج"].some(k => text.includes(k)))
    return "urgent";
  if (["مهم", "خطأ", "فاتورة خاطئة", "لا يعمل"].some(k => text.includes(k)))
    return "high";
  if (["استفسار", "سؤال", "تحديث"].some(k => text.includes(k)))
    return "low";
  return "medium";
}

// Load Balancing للموظفين (دعم + CRM)
interface AgentCandidate {
  assignmentId: number;
  name: string;
  activeTickets: number;
  clientServedBefore: boolean; // هل خدم هذا العميل قبلاً
  rating: number;
}

function loadBalanceAgent(candidates: AgentCandidate[]): AgentCandidate {
  const scored = candidates.map(a => {
    const loadScore = Math.max(0, ((10 - a.activeTickets) / 10) * 60);
    const historyScore = a.clientServedBefore ? 30 : 0;
    const ratingScore = (a.rating / 5) * 10;
    return { ...a, score: loadScore + historyScore + ratingScore };
  });
  scored.sort((a, b) => b.score - a.score);
  return scored[0];
}

export const projectsSupportCrmRouter = router({

  // ═══════════════════════════════════════════
  // ── المشاريع — 7 خطوات
  // ═══════════════════════════════════════════

  createProject: scopedProcedure
    .input(z.object({
      name: z.string(),
      clientId: z.number(),
      budget: z.number(),
      startDate: z.string(),
      endDate: z.string(),
      phases: z.array(z.object({
        name: z.string(),
        order: z.number(),
        estimatedDays: z.number(),
        tasks: z.array(z.object({
          name: z.string(),
          assignedTo: z.number(), // assignmentId
          estimatedHours: z.number(),
          dependsOn: z.array(z.string()).optional(), // أسماء المهام التي تعتمد عليها
        })),
      })),
      description: z.string().optional(),
    }))
    .mutation(async ({ input, ctx }) => {
      const { companyId, branchId, userId } = ctx.scope;

      // ── خطوة 1: إنشاء المشروع ───────────────────────────
      const projectCode = `PRJ-${companyId}-${Date.now().toString(36).toUpperCase()}`;

      const [prjResult] = await db.execute(`
        INSERT INTO projects
          (companyId, branchId, projectCode, name, clientId,
           budget, startDate, endDate, description,
           status, budgetUsed, createdBy, createdAt)
        VALUES (?,?,?,?,?, ?,?,?,?, 'planning',0,?,NOW())
      `, [
        companyId, branchId, projectCode, input.name, input.clientId,
        input.budget, input.startDate, input.endDate, input.description || null,
        userId,
      ]);
      const projectId = (prjResult as any).insertId;

      // ── خطوة 2: إنشاء مراحل ومهام وتبعيات ──────────────
      const taskMap: Record<string, number> = {}; // اسم المهمة -> taskId

      for (const phase of input.phases) {
        const [phResult] = await db.execute(`
          INSERT INTO project_phases
            (companyId, projectId, name, phaseOrder, estimatedDays, status, createdAt)
          VALUES (?,?,?,?,?,'pending',NOW())
        `, [companyId, projectId, phase.name, phase.order, phase.estimatedDays]);
        const phaseId = (phResult as any).insertId;

        for (const task of phase.tasks) {
          const [tResult] = await db.execute(`
            INSERT INTO tasks
              (companyId, branchId, assignedTo, type, refType, refId,
               title, estimatedDuration, clientId, status, priority, createdAt)
            VALUES (?,?,?,'project_task','project',?,  ?,?,?,'pending','normal',NOW())
          `, [
            companyId, branchId, task.assignedTo, projectId,
            task.name, task.estimatedHours * 60, input.clientId,
          ]);
          const taskId = (tResult as any).insertId;
          taskMap[task.name] = taskId;

          // ربط بالمرحلة
          await db.execute(`
            INSERT INTO project_task_phases (taskId, phaseId) VALUES (?,?)
          `, [taskId, phaseId]);
        }
      }

      // تسجيل التبعيات
      for (const phase of input.phases) {
        for (const task of phase.tasks) {
          if (task.dependsOn?.length) {
            for (const dep of task.dependsOn) {
              if (taskMap[dep] && taskMap[task.name]) {
                await db.execute(`
                  INSERT INTO task_dependencies (taskId, dependsOnTaskId)
                  VALUES (?,?)
                `, [taskMap[task.name], taskMap[dep]]);
              }
            }
          }
        }
      }

      // ── خطوة 3: Critical Path ────────────────────────────
      const criticalPath = await calcCriticalPath(projectId, companyId, db);

      // ── خطوة 4: المهام في تقويم كل عضو (تمت في الـ tasks) ─

      // ── خطوة 5: إكمال مهمة يفتح المهام المعتمدة (عبر eventBus)
      // يُنفَّذ في TASK_COMPLETED handler

      // ── خطوة 6: تحذير ميزانية 80% ──────────────────────
      // يُراقَب عند كل مصروف في financeEngine

      // ── خطوة 7: إكمال مرحلة = فاتورة تلقائية ───────────
      // يُنفَّذ في PROJECT_PHASE_COMPLETED handler

      // إشعار فريق المشروع
      const assignees = [...new Set(input.phases.flatMap(p => p.tasks.map(t => t.assignedTo)))];
      for (const assignedTo of assignees) {
        await db.execute(`
          INSERT INTO notifications (companyId, assignmentId, type, title, body, createdAt)
          VALUES (?,?,'project_assigned','مشروع جديد',
            CONCAT(?,': ',?,' — يبدأ ',?),NOW())
        `, [companyId, assignedTo, projectCode, input.name, input.startDate]);
      }

      eventBus.emit("PROJECT_CREATED", {
        projectId, projectCode, clientId: input.clientId,
        budget: input.budget, companyId, branchId,
      });

      return { projectId, projectCode, criticalPath, taskCount: Object.keys(taskMap).length };
    }),

  // إكمال مرحلة مشروع ← فاتورة تلقائية
  completeProjectPhase: scopedProcedure
    .input(z.object({ phaseId: z.number(), actualCost: z.number() }))
    .mutation(async ({ input, ctx }) => {
      const { companyId, branchId, userId } = ctx.scope;

      const [phases] = await db.query(`
        SELECT pp.*, p.clientId, p.projectCode, p.budget, p.budgetUsed, p.name AS projectName
        FROM project_phases pp
        JOIN projects p ON p.id = pp.projectId
        WHERE pp.id=? AND p.companyId=?
      `, [input.phaseId, companyId]);

      if (!phases.length) throw new Error("المرحلة غير موجودة");
      const phase = phases[0];

      await db.execute(`
        UPDATE project_phases SET status='completed', completedAt=NOW() WHERE id=?
      `, [input.phaseId]);

      // تحديث الميزانية المُستخدمة
      const newBudgetUsed = phase.budgetUsed + input.actualCost;
      const budgetPercent = (newBudgetUsed / phase.budget) * 100;

      await db.execute(`
        UPDATE projects SET budgetUsed=? WHERE id=?
      `, [newBudgetUsed, phase.projectId]);

      // تحذير ميزانية 80%
      if (budgetPercent >= 80) {
        await db.execute(`
          INSERT INTO notifications (companyId, type, title, body, targetRole, createdAt)
          VALUES (?,'budget_warning','تحذير ميزانية مشروع',
            CONCAT(?, ': ',?,?'%'),'pm',NOW())
        `, [companyId, phase.projectName, budgetPercent.toFixed(0)]);
      }

      // فاتورة تلقائية للعميل عند إكمال المرحلة
      eventBus.emit("PROJECT_PHASE_COMPLETED", {
        phaseId: input.phaseId, projectId: phase.projectId,
        clientId: phase.clientId, actualCost: input.actualCost,
        companyId, branchId,
      });

      // فتح المهام المعتمدة على هذه المرحلة
      await db.execute(`
        UPDATE tasks t
        JOIN task_dependencies td ON td.taskId = t.id
        JOIN project_task_phases ptp ON ptp.taskId = td.dependsOnTaskId AND ptp.phaseId=?
        SET t.status='pending'
        WHERE t.status='blocked'
      `, [input.phaseId]);

      return { success: true, budgetPercent: +budgetPercent.toFixed(1) };
    }),

  // ═══════════════════════════════════════════
  // ── الدعم — تذكرة 8 خطوات + SLA
  // ═══════════════════════════════════════════

  createSupportTicket: scopedProcedure
    .input(z.object({
      clientId: z.number(),
      subject: z.string(),
      body: z.string(),
      channel: z.enum(["whatsapp", "email", "phone", "portal", "app"]),
      attachments: z.array(z.string()).optional(),
    }))
    .mutation(async ({ input, ctx }) => {
      const { companyId, branchId, userId } = ctx.scope;

      // ── خطوة 1: تحديد أولوية تلقائية ────────────────────
      const priority = detectTicketPriority(input.subject, input.body);
      const sla = SUPPORT_SLA[priority];
      const slaReplyDeadline = new Date(Date.now() + sla.replyHours * 3600000);
      const slaResolveDeadline = new Date(Date.now() + sla.resolveHours * 3600000);

      const ticketNumber = `TKT-${companyId}-${Date.now().toString(36).toUpperCase()}`;

      // ── خطوة 2: حفظ التذكرة ─────────────────────────────
      const [ticketResult] = await db.execute(`
        INSERT INTO support_tickets
          (companyId, branchId, ticketNumber, clientId, subject, body,
           channel, attachments, priority,
           slaReplyDeadline, slaResolveDeadline,
           status, createdAt)
        VALUES (?,?,?,?,?,?, ?,?,?,  ?,?, 'open',NOW())
      `, [
        companyId, branchId, ticketNumber, input.clientId,
        input.subject, input.body,
        input.channel, JSON.stringify(input.attachments || []),
        priority, slaReplyDeadline, slaResolveDeadline,
      ]);
      const ticketId = (ticketResult as any).insertId;

      // ── خطوة 3: تعيين موظف (Load Balancing) ──────────────
      const agentRows = await db.query(`
        SELECT
          ea.id AS assignmentId, e.name,
          COUNT(st.id) AS activeTickets,
          (SELECT COUNT(*) FROM support_tickets st2
           WHERE st2.assignedTo=ea.id AND st2.clientId=? AND st2.status='closed') > 0
            AS servedBefore,
          AVG(tr.rating) AS rating
        FROM employee_assignments ea
        JOIN employees e ON e.id = ea.employeeId
        LEFT JOIN support_tickets st ON st.assignedTo=ea.id
          AND st.status IN ('open','in_progress')
        LEFT JOIN support_ticket_ratings tr ON tr.assignmentId=ea.id
        WHERE ea.companyId=? AND ea.branchId=?
          AND ea.status='active'
          AND ea.role IN ('support','employee')
        GROUP BY ea.id
        HAVING activeTickets < 10
      `, [input.clientId, companyId, branchId]);

      let assignedTo: number | null = null;
      if (agentRows.length) {
        const candidates: AgentCandidate[] = agentRows.map((r: any) => ({
          assignmentId: r.assignmentId,
          name: r.name,
          activeTickets: +r.activeTickets,
          clientServedBefore: !!r.servedBefore,
          rating: +r.rating || 4,
        }));
        const best = loadBalanceAgent(candidates);
        assignedTo = best.assignmentId;

        await db.execute(`
          UPDATE support_tickets SET assignedTo=?, status='assigned' WHERE id=?
        `, [assignedTo, ticketId]);
      }

      // ── خطوة 4: مهمة في الصفحة الرئيسية للموظف ──────────
      if (assignedTo) {
        await db.execute(`
          INSERT INTO tasks
            (companyId, branchId, assignedTo, type, refType, refId,
             title, clientId, priority, slaDeadline, status, createdAt)
          VALUES (?,?,?,'support_ticket','support_ticket',?,
            CONCAT('[دعم] ',?),?,?,?,'pending',NOW())
        `, [
          companyId, branchId, assignedTo, ticketId,
          input.subject, input.clientId, priority, slaResolveDeadline,
        ]);

        // إشعار الموظف
        await db.execute(`
          INSERT INTO notifications (companyId, assignmentId, type, title, body, createdAt)
          VALUES (?,?,'ticket_assigned','تذكرة دعم جديدة',
            CONCAT(?,': ',?,' — SLA رد: ',?),NOW())
        `, [
          companyId, assignedTo, ticketNumber, input.subject,
          slaReplyDeadline.toLocaleTimeString("ar"),
        ]);
      }

      // ── خطوة 5: تأكيد للعميل ─────────────────────────────
      await db.execute(`
        INSERT INTO sms_queue (companyId, clientId, message, scheduledAt)
        VALUES (?,?,CONCAT('تم استلام طلبك ',?,' — سيتواصل معك فريق الدعم قريباً'),NOW())
      `, [companyId, input.clientId, ticketNumber]);

      // ── خطوة 6 + 7: Cron يراقب SLA ──────────────────────
      // (في runSupportSlaCheck)

      eventBus.emit("SUPPORT_TICKET_CREATED", {
        ticketId, ticketNumber, clientId: input.clientId,
        priority, companyId, branchId,
      });

      return { ticketId, ticketNumber, priority, slaReplyDeadline, slaResolveDeadline };
    }),

  // ── رد على تذكرة (يوقف SLA الرد) ──────────────────────────
  replyToTicket: scopedProcedure
    .input(z.object({
      ticketId: z.number(),
      message: z.string(),
      isInternal: z.boolean().default(false),
      requiresFieldVisit: z.boolean().default(false),
      attachments: z.array(z.string()).optional(),
    }))
    .mutation(async ({ input, ctx }) => {
      const { companyId, userId } = ctx.scope;

      const [tickets] = await db.query(`
        SELECT * FROM support_tickets WHERE id=? AND companyId=?
      `, [input.ticketId, companyId]);
      if (!tickets.length) throw new Error("التذكرة غير موجودة");
      const ticket = tickets[0];

      await db.execute(`
        INSERT INTO ticket_replies
          (ticketId, message, isInternal, attachments, sentBy, sentAt)
        VALUES (?,?,?,?,?,NOW())
      `, [
        input.ticketId, input.message,
        input.isInternal ? 1 : 0,
        JSON.stringify(input.attachments || []),
        userId,
      ]);

      // تسجيل وقت أول رد
      if (!ticket.firstReplyAt) {
        await db.execute(`
          UPDATE support_tickets SET firstReplyAt=NOW(), status='in_progress' WHERE id=?
        `, [input.ticketId]);
      }

      // ── خطوة 8: إذا تحتاج زيارة = مهمة ميدانية ──────────
      if (input.requiresFieldVisit) {
        await db.execute(`
          INSERT INTO tasks
            (companyId, type, refType, refId, title, clientId, priority, status, createdAt)
          VALUES (?,'field_visit','support_ticket',?,
            CONCAT('زيارة ميدانية: ',?),?,'high','pending',NOW())
        `, [companyId, input.ticketId, ticket.subject, ticket.clientId]);
      }

      // إرسال الرد للعميل إذا ليس داخلي
      if (!input.isInternal) {
        await db.execute(`
          INSERT INTO ${ticket.channel === 'email' ? 'email_queue' : 'whatsapp_queue'}
            (companyId, clientId, message, scheduledAt)
          VALUES (?,?,?,NOW())
        `, [companyId, ticket.clientId, input.message]);
      }

      return { success: true };
    }),

  // ── إغلاق تذكرة ──────────────────────────────────────────
  closeTicket: scopedProcedure
    .input(z.object({
      ticketId: z.number(),
      resolution: z.string(),
      sendSurvey: z.boolean().default(true),
    }))
    .mutation(async ({ input, ctx }) => {
      const { companyId, userId } = ctx.scope;

      const [tickets] = await db.query(`
        SELECT * FROM support_tickets WHERE id=? AND companyId=?
      `, [input.ticketId, companyId]);
      if (!tickets.length) throw new Error("التذكرة غير موجودة");
      const ticket = tickets[0];

      const withinSla = new Date() <= new Date(ticket.slaResolveDeadline);

      await db.execute(`
        UPDATE support_tickets
        SET status='closed', resolution=?, closedAt=NOW(), closedBy=?,
            resolvedWithinSla=?
        WHERE id=?
      `, [input.resolution, userId, withinSla ? 1 : 0, input.ticketId]);

      await db.execute(`
        UPDATE tasks SET status='completed', completedAt=NOW()
        WHERE refType='support_ticket' AND refId=?
      `, [input.ticketId]);

      // استبيان بعد 24 ساعة
      if (input.sendSurvey) {
        const surveyAt = new Date(Date.now() + 24 * 3600000);
        await db.execute(`
          INSERT INTO sms_queue (companyId, clientId, message, scheduledAt)
          VALUES (?,?,CONCAT('كيف كانت تجربتك مع فريق الدعم؟ قيّمنا: https://rate.door.sa/support/?id=',?),?)
        `, [companyId, ticket.clientId, input.ticketId, surveyAt]);
      }

      eventBus.emit("SUPPORT_TICKET_CLOSED", {
        ticketId: input.ticketId, withinSla, companyId,
      });

      return { success: true, withinSla };
    }),

  // ── Cron: فحص SLA التذاكر ─────────────────────────────────
  runSupportSlaCheck: scopedProcedure
    .mutation(async ({ ctx }) => {
      const { companyId } = ctx.scope;
      const alerts: string[] = [];

      // تذاكر تجاوزت SLA الرد ولم تُرد عليها
      const replyBreaches = await db.query(`
        SELECT st.id, st.ticketNumber, st.subject, st.assignedTo,
          st.priority, TIMESTAMPDIFF(MINUTE, st.slaReplyDeadline, NOW()) AS overMin
        FROM support_tickets st
        WHERE st.companyId=?
          AND st.status IN ('open','assigned')
          AND st.firstReplyAt IS NULL
          AND st.slaReplyDeadline < NOW()
          AND st.slaReplyAlertSent=0
      `, [companyId]);

      for (const t of replyBreaches) {
        alerts.push(`⚠️ SLA رد منتهي: ${t.ticketNumber} — تأخر ${t.overMin} دقيقة`);
        await db.execute(`
          INSERT INTO notifications (companyId, assignmentId, type, title, body, createdAt)
          VALUES (?,?,'sla_breach','تجاوز SLA الرد',
            CONCAT(?,': تأخر ',?,' دقيقة'),NOW())
        `, [companyId, t.assignedTo, t.ticketNumber, t.overMin]);
        await db.execute(`
          UPDATE support_tickets SET slaReplyAlertSent=1 WHERE id=?
        `, [t.id]);
      }

      // تذاكر على وشك انتهاء SLA الحل (80%)
      const nearDeadline = await db.query(`
        SELECT st.id, st.ticketNumber, st.assignedTo, st.priority,
          TIMESTAMPDIFF(MINUTE, NOW(), st.slaResolveDeadline) AS remainMin
        FROM support_tickets st
        WHERE st.companyId=?
          AND st.status IN ('open','assigned','in_progress')
          AND st.slaResolveDeadline > NOW()
          AND TIMESTAMPDIFF(MINUTE, NOW(), st.slaResolveDeadline) <= 60
          AND st.slaWarningAlertSent=0
      `, [companyId]);

      for (const t of nearDeadline) {
        alerts.push(`🔔 تحذير SLA: ${t.ticketNumber} — متبقي ${t.remainMin} دقيقة`);
        await db.execute(`
          INSERT INTO notifications (companyId, assignmentId, type, title, body, createdAt)
          VALUES (?,?,'sla_warning','تحذير SLA',
            CONCAT(?,': متبقي ',?,' دقيقة'),NOW())
        `, [companyId, t.assignedTo, t.ticketNumber, t.remainMin]);
        await db.execute(`
          UPDATE support_tickets SET slaWarningAlertSent=1 WHERE id=?
        `, [t.id]);
      }

      return { alerts, count: alerts.length };
    }),

  // ═══════════════════════════════════════════
  // ── CRM — فرصة بيع 7 مراحل
  // ═══════════════════════════════════════════

  createOpportunity: scopedProcedure
    .input(z.object({
      clientId: z.number(),
      title: z.string(),
      value: z.number(),
      assignedTo: z.number(), // assignmentId مندوب المبيعات
      source: z.string().optional(), // whatsapp | referral | cold_call | website
      expectedCloseDate: z.string(),
      notes: z.string().optional(),
    }))
    .mutation(async ({ input, ctx }) => {
      const { companyId, branchId, userId } = ctx.scope;

      const oppNumber = `OPP-${companyId}-${Date.now().toString(36).toUpperCase()}`;

      // ── مرحلة 1: حفظ prospecting ──────────────────────────
      const [oppResult] = await db.execute(`
        INSERT INTO crm_opportunities
          (companyId, branchId, oppNumber, clientId, title, value,
           assignedTo, source, expectedCloseDate, notes,
           stage, probability, createdBy, createdAt)
        VALUES (?,?,?,?,?,?, ?,?,?,?, 'prospecting',10,?,NOW())
      `, [
        companyId, branchId, oppNumber, input.clientId, input.title, input.value,
        input.assignedTo, input.source || null,
        input.expectedCloseDate, input.notes || null,
        userId,
      ]);
      const oppId = (oppResult as any).insertId;

      // ── مرحلة 2: جدولة متابعة 3 أيام ──────────────────────
      const followupDays = await getSetting("crm.prospectingFollowupDays", null, companyId) as number || 3;
      const followupDate = new Date(Date.now() + followupDays * 86400000);

      await db.execute(`
        INSERT INTO tasks
          (companyId, branchId, assignedTo, type, refType, refId,
           title, clientId, scheduledDate, status, priority, createdAt)
        VALUES (?,?,?,'crm_followup','crm_opportunity',?,
          CONCAT('متابعة: ',?),?,?,  'pending','normal',NOW())
      `, [
        companyId, branchId, input.assignedTo, oppId,
        input.title, input.clientId, followupDate.toISOString().slice(0, 10),
      ]);

      // إشعار المندوب
      await db.execute(`
        INSERT INTO notifications (companyId, assignmentId, type, title, body, createdAt)
        VALUES (?,?,'opp_assigned','فرصة بيع جديدة',
          CONCAT(?,': ',?,' — ',?,' ريال'),NOW())
      `, [companyId, input.assignedTo, oppNumber, input.title, input.value]);

      eventBus.emit("CRM_OPPORTUNITY_CREATED", {
        oppId, oppNumber, clientId: input.clientId,
        value: input.value, companyId, branchId,
      });

      return { oppId, oppNumber };
    }),

  // ── تقدم الفرصة لمرحلة جديدة ──────────────────────────────
  advanceOpportunity: scopedProcedure
    .input(z.object({
      oppId: z.number(),
      newStage: z.enum(["qualification", "proposal", "negotiation", "closed_won", "closed_lost"]),
      notes: z.string().optional(),
      lostReason: z.string().optional(), // إجباري عند closed_lost
    }))
    .mutation(async ({ input, ctx }) => {
      const { companyId, branchId, userId } = ctx.scope;

      if (input.newStage === "closed_lost" && !input.lostReason) {
        throw new Error("سبب الخسارة إجباري عند إغلاق الفرصة كخسارة");
      }

      const [opps] = await db.query(`
        SELECT * FROM crm_opportunities WHERE id=? AND companyId=?
      `, [input.oppId, companyId]);
      if (!opps.length) throw new Error("الفرصة غير موجودة");
      const opp = opps[0];

      // نسب الاحتمالية لكل مرحلة
      const probabilities: Record<string, number> = {
        qualification: 25, proposal: 50,
        negotiation: 75, closed_won: 100, closed_lost: 0,
      };

      const before = { stage: opp.stage, probability: opp.probability };

      await db.execute(`
        UPDATE crm_opportunities
        SET stage=?, probability=?, lastAdvancedAt=NOW(),
            lostReason=?, notes=CONCAT(COALESCE(notes,''),'\n',COALESCE(?,''))
        WHERE id=?
      `, [
        input.newStage, probabilities[input.newStage],
        input.lostReason || null, input.notes || null,
        input.oppId,
      ]);

      // ── مرحلة 3-4: كل مرحلة تجدول المتابعة التالية تلقائياً
      const followupDaysMap: Record<string, number> = {
        qualification: 2, proposal: 3, negotiation: 1,
      };

      if (followupDaysMap[input.newStage]) {
        const nextFollowup = new Date(
          Date.now() + followupDaysMap[input.newStage] * 86400000
        );
        await db.execute(`
          INSERT INTO tasks
            (companyId, branchId, assignedTo, type, refType, refId,
             title, clientId, scheduledDate, status, priority, createdAt)
          VALUES (?,?,?,'crm_followup','crm_opportunity',?,
            CONCAT('متابعة ',?,'): ',?),?,?,  'pending','normal',NOW())
        `, [
          companyId, branchId, opp.assignedTo, input.oppId,
          input.newStage, opp.title, opp.clientId,
          nextFollowup.toISOString().slice(0, 10),
        ]);
      }

      // ── مرحلة 5: closed_won = عقد + فاتورة ──────────────
      if (input.newStage === "closed_won") {
        eventBus.emit("CRM_OPPORTUNITY_WON", {
          oppId: input.oppId, oppNumber: opp.oppNumber,
          clientId: opp.clientId, value: opp.value,
          companyId, branchId,
        });

        // تحديث KPI المندوب
        await db.execute(`
          INSERT INTO crm_kpis (assignmentId, metric, value, period, companyId, createdAt)
          VALUES (?, 'closed_won', ?, DATE_FORMAT(NOW(),'%Y-%m'), ?, NOW())
          ON DUPLICATE KEY UPDATE value=value+?
        `, [opp.assignedTo, opp.value, companyId, opp.value]);
      }

      // ── مرحلة 6: closed_lost = سبب إجباري + تحليل ────────
      if (input.newStage === "closed_lost") {
        await db.execute(`
          INSERT INTO crm_loss_analysis
            (companyId, oppId, reason, value, competitor, createdAt)
          VALUES (?,?,?,?,NULL,NOW())
        `, [companyId, input.oppId, input.lostReason, opp.value]);
      }

      await auditLogger.log({
        companyId, branchId, userId,
        action: "CRM_STAGE_ADVANCED",
        entity: "crm_opportunities",
        entityId: input.oppId,
        before, after: { stage: input.newStage, probability: probabilities[input.newStage] },
        reason: input.notes || `تقدم لـ ${input.newStage}`,
      });

      return { success: true, newStage: input.newStage, probability: probabilities[input.newStage] };
    }),

  // ── Cron: تذكير متابعات CRM ──────────────────────────────
  runCrmReminders: scopedProcedure
    .mutation(async ({ ctx }) => {
      const { companyId } = ctx.scope;
      const alerts: string[] = [];

      // فرص لم تُتابع
      const overdueFollowups = await db.query(`
        SELECT o.id, o.oppNumber, o.title, o.assignedTo, o.stage,
          DATEDIFF(NOW(), t.scheduledDate) AS daysOverdue
        FROM crm_opportunities o
        JOIN tasks t ON t.refType='crm_opportunity' AND t.refId=o.id
          AND t.type='crm_followup' AND t.status='pending'
        WHERE o.companyId=?
          AND o.stage NOT IN ('closed_won','closed_lost')
          AND t.scheduledDate < NOW()
      `, [companyId]);

      for (const opp of overdueFollowups) {
        alerts.push(`📞 فرصة ${opp.oppNumber}: متابعة متأخرة ${opp.daysOverdue} يوم`);

        const escalateDays = await getSetting("crm.escalateDays", null, companyId) as number || 2;
        if (opp.daysOverdue >= escalateDays) {
          // تصعيد لمدير المبيعات
          await db.execute(`
            INSERT INTO notifications (companyId, type, title, body, targetRole, createdAt)
            VALUES (?,'crm_escalation','تصعيد متابعة مبيعات',
              CONCAT(?,': لم تُتابع منذ ',?,' أيام'),'sales_manager',NOW())
          `, [companyId, opp.oppNumber, opp.daysOverdue]);
        } else {
          // تذكير المندوب
          await db.execute(`
            INSERT INTO notifications (companyId, assignmentId, type, title, body, createdAt)
            VALUES (?,?,'followup_reminder','تذكير متابعة',
              CONCAT('فرصة ',?,': ',?),NOW())
          `, [companyId, opp.assignedTo, opp.oppNumber, opp.title]);
        }
      }

      return { alerts, count: alerts.length };
    }),
});

// ─────────────────────────────────────────────
// حساب Critical Path للمشروع
// خوارزمية Forward/Backward Pass
// ─────────────────────────────────────────────

async function calcCriticalPath(projectId: number, companyId: number, db: any) {
  const tasks = await db.query(`
    SELECT t.id, t.title, t.estimatedDuration AS duration
    FROM tasks t
    JOIN project_task_phases ptp ON ptp.taskId = t.id
    JOIN project_phases pp ON pp.id = ptp.phaseId
    WHERE pp.projectId=? AND t.companyId=?
    ORDER BY pp.phaseOrder, t.id
  `, [projectId, companyId]);

  const deps = await db.query(`
    SELECT td.taskId, td.dependsOnTaskId
    FROM task_dependencies td
    JOIN tasks t ON t.id = td.taskId
    JOIN project_task_phases ptp ON ptp.taskId = t.id
    JOIN project_phases pp ON pp.id = ptp.phaseId
    WHERE pp.projectId=?
  `, [projectId]);

  // بناء الـ graph
  const taskMap: Record<number, any> = {};
  for (const t of tasks) {
    taskMap[t.id] = { ...t, ES: 0, EF: 0, LS: Infinity, LF: Infinity, slack: 0 };
  }

  // Forward Pass — أقرب وقت بداية/نهاية
  const depMap: Record<number, number[]> = {};
  for (const d of deps) {
    if (!depMap[d.taskId]) depMap[d.taskId] = [];
    depMap[d.taskId].push(d.dependsOnTaskId);
  }

  for (const t of tasks) {
    const prevTasks = depMap[t.id] || [];
    const maxEF = prevTasks.length
      ? Math.max(...prevTasks.map(pid => taskMap[pid]?.EF || 0))
      : 0;
    taskMap[t.id].ES = maxEF;
    taskMap[t.id].EF = maxEF + t.duration;
  }

  // Backward Pass
  const projectDuration = Math.max(...Object.values(taskMap).map((t: any) => t.EF));
  const revTasks = [...tasks].reverse();

  for (const t of revTasks) {
    const nextTasks = deps.filter((d: any) => d.dependsOnTaskId === t.id).map((d: any) => d.taskId);
    if (!nextTasks.length) {
      taskMap[t.id].LF = projectDuration;
    } else {
      taskMap[t.id].LF = Math.min(...nextTasks.map(nid => taskMap[nid]?.LS || projectDuration));
    }
    taskMap[t.id].LS = taskMap[t.id].LF - t.duration;
    taskMap[t.id].slack = taskMap[t.id].LS - taskMap[t.id].ES;
  }

  // المسار الحرج = مهام الـ slack = 0
  const criticalPath = Object.values(taskMap)
    .filter((t: any) => t.slack === 0)
    .map((t: any) => ({ id: t.id, title: t.title, duration: t.duration, ES: t.ES, EF: t.EF }))
    .sort((a: any, b: any) => a.ES - b.ES);

  return { criticalPath, projectDurationMin: projectDuration };
}

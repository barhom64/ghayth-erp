/**
 * fleetEngine.ts — منصة غيث ERP
 * المرجع: ملف 04 — الأسطول والنقل
 * رحلة توصيل 10 خطوات + صيانة دورية 8 خطوات + 7 تنبيهات ذكية
 */

import { z } from "zod";
import { scopedProcedure, router } from "../../core/trpc.js";
import { db } from "../../core/db.js";
import { eventBus } from "../../core/eventBus.js";
import { auditLogger } from "../../core/eventBus.js";
import { getSetting } from "../../core/eventBus.js";

// ─────────────────────────────────────────────
// الثوابت
// ─────────────────────────────────────────────

const FUEL_PRICE_PER_LITER = 2.18; // ريال
const FUEL_CONSUMPTION_PER_100KM = 12; // لتر
const DRIVER_HOURLY_RATE = 29; // ريال/ساعة (= راتب 8700 / 300 ساعة)
const VEHICLE_DEPRECIATION_PER_KM = 0.5; // ريال/كم

// ─────────────────────────────────────────────
// خوارزمية Haversine — المسافة بين نقطتين GPS
// ─────────────────────────────────────────────

function haversineKm(
  lat1: number, lon1: number,
  lat2: number, lon2: number
): number {
  const R = 6371;
  const dLat = ((lat2 - lat1) * Math.PI) / 180;
  const dLon = ((lon2 - lon1) * Math.PI) / 180;
  const a =
    Math.sin(dLat / 2) ** 2 +
    Math.cos((lat1 * Math.PI) / 180) *
      Math.cos((lat2 * Math.PI) / 180) *
      Math.sin(dLon / 2) ** 2;
  return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
}

function travelMinutes(km: number, speedKmh = 40): number {
  return Math.round((km / speedKmh) * 60);
}

// ─────────────────────────────────────────────
// تكلفة الرحلة
// ─────────────────────────────────────────────

function calcTripCost(distanceKm: number, durationMin: number) {
  const fuel =
    (distanceKm / 100) * FUEL_CONSUMPTION_PER_100KM * FUEL_PRICE_PER_LITER;
  const driverWage = (durationMin / 60) * DRIVER_HOURLY_RATE;
  const depreciation = distanceKm * VEHICLE_DEPRECIATION_PER_KM;
  const total = fuel + driverWage + depreciation;
  return {
    fuel: +fuel.toFixed(2),
    driverWage: +driverWage.toFixed(2),
    depreciation: +depreciation.toFixed(2),
    total: +total.toFixed(2),
  };
}

// ─────────────────────────────────────────────
// Load Balancing — اختيار أفضل سائق
// المعادلة: مهام 40% + مسافة 30% + تخصص 20% + تقييم 10%
// ─────────────────────────────────────────────

interface DriverCandidate {
  driverId: number;
  name: string;
  activeTasks: number;        // عدد المهام النشطة اليوم
  distanceKm: number;         // مسافته من موقع الانطلاق
  hasRequiredSkill: boolean;  // يمتلك مهارة الرحلة
  rating: number;             // 1-5
  assignmentId: number;
}

function loadBalanceDriver(candidates: DriverCandidate[]): DriverCandidate {
  const scored = candidates.map((d) => {
    // كلما قلّت المهام = نقاط أعلى (max 6 مهام يومياً)
    const taskScore = Math.max(0, ((6 - d.activeTasks) / 6) * 100);
    // كلما قلّت المسافة = نقاط أعلى
    const maxDist = Math.max(...candidates.map((c) => c.distanceKm)) || 1;
    const distScore = ((maxDist - d.distanceKm) / maxDist) * 100;
    const skillScore = d.hasRequiredSkill ? 100 : 0;
    const ratingScore = (d.rating / 5) * 100;
    const total =
      taskScore * 0.4 +
      distScore * 0.3 +
      skillScore * 0.2 +
      ratingScore * 0.1;
    return { ...d, score: +total.toFixed(1) };
  });

  scored.sort((a, b) => b.score - a.score);
  return scored[0];
}

// ─────────────────────────────────────────────
// 1. سيناريو رحلة توصيل — 10 خطوات
// ─────────────────────────────────────────────

export const fleetRouter = router({

  createTrip: scopedProcedure
    .input(
      z.object({
        clientId: z.number(),
        fromLat: z.number(),
        fromLon: z.number(),
        toLat: z.number(),
        toLon: z.number(),
        cargoDescription: z.string(),
        cargoWeightKg: z.number().optional(),
        requestedBy: z.number(), // assignmentId
      })
    )
    .mutation(async ({ input, ctx }) => {
      const { companyId, branchId, userId } = ctx.scope;
      const tripDate = new Date();

      // ── خطوة 1: حساب المسار بـ Haversine ──────────────
      const distanceKm = haversineKm(
        input.fromLat, input.fromLon,
        input.toLat, input.toLon
      );
      const speedKmh = await getSetting("fleet.travelSpeedKmh", branchId, companyId) as number || 40;
      const travelMin = travelMinutes(distanceKm, speedKmh);

      // ── خطوة 2: اختيار أفضل مركبة ──────────────────────
      const vehicles = await db.query(`
        SELECT v.*, i.expiresAt as insuranceExpiry
        FROM fleet_vehicles v
        JOIN fleet_insurance i ON i.vehicleId = v.id AND i.status = 'active'
        WHERE v.companyId = ? AND v.branchId = ?
          AND v.status = 'available'
          AND (v.maxPayloadKg IS NULL OR v.maxPayloadKg >= ?)
          AND i.expiresAt > NOW()
        ORDER BY ABS(v.currentLat - ?) + ABS(v.currentLon - ?) ASC
        LIMIT 1
      `, [companyId, branchId, input.cargoWeightKg || 0, input.fromLat, input.fromLon]);

      if (!vehicles.length) {
        throw new Error("لا توجد مركبة متاحة أو مؤمّنة");
      }
      const vehicle = vehicles[0];

      // ── خطوة 3: اختيار أفضل سائق بـ Load Balancing ──────
      const driverRows = await db.query(`
        SELECT
          d.id AS driverId, d.name,
          d.rating,
          d.lat AS driverLat, d.lon AS driverLon,
          d.assignmentId,
          COUNT(t.id) AS activeTasks,
          (d.skills LIKE '%delivery%' OR d.skills LIKE '%توصيل%') AS hasSkill
        FROM fleet_drivers d
        LEFT JOIN tasks t ON t.assignedTo = d.assignmentId
          AND t.scheduledDate = CURDATE()
          AND t.status IN ('pending','in_progress')
        WHERE d.companyId = ? AND d.branchId = ?
          AND d.status = 'available'
          AND d.licenseExpiry > NOW()
        GROUP BY d.id
      `, [companyId, branchId]);

      if (!driverRows.length) {
        throw new Error("لا يوجد سائق متاح");
      }

      const candidates: DriverCandidate[] = driverRows.map((r: any) => ({
        driverId: r.driverId,
        name: r.name,
        activeTasks: +r.activeTasks,
        distanceKm: haversineKm(r.driverLat, r.driverLon, input.fromLat, input.fromLon),
        hasRequiredSkill: !!r.hasSkill,
        rating: +r.rating || 4,
        assignmentId: r.assignmentId,
      }));

      const bestDriver = loadBalanceDriver(candidates);

      // ── خطوة 4: حساب المدة الكاملة للرحلة ───────────────
      const loadingMin = 15;
      const unloadingMin = 15;
      const returnMin = travelMin;
      const totalMin = travelMin + loadingMin + unloadingMin + returnMin;

      const scheduledStart = new Date(tripDate.getTime() + 8 * 60000); // 8 دقائق تنقل للمحطة
      const estimatedArrival = new Date(scheduledStart.getTime() + (travelMin + loadingMin) * 60000);

      // ── خطوة 5: حفظ الرحلة ───────────────────────────────
      const [tripResult] = await db.execute(`
        INSERT INTO fleet_trips
          (companyId, branchId, vehicleId, driverId, clientId,
           fromLat, fromLon, toLat, toLon,
           distanceKm, travelMin, totalMin,
           scheduledStart, estimatedArrival,
           status, cargoDescription, requestedBy, createdAt)
        VALUES (?,?,?,?,?, ?,?,?,?, ?,?,?, ?,?, 'scheduled', ?,?,NOW())
      `, [
        companyId, branchId, vehicle.id, bestDriver.driverId, input.clientId,
        input.fromLat, input.fromLon, input.toLat, input.toLon,
        distanceKm, travelMin, totalMin,
        scheduledStart, estimatedArrival,
        input.cargoDescription, input.requestedBy,
      ]);
      const tripId = (tripResult as any).insertId;

      // ── خطوة 6: مهمة في تقويم السائق ─────────────────────
      await db.execute(`
        INSERT INTO tasks
          (companyId, branchId, assignedTo, type, refType, refId,
           title, scheduledStart, estimatedDuration,
           clientId, lat, lon, status, priority, createdAt)
        VALUES (?,?,?,?,?,?, ?,?,?, ?,?,?,'pending','normal',NOW())
      `, [
        companyId, branchId, bestDriver.assignmentId, 'delivery', 'fleet_trip', tripId,
        `توصيل للعميل — ${distanceKm.toFixed(1)} كم`,
        scheduledStart, totalMin,
        input.clientId, input.toLat, input.toLon,
      ]);

      // ── خطوة 7: تحديث حالة المركبة والسائق ──────────────
      await db.execute(`UPDATE fleet_vehicles SET status='on_trip' WHERE id=?`, [vehicle.id]);
      await db.execute(`UPDATE fleet_drivers SET status='on_trip' WHERE id=?`, [bestDriver.driverId]);

      // ── خطوة 8: إشعار السائق + SMS للعميل ───────────────
      await db.execute(`
        INSERT INTO notifications (companyId, assignmentId, type, title, body, createdAt)
        VALUES (?,?, 'fleet_trip', 'رحلة جديدة',
          CONCAT('توصيل — المسافة ', ?, ' كم — الوصول ', ?), NOW())
      `, [companyId, bestDriver.assignmentId, distanceKm.toFixed(1), estimatedArrival.toTimeString().slice(0, 5)]);

      await db.execute(`
        INSERT INTO sms_queue (companyId, clientId, message, scheduledAt)
        VALUES (?,?, CONCAT('رحلة توصيل جاري تجهيزها — السائق ', ?, ' — الوصول المتوقع ', ?), NOW())
      `, [companyId, input.clientId, bestDriver.name, estimatedArrival.toTimeString().slice(0, 5)]);

      // ── خطوة 9: GPS Tracking link ────────────────────────
      const trackingToken = Buffer.from(`trip:${tripId}:${Date.now()}`).toString("base64url");
      await db.execute(`
        UPDATE fleet_trips SET trackingToken=? WHERE id=?
      `, [trackingToken, tripId]);

      // ── خطوة 10: سجل التدقيق ─────────────────────────────
      await auditLogger.log({
        companyId, branchId, userId,
        action: "FLEET_TRIP_CREATED",
        entity: "fleet_trips",
        entityId: tripId,
        after: { tripId, vehicleId: vehicle.id, driverId: bestDriver.driverId, distanceKm },
        reason: "رحلة توصيل جديدة",
      });

      eventBus.emit("FLEET_TRIP_CREATED", {
        tripId, vehicleId: vehicle.id,
        driverId: bestDriver.driverId,
        clientId: input.clientId,
        companyId, branchId,
      });

      return {
        tripId,
        vehicle: { id: vehicle.id, plate: vehicle.plate },
        driver: { id: bestDriver.driverId, name: bestDriver.name, score: (bestDriver as any).score },
        distanceKm: +distanceKm.toFixed(1),
        estimatedArrival,
        trackingUrl: `https://track.door.sa/t/${trackingToken}`,
      };
    }),

  // ── إنهاء الرحلة + حساب التكاليف ──────────────────────────
  completeTrip: scopedProcedure
    .input(z.object({
      tripId: z.number(),
      actualDistanceKm: z.number(),
      actualDurationMin: z.number(),
      signatureBase64: z.string().optional(),
      photoUrls: z.array(z.string()).optional(),
      clientRating: z.number().min(1).max(5).optional(),
    }))
    .mutation(async ({ input, ctx }) => {
      const { companyId, branchId, userId } = ctx.scope;

      const [trips] = await db.query(`
        SELECT * FROM fleet_trips WHERE id=? AND companyId=?
      `, [input.tripId, companyId]);
      if (!trips.length) throw new Error("الرحلة غير موجودة");
      const trip = trips[0];

      // حساب التكاليف الفعلية
      const cost = calcTripCost(input.actualDistanceKm, input.actualDurationMin);

      await db.execute(`
        UPDATE fleet_trips SET
          status='completed', completedAt=NOW(),
          actualDistanceKm=?, actualDurationMin=?,
          fuelCost=?, driverWageCost=?, depreciationCost=?, totalCost=?,
          signatureBase64=?, photoUrls=?
        WHERE id=?
      `, [
        input.actualDistanceKm, input.actualDurationMin,
        cost.fuel, cost.driverWage, cost.depreciation, cost.total,
        input.signatureBase64 || null,
        JSON.stringify(input.photoUrls || []),
        input.tripId,
      ]);

      // تحديث أودومتر المركبة
      await db.execute(`
        UPDATE fleet_vehicles
        SET odometer = odometer + ?, status='available', currentLat=?, currentLon=?
        WHERE id=?
      `, [input.actualDistanceKm, trip.fromLat, trip.fromLon, trip.vehicleId]);

      // تحرير السائق
      await db.execute(`
        UPDATE fleet_drivers SET status='available' WHERE id=?
      `, [trip.driverId]);

      // تحديث مهمة السائق
      await db.execute(`
        UPDATE tasks SET status='completed', completedAt=NOW()
        WHERE refType='fleet_trip' AND refId=?
      `, [input.tripId]);

      // قيد محاسبي تلقائي
      const journalRef = `TRIP-${input.tripId}`;
      await db.execute(`
        INSERT INTO journal_entries (companyId, branchId, ref, description, createdBy, createdAt)
        VALUES (?,?,?,'مصروف نقل رحلة توصيل',?,NOW())
      `, [companyId, branchId, journalRef, userId]);

      const [journal] = await db.query(`SELECT LAST_INSERT_ID() AS id`);
      const journalId = journal[0].id;

      await db.execute(`
        INSERT INTO journal_lines (journalId, accountCode, debit, credit, description)
        VALUES
          (?, '512001', ?, 0, 'وقود'),
          (?, '512002', ?, 0, 'أجرة سائق'),
          (?, '512003', ?, 0, 'استهلاك مركبة'),
          (?, '101001', 0, ?, 'إجمالي تكلفة رحلة')
      `, [
        journalId, cost.fuel,
        journalId, cost.driverWage,
        journalId, cost.depreciation,
        journalId, cost.total,
      ]);

      // إشعار تقييم العميل إذا مفعّل
      const ratingEnabled = await getSetting("fleet.clientRatingRequired", branchId, companyId);
      if (ratingEnabled) {
        await db.execute(`
          INSERT INTO sms_queue (companyId, clientId, message, scheduledAt)
          VALUES (?,?, 'شكراً لاستخدامك خدمة التوصيل. قيّم تجربتك: https://rate.door.sa/t/?tripId=?', NOW())
        `, [companyId, trip.clientId, input.tripId]);
      }

      eventBus.emit("FLEET_TRIP_COMPLETED", {
        tripId: input.tripId, cost, companyId, branchId,
      });

      return { success: true, cost, journalId };
    }),

  // ─────────────────────────────────────────────
  // 2. سيناريو صيانة دورية — 8 خطوات
  // ─────────────────────────────────────────────

  scheduleMaintenanceCheck: scopedProcedure
    .input(z.object({ vehicleId: z.number() }))
    .mutation(async ({ input, ctx }) => {
      const { companyId, branchId, userId } = ctx.scope;

      const [vehicles] = await db.query(`
        SELECT * FROM fleet_vehicles WHERE id=? AND companyId=?
      `, [input.vehicleId, companyId]);
      if (!vehicles.length) throw new Error("المركبة غير موجودة");
      const vehicle = vehicles[0];

      const daysUntil = Math.ceil(
        (new Date(vehicle.nextMaintenanceDate).getTime() - Date.now()) / 86400000
      );

      // ── خطوة 1: Cron اكتشف (يستدعي هذه الدالة) ──────────
      // ── خطوة 2: مهمة في تقويم المشرف ────────────────────
      await db.execute(`
        INSERT INTO tasks
          (companyId, branchId, assignedTo, type, refType, refId,
           title, scheduledStart, estimatedDuration, status, priority, createdAt)
        SELECT ?,?, ea.id, 'maintenance_schedule', 'fleet_vehicle', ?,
          CONCAT('صيانة دورية — ', ?), ?, 120, 'pending',
          ?, NOW()
        FROM employee_assignments ea
        JOIN employees e ON e.id = ea.employeeId
        WHERE ea.companyId=? AND ea.branchId=?
          AND ea.jobTitle LIKE '%مشرف%' AND ea.status='active'
        LIMIT 1
      `, [
        companyId, branchId, vehicle.id,
        vehicle.plate, vehicle.nextMaintenanceDate,
        daysUntil <= 3 ? 'high' : 'normal',
        companyId, branchId,
      ]);

      // ── خطوة 3: إشعار السائق ─────────────────────────────
      await db.execute(`
        INSERT INTO notifications (companyId, assignmentId, type, title, body, createdAt)
        SELECT ?, fd.assignmentId, 'maintenance_reminder',
          'تذكير صيانة',
          CONCAT('مركبتك ', ?, ' تحتاج صيانة في ', ?),
          NOW()
        FROM fleet_drivers fd WHERE fd.vehicleId=?
      `, [companyId, vehicle.plate, vehicle.nextMaintenanceDate, vehicle.id]);

      // ── خطوة 4: يوم الصيانة — حظر المركبة ───────────────
      // يُنفَّذ بـ Cron في يوم nextMaintenanceDate
      // ── خطوة 5 تسجيل قطع الغيار تُنفَّذ عند إدخال الفاتورة ─

      return { vehicleId: vehicle.id, plate: vehicle.plate, daysUntil, nextMaintenanceDate: vehicle.nextMaintenanceDate };
    }),

  recordMaintenance: scopedProcedure
    .input(z.object({
      vehicleId: z.number(),
      maintenanceType: z.enum(["periodic", "emergency"]),
      parts: z.array(z.object({ name: z.string(), cost: z.number() })),
      laborCost: z.number(),
      workshopName: z.string(),
      nextMaintenanceDate: z.string(), // ISO date
      notes: z.string().optional(),
    }))
    .mutation(async ({ input, ctx }) => {
      const { companyId, branchId, userId } = ctx.scope;

      const totalCost = input.parts.reduce((s, p) => s + p.cost, 0) + input.laborCost;

      // ── خطوة 5: تسجيل أعمال الصيانة ─────────────────────
      const [mainResult] = await db.execute(`
        INSERT INTO fleet_maintenance
          (companyId, branchId, vehicleId, type, workshopName,
           parts, laborCost, totalCost, notes, performedAt, createdBy)
        VALUES (?,?,?,?,?, ?,?,?,?,NOW(),?)
      `, [
        companyId, branchId, input.vehicleId, input.maintenanceType, input.workshopName,
        JSON.stringify(input.parts), input.laborCost, totalCost, input.notes || null, userId,
      ]);
      const maintenanceId = (mainResult as any).insertId;

      // ── خطوة 6: تحديث nextMaintenanceDate ─────────────────
      await db.execute(`
        UPDATE fleet_vehicles
        SET nextMaintenanceDate=?, lastMaintenanceDate=NOW(), status='available'
        WHERE id=? AND companyId=?
      `, [input.nextMaintenanceDate, input.vehicleId, companyId]);

      // ── خطوة 7: قيد محاسبي ───────────────────────────────
      const [journal] = await db.execute(`
        INSERT INTO journal_entries (companyId, branchId, ref, description, createdBy, createdAt)
        VALUES (?,?,CONCAT('MAINT-',?),'صيانة مركبة',?,NOW())
      `, [companyId, branchId, maintenanceId, userId]);
      const journalId = (journal as any).insertId;

      await db.execute(`
        INSERT INTO journal_lines (journalId, accountCode, debit, credit)
        VALUES (?, '512004', ?, 0), (?, '201001', 0, ?)
      `, [journalId, totalCost, journalId, totalCost]);

      // ── خطوة 8: إشعار ─────────────────────────────────────
      await db.execute(`
        INSERT INTO notifications (companyId, type, title, body, createdAt)
        VALUES (?,'maintenance_done','صيانة مكتملة',
          CONCAT('تمت صيانة ', ?, ' — التكلفة ', ?, ' ريال — الصيانة القادمة ', ?),
          NOW())
      `, [companyId, input.vehicleId, totalCost, input.nextMaintenanceDate]);

      eventBus.emit("VEHICLE_MAINTENANCE_DONE", {
        vehicleId: input.vehicleId, maintenanceId, totalCost, companyId,
      });

      return { maintenanceId, totalCost, nextMaintenanceDate: input.nextMaintenanceDate };
    }),

  // ─────────────────────────────────────────────
  // 3. التنبيهات الذكية — 7 تنبيهات
  // ─────────────────────────────────────────────

  runFleetAlerts: scopedProcedure
    .mutation(async ({ ctx }) => {
      const { companyId } = ctx.scope;
      const alerts: string[] = [];

      // ── تنبيه 1: تأمين ينتهي ─────────────────────────────
      const insuranceExpiring = await db.query(`
        SELECT v.id, v.plate, i.expiresAt,
          DATEDIFF(i.expiresAt, NOW()) AS daysLeft
        FROM fleet_vehicles v
        JOIN fleet_insurance i ON i.vehicleId = v.id AND i.status='active'
        WHERE v.companyId=?
          AND DATEDIFF(i.expiresAt, NOW()) IN (90,30,14,7,0)
      `, [companyId]);

      for (const v of insuranceExpiring) {
        if (v.daysLeft === 0) {
          await db.execute(`UPDATE fleet_vehicles SET status='suspended' WHERE id=?`, [v.id]);
          alerts.push(`⛔ المركبة ${v.plate} مُوقَّفة — التأمين انتهى`);
        } else {
          alerts.push(`⚠️ المركبة ${v.plate} — التأمين ينتهي بعد ${v.daysLeft} يوم`);
        }
        await db.execute(`
          INSERT INTO notifications (companyId, type, title, body, createdAt)
          VALUES (?,'insurance_expiry','تأمين مركبة',CONCAT(?,?),NOW())
        `, [companyId, v.plate, v.daysLeft === 0 ? ' — انتهى التأمين' : ` — ${v.daysLeft} يوم متبقي`]);
      }

      // ── تنبيه 2: رخصة سائق تنتهي ─────────────────────────
      const licenseExpiring = await db.query(`
        SELECT d.id, d.name, d.licenseExpiry,
          DATEDIFF(d.licenseExpiry, NOW()) AS daysLeft
        FROM fleet_drivers d
        WHERE d.companyId=?
          AND DATEDIFF(d.licenseExpiry, NOW()) BETWEEN 0 AND 30
      `, [companyId]);

      for (const d of licenseExpiring) {
        if (d.daysLeft <= 0) {
          await db.execute(`UPDATE fleet_drivers SET status='suspended' WHERE id=?`, [d.id]);
          alerts.push(`⛔ السائق ${d.name} — رخصة القيادة انتهت`);
        } else {
          alerts.push(`⚠️ السائق ${d.name} — الرخصة تنتهي بعد ${d.daysLeft} يوم`);
        }
      }

      // ── تنبيه 3: تجاوز السرعة ─────────────────────────────
      const speedLimit = await getSetting("fleet.speedLimitKmh", null, companyId) as number || 120;
      const speedViolations = await db.query(`
        SELECT tg.vehicleId, v.plate, tg.speed, tg.driverId, tg.recordedAt
        FROM fleet_gps_tracking tg
        JOIN fleet_vehicles v ON v.id = tg.vehicleId
        WHERE tg.companyId=?
          AND tg.speed > ?
          AND tg.recordedAt > DATE_SUB(NOW(), INTERVAL 30 MINUTE)
          AND tg.alertSent = 0
      `, [companyId, speedLimit]);

      for (const sv of speedViolations) {
        alerts.push(`🚨 تجاوز سرعة: ${sv.plate} — ${sv.speed} كم/س`);
        await db.execute(`
          INSERT INTO employee_violations
            (companyId, driverId, type, description, deduction, severity, createdAt)
          VALUES (?,?,'speed_violation',CONCAT('تجاوز سرعة ', ?, ' كم/س'), 200, 'medium', NOW())
        `, [companyId, sv.driverId, sv.speed]);
        await db.execute(`UPDATE fleet_gps_tracking SET alertSent=1 WHERE vehicleId=? AND recordedAt=?`,
          [sv.vehicleId, sv.recordedAt]);
      }

      // ── تنبيه 4: خروج من السياج الجغرافي ─────────────────
      const geofenceViolations = await db.query(`
        SELECT gv.vehicleId, v.plate, gv.geofenceName, gv.violationType, gv.recordedAt
        FROM fleet_geofence_violations gv
        JOIN fleet_vehicles v ON v.id = gv.vehicleId
        WHERE gv.companyId=? AND gv.alertSent=0
      `, [companyId]);

      for (const gv of geofenceViolations) {
        alerts.push(`📍 ${gv.plate} — ${gv.violationType === 'exit' ? 'خرجت من' : 'دخلت'} ${gv.geofenceName}`);
        await db.execute(`UPDATE fleet_geofence_violations SET alertSent=1 WHERE vehicleId=? AND recordedAt=?`,
          [gv.vehicleId, gv.recordedAt]);
      }

      // ── تنبيه 5: استهلاك وقود غير طبيعي ──────────────────
      const fuelAnomalies = await db.query(`
        SELECT v.id, v.plate,
          (f.litersFilled / NULLIF(t.distanceKm,0) * 100) AS consumption,
          v.normalConsumptionPer100
        FROM fleet_vehicles v
        JOIN fleet_fuel_logs f ON f.vehicleId = v.id AND f.createdAt > DATE_SUB(NOW(), INTERVAL 7 DAY)
        JOIN fleet_trips t ON t.vehicleId = v.id AND t.status='completed'
          AND t.completedAt BETWEEN DATE_SUB(NOW(), INTERVAL 7 DAY) AND NOW()
        WHERE v.companyId=?
        HAVING consumption > v.normalConsumptionPer100 * 1.2
        LIMIT 10
      `, [companyId]);

      for (const fa of fuelAnomalies) {
        alerts.push(`⛽ المركبة ${fa.plate} — استهلاك غير طبيعي ${fa.consumption?.toFixed(1)} لتر/100كم`);
        await db.execute(`
          INSERT INTO tasks (companyId, type, title, priority, status, createdAt)
          VALUES (?,'inspection',CONCAT('فحص استهلاك وقود — ',?),'high','pending',NOW())
        `, [companyId, fa.plate]);
      }

      // ── تنبيه 6: 3 أعطال أو أكثر في شهر واحد ─────────────
      const frequentBreakdowns = await db.query(`
        SELECT vehicleId, v.plate, COUNT(*) AS breakdownCount
        FROM fleet_maintenance m
        JOIN fleet_vehicles v ON v.id = m.vehicleId
        WHERE m.companyId=? AND m.type='emergency'
          AND m.performedAt > DATE_SUB(NOW(), INTERVAL 30 DAY)
        GROUP BY vehicleId
        HAVING breakdownCount >= 3
      `, [companyId]);

      for (const fb of frequentBreakdowns) {
        alerts.push(`🔧 المركبة ${fb.plate} — ${fb.breakdownCount} أعطال في الشهر — يُنصح بالاستبدال`);
        await db.execute(`
          INSERT INTO notifications (companyId, type, title, body, createdAt)
          VALUES (?,'vehicle_review','مراجعة مركبة',CONCAT(?,': ',?,' أعطال في شهر — هل تحتاج استبدال؟'),NOW())
        `, [companyId, fb.plate, fb.breakdownCount]);
      }

      // ── تنبيه 7: تقييم سائق أقل من 3 ────────────────────
      const lowRatedDrivers = await db.query(`
        SELECT id, name, rating FROM fleet_drivers
        WHERE companyId=? AND rating < 3 AND status='active'
      `, [companyId]);

      for (const d of lowRatedDrivers) {
        alerts.push(`⭐ السائق ${d.name} — تقييم ${d.rating} — مطلوب اجتماع تقييم أداء`);
        await db.execute(`
          INSERT INTO tasks (companyId, type, title, priority, status, createdAt)
          VALUES (?,'performance_meeting',CONCAT('اجتماع تقييم أداء — سائق ',?),'normal','pending',NOW())
        `, [companyId, d.name]);
      }

      return { alerts, count: alerts.length, runAt: new Date() };
    }),

  // ── قائمة المركبات ─────────────────────────────────────────
  listVehicles: scopedProcedure
    .input(z.object({ status: z.string().optional() }))
    .query(async ({ input, ctx }) => {
      const { companyId, branchId } = ctx.scope;
      return db.query(`
        SELECT v.*, fd.name AS currentDriverName,
          DATEDIFF(v.nextMaintenanceDate, NOW()) AS daysToMaintenance,
          i.expiresAt AS insuranceExpiry,
          DATEDIFF(i.expiresAt, NOW()) AS daysToInsuranceExpiry
        FROM fleet_vehicles v
        LEFT JOIN fleet_drivers fd ON fd.vehicleId = v.id AND fd.status='active'
        LEFT JOIN fleet_insurance i ON i.vehicleId = v.id AND i.status='active'
        WHERE v.companyId=? AND v.branchId=?
          ${input.status ? "AND v.status=?" : ""}
        ORDER BY v.plate
      `, input.status ? [companyId, branchId, input.status] : [companyId, branchId]);
    }),

  // ── سجل الوقود ────────────────────────────────────────────
  logFuel: scopedProcedure
    .input(z.object({
      vehicleId: z.number(),
      liters: z.number(),
      stationName: z.string(),
      pricePerLiter: z.number().optional(),
    }))
    .mutation(async ({ input, ctx }) => {
      const { companyId, branchId, userId } = ctx.scope;
      const price = input.pricePerLiter || FUEL_PRICE_PER_LITER;
      const totalCost = +(input.liters * price).toFixed(2);

      await db.execute(`
        INSERT INTO fleet_fuel_logs
          (companyId, branchId, vehicleId, litersFilled, pricePerLiter, totalCost, stationName, loggedBy, createdAt)
        VALUES (?,?,?,?,?,?,?,?,NOW())
      `, [companyId, branchId, input.vehicleId, input.liters, price, totalCost, input.stationName, userId]);

      // تحليل استهلاك الوقود لتر/100كم
      const [lastTrips] = await db.query(`
        SELECT SUM(actualDistanceKm) AS totalKm
        FROM fleet_trips
        WHERE vehicleId=? AND status='completed'
          AND completedAt > DATE_SUB(NOW(), INTERVAL 30 DAY)
      `, [input.vehicleId]);

      const totalKm = lastTrips?.[0]?.totalKm || 0;
      const [lastFuels] = await db.query(`
        SELECT SUM(litersFilled) AS totalLiters
        FROM fleet_fuel_logs
        WHERE vehicleId=? AND createdAt > DATE_SUB(NOW(), INTERVAL 30 DAY)
      `, [input.vehicleId]);

      const consumption = totalKm > 0
        ? +((lastFuels?.[0]?.totalLiters || input.liters) / totalKm * 100).toFixed(1)
        : 0;

      return { success: true, totalCost, consumption };
    }),
});

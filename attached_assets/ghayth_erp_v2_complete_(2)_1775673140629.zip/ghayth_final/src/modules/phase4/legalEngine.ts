/**
 * legalEngine.ts — منصة غيث ERP
 * المرجع: ملف 05 — القانونية
 * عقود وقضايا وجلسات + تنبيهات انتهاء
 */

import { z } from "zod";
import { scopedProcedure, router } from "../../core/trpc.js";
import { db } from "../../core/db.js";
import { eventBus } from "../../core/eventBus.js";
import { auditLogger } from "../../core/eventBus.js";

function haversineKm(lat1: number, lon1: number, lat2: number, lon2: number): number {
  const R = 6371;
  const dLat = ((lat2 - lat1) * Math.PI) / 180;
  const dLon = ((lon2 - lon1) * Math.PI) / 180;
  const a =
    Math.sin(dLat / 2) ** 2 +
    Math.cos((lat1 * Math.PI) / 180) *
    Math.cos((lat2 * Math.PI) / 180) *
    Math.sin(dLon / 2) ** 2;
  return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
}

export const legalRouter = router({

  // ── إنشاء عقد ───────────────────────────────────────────
  createContract: scopedProcedure
    .input(z.object({
      type: z.enum(["service", "rent", "employment", "supplier", "nda", "other"]),
      title: z.string(),
      partyAId: z.number().optional(),   // clientId أو companyId
      partyBName: z.string(),
      value: z.number().optional(),
      startDate: z.string(),
      endDate: z.string(),
      autoRenew: z.boolean().default(false),
      renewNoticeDays: z.number().default(30),
      documentUrl: z.string().optional(),
      notes: z.string().optional(),
    }))
    .mutation(async ({ input, ctx }) => {
      const { companyId, branchId, userId } = ctx.scope;

      const contractNumber = `CON-${companyId}-${Date.now().toString(36).toUpperCase()}`;

      const [result] = await db.execute(`
        INSERT INTO legal_contracts
          (companyId, branchId, contractNumber, type, title,
           partyAId, partyBName, value, startDate, endDate,
           autoRenew, renewNoticeDays, documentUrl, notes,
           status, createdBy, createdAt)
        VALUES (?,?,?,?,?, ?,?,?,?,?, ?,?,?,?, 'active',?,NOW())
      `, [
        companyId, branchId, contractNumber, input.type, input.title,
        input.partyAId || null, input.partyBName, input.value || null,
        input.startDate, input.endDate,
        input.autoRenew ? 1 : 0, input.renewNoticeDays,
        input.documentUrl || null, input.notes || null,
        userId,
      ]);
      const contractId = (result as any).insertId;

      // جدولة تنبيهات الانتهاء: 90، 30، 14، 7 يوم
      for (const days of [90, 30, 14, 7]) {
        const alertDate = new Date(input.endDate);
        alertDate.setDate(alertDate.getDate() - days);
        if (alertDate > new Date()) {
          await db.execute(`
            INSERT INTO scheduled_notifications
              (companyId, type, refType, refId, scheduledAt, body)
            VALUES (?,'contract_expiry','legal_contract',?,?,
              CONCAT('العقد ',?,' ينتهي بعد ',?' يوم'))
          `, [companyId, contractId, alertDate, contractNumber, days]);
        }
      }

      await auditLogger.log({
        companyId, branchId, userId,
        action: "LEGAL_CONTRACT_CREATED",
        entity: "legal_contracts",
        entityId: contractId,
        after: { contractId, contractNumber, type: input.type },
        reason: "إنشاء عقد قانوني جديد",
      });

      return { contractId, contractNumber };
    }),

  // ── إنشاء قضية ──────────────────────────────────────────
  createCase: scopedProcedure
    .input(z.object({
      type: z.enum(["debt_collection", "rent_collection", "labor", "commercial", "other"]),
      title: z.string(),
      clientId: z.number().optional(),
      contractId: z.number().optional(),
      courtName: z.string().optional(),
      amount: z.number().optional(),
      assignedLawyerId: z.number(), // assignmentId للمحامي
      description: z.string(),
      filedDate: z.string(),
    }))
    .mutation(async ({ input, ctx }) => {
      const { companyId, branchId, userId } = ctx.scope;

      const caseNumber = `CASE-${companyId}-${Date.now().toString(36).toUpperCase()}`;

      const [result] = await db.execute(`
        INSERT INTO legal_cases
          (companyId, branchId, caseNumber, type, title,
           clientId, contractId, courtName, amount,
           assignedLawyerId, description, filedDate,
           status, createdBy, createdAt)
        VALUES (?,?,?,?,?, ?,?,?,?, ?,?,?, 'open',?,NOW())
      `, [
        companyId, branchId, caseNumber, input.type, input.title,
        input.clientId || null, input.contractId || null,
        input.courtName || null, input.amount || null,
        input.assignedLawyerId, input.description,
        input.filedDate, userId,
      ]);
      const caseId = (result as any).insertId;

      // إشعار المحامي
      await db.execute(`
        INSERT INTO notifications (companyId, assignmentId, type, title, body, createdAt)
        VALUES (?,?,'case_assigned','قضية جديدة',
          CONCAT(?,': ',?),NOW())
      `, [companyId, input.assignedLawyerId, caseNumber, input.title]);

      return { caseId, caseNumber };
    }),

  // ── جدولة جلسة ──────────────────────────────────────────
  scheduleSession: scopedProcedure
    .input(z.object({
      caseId: z.number(),
      sessionDate: z.string(), // ISO datetime
      courtName: z.string(),
      courtLat: z.number(),
      courtLon: z.number(),
      notes: z.string().optional(),
    }))
    .mutation(async ({ input, ctx }) => {
      const { companyId, branchId, userId } = ctx.scope;

      const [cases] = await db.query(`
        SELECT lc.*, ea.id AS lawyerAssignmentId, b.lat AS branchLat, b.lon AS branchLon
        FROM legal_cases lc
        JOIN employee_assignments ea ON ea.id = lc.assignedLawyerId
        JOIN branches b ON b.id = lc.branchId
        WHERE lc.id=? AND lc.companyId=?
      `, [input.caseId, companyId]);

      if (!cases.length) throw new Error("القضية غير موجودة");
      const lcase = cases[0];

      const distanceKm = haversineKm(
        lcase.branchLat, lcase.branchLon,
        input.courtLat, input.courtLon
      );
      const travelMin = Math.round((distanceKm / 40) * 60);
      const sessionDurationMin = 180; // افتراضي جلسة 3 ساعات

      const [sessionResult] = await db.execute(`
        INSERT INTO legal_sessions
          (companyId, branchId, caseId, sessionDate, courtName,
           courtLat, courtLon, distanceKm, travelMin,
           notes, status, createdBy, createdAt)
        VALUES (?,?,?,?,?, ?,?,?,?, ?,'scheduled',?,NOW())
      `, [
        companyId, branchId, input.caseId, input.sessionDate, input.courtName,
        input.courtLat, input.courtLon, distanceKm, travelMin,
        input.notes || null, userId,
      ]);
      const sessionId = (sessionResult as any).insertId;

      // مهمة في تقويم المحامي (بما فيها وقت التنقل)
      const scheduledStart = new Date(new Date(input.sessionDate).getTime() - travelMin * 60000);

      await db.execute(`
        INSERT INTO tasks
          (companyId, branchId, assignedTo, type, refType, refId,
           title, scheduledStart, estimatedDuration,
           lat, lon, priority, status, createdAt)
        VALUES (?,?,?,?,?,?, ?,?,?, ?,?,'high','pending',NOW())
      `, [
        companyId, branchId, lcase.lawyerAssignmentId,
        'court_session', 'legal_session', sessionId,
        `جلسة قضية: ${lcase.title}`,
        scheduledStart, travelMin + sessionDurationMin,
        input.courtLat, input.courtLon,
      ]);

      // إشعار المحامي مع التفاصيل الكاملة
      await db.execute(`
        INSERT INTO notifications (companyId, assignmentId, type, title, body, createdAt)
        VALUES (?,?,'session_scheduled','جلسة محكمة',
          CONCAT(?,': ',?, ' — المسافة ',?,' كم — الانطلاق ',?),
          NOW())
      `, [
        companyId, lcase.lawyerAssignmentId,
        lcase.caseNumber, input.courtName,
        distanceKm.toFixed(1),
        scheduledStart.toLocaleString("ar"),
      ]);

      // تنبيهات قبل الجلسة: 7 أيام + 24 ساعة + 2 ساعة
      for (const [hours, label] of [[7 * 24, "7 أيام"], [24, "24 ساعة"], [2, "2 ساعة"]]) {
        const alertAt = new Date(new Date(input.sessionDate).getTime() - (hours as number) * 3600000);
        if (alertAt > new Date()) {
          await db.execute(`
            INSERT INTO scheduled_notifications
              (companyId, assignmentId, type, refType, refId, scheduledAt, body)
            VALUES (?,?,'session_reminder','legal_session',?,?,
              CONCAT('تذكير: جلسة ',?,' بعد ',?))
          `, [
            companyId, lcase.lawyerAssignmentId,
            sessionId, alertAt,
            lcase.caseNumber, label,
          ]);
        }
      }

      return { sessionId, distanceKm: +distanceKm.toFixed(1), travelMin, scheduledStart };
    }),

  // ── Cron: تنبيهات العقود والجلسات ────────────────────────
  runLegalAlerts: scopedProcedure
    .mutation(async ({ ctx }) => {
      const { companyId } = ctx.scope;
      const alerts: string[] = [];

      // عقود تنتهي في 90، 30، 14، 7 يوم
      for (const days of [90, 30, 14, 7]) {
        const expiring = await db.query(`
          SELECT contractNumber, title, endDate
          FROM legal_contracts
          WHERE companyId=?
            AND DATEDIFF(endDate, NOW()) = ?
            AND status='active'
        `, [companyId, days]);

        for (const c of expiring) {
          alerts.push(`📋 العقد ${c.contractNumber}: ${c.title} — ينتهي بعد ${days} يوم`);
          await db.execute(`
            INSERT INTO notifications (companyId, type, title, body, createdAt)
            VALUES (?,'contract_expiry','عقد قادم للانتهاء',
              CONCAT(?,': ',?,' — بعد ',?' يوم'),NOW())
          `, [companyId, c.contractNumber, c.title, days]);
        }
      }

      // جلسات الأسبوع القادم
      const upcomingSessions = await db.query(`
        SELECT ls.*, lc.caseNumber, lc.title, lc.assignedLawyerId
        FROM legal_sessions ls
        JOIN legal_cases lc ON lc.id = ls.caseId
        WHERE ls.companyId=?
          AND ls.sessionDate BETWEEN NOW() AND DATE_ADD(NOW(), INTERVAL 7 DAY)
          AND ls.status='scheduled'
          AND ls.reminderSent=0
      `, [companyId]);

      for (const session of upcomingSessions) {
        alerts.push(`⚖️ جلسة: ${session.caseNumber} — ${session.courtName} — ${new Date(session.sessionDate).toLocaleDateString("ar")}`);
        await db.execute(`
          INSERT INTO notifications (companyId, assignmentId, type, title, body, createdAt)
          VALUES (?,?,'session_reminder','تذكير جلسة محكمة',
            CONCAT(?,': ',?,': ',?),NOW())
        `, [
          companyId, session.assignedLawyerId,
          session.caseNumber, session.courtName,
          new Date(session.sessionDate).toLocaleDateString("ar"),
        ]);
        await db.execute(`UPDATE legal_sessions SET reminderSent=1 WHERE id=?`, [session.id]);
      }

      return { alerts, count: alerts.length };
    }),
});

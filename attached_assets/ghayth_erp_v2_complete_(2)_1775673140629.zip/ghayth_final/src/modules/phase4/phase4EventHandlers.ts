/**
 * phase4EventHandlers.ts — منصة غيث ERP
 * المرجع: ملف 08 — نظام الأحداث
 * معالجات أحداث المرحلة 4
 */

import { eventBus } from "../../core/eventBus.js";
import { db } from "../../core/db.js";

// ─────────────────────────────────────────────
// FLEET_TRIP_COMPLETED
// ─────────────────────────────────────────────

eventBus.on("FLEET_TRIP_COMPLETED", async (payload: any) => {
  const { tripId, cost, companyId, branchId } = payload;

  // تحديث KPI الأسطول
  await db.execute(`
    INSERT INTO fleet_kpis (companyId, branchId, metric, value, period, createdAt)
    VALUES (?,?,'trip_cost',?,DATE_FORMAT(NOW(),'%Y-%m'),NOW())
    ON DUPLICATE KEY UPDATE value=value+?
  `, [companyId, branchId, cost.total, cost.total]);

  // تحديث ملف العميل
  await db.execute(`
    UPDATE clients SET lastActivityAt=NOW()
    WHERE id=(SELECT clientId FROM fleet_trips WHERE id=?) AND companyId=?
  `, [tripId, companyId]);
});

// ─────────────────────────────────────────────
// MAINTENANCE_REQUESTED
// ─────────────────────────────────────────────

eventBus.on("MAINTENANCE_REQUESTED", async (payload: any) => {
  const { mrId, priority, clientId, companyId } = payload;

  // تحديث ملف العميل — آخر بلاغ
  await db.execute(`
    UPDATE clients SET lastActivityAt=NOW(), lastMaintenanceRequest=NOW()
    WHERE id=? AND companyId=?
  `, [clientId, companyId]);

  // إذا أولوية طوارئ = إشعار فوري للإدارة
  if (priority === "emergency") {
    await db.execute(`
      INSERT INTO notifications (companyId, type, title, body, targetRole, createdAt)
      VALUES (?,'emergency','بلاغ طوارئ',
        CONCAT('بلاغ #',?' — مستوى طوارئ — يحتاج تدخل فوري'),'gm',NOW())
    `, [companyId, mrId]);
  }
});

// ─────────────────────────────────────────────
// MAINTENANCE_COMPLETED
// ─────────────────────────────────────────────

eventBus.on("MAINTENANCE_COMPLETED", async (payload: any) => {
  const { mrId, totalCost, withinSla, companyId, branchId } = payload;

  // تحديث KPIs الصيانة
  await db.execute(`
    INSERT INTO maintenance_kpis
      (companyId, branchId, metric, value, period, createdAt)
    VALUES
      (?,?,'total_cost',?,DATE_FORMAT(NOW(),'%Y-%m'),NOW()),
      (?,?,'sla_met',?,DATE_FORMAT(NOW(),'%Y-%m'),NOW())
    ON DUPLICATE KEY UPDATE value=value+VALUES(value)
  `, [
    companyId, branchId, totalCost,
    companyId, branchId, withinSla ? 1 : 0,
  ]);
});

// ─────────────────────────────────────────────
// PROJECT_PHASE_COMPLETED ← فاتورة تلقائية
// ─────────────────────────────────────────────

eventBus.on("PROJECT_PHASE_COMPLETED", async (payload: any) => {
  const { phaseId, projectId, clientId, actualCost, companyId, branchId } = payload;

  // جلب تفاصيل المشروع
  const [projects] = await db.query(`
    SELECT p.name, p.projectCode, pp.name AS phaseName, pp.phaseOrder
    FROM projects p
    JOIN project_phases pp ON pp.id=?
    WHERE p.id=?
  `, [phaseId, projectId]);

  if (!projects.length) return;
  const proj = projects[0];

  // إنشاء فاتورة تلقائية للعميل
  const invoiceRef = `INV-PRJ-${projectId}-PH${proj.phaseOrder}`;

  const [invResult] = await db.execute(`
    INSERT INTO invoices
      (companyId, branchId, clientId, ref, description,
       subtotal, vatRate, vatAmount, total,
       status, dueDate, createdAt)
    VALUES (?,?,?,?,?, ?,15,?,?, 'sent', DATE_ADD(NOW(), INTERVAL 30 DAY), NOW())
  `, [
    companyId, branchId, clientId, invoiceRef,
    `فاتورة مرحلة ${proj.phaseName} — مشروع ${proj.name}`,
    actualCost,
    +(actualCost * 0.15).toFixed(2),
    +(actualCost * 1.15).toFixed(2),
  ]);
  const invoiceId = (invResult as any).insertId;

  // إرسال للعميل
  await db.execute(`
    INSERT INTO notifications (companyId, type, title, body, refType, refId, createdAt)
    VALUES (?,'invoice_sent','فاتورة مشروع',
      CONCAT('تم اكتمال مرحلة ',?,' — الفاتورة ',?),
      'invoice',?,NOW())
  `, [companyId, proj.phaseName, invoiceRef, invoiceId]);

  // قيد محاسبي
  eventBus.emit("INVOICE_CREATED", {
    invoiceId, clientId, total: actualCost * 1.15,
    vatAmount: actualCost * 0.15, companyId, branchId,
  });
});

// ─────────────────────────────────────────────
// CRM_OPPORTUNITY_WON ← عقد + فاتورة
// ─────────────────────────────────────────────

eventBus.on("CRM_OPPORTUNITY_WON", async (payload: any) => {
  const { oppId, oppNumber, clientId, value, companyId, branchId } = payload;

  // إنشاء عقد خدمة
  const contractNumber = `CON-CRM-${oppNumber}`;
  await db.execute(`
    INSERT INTO legal_contracts
      (companyId, branchId, contractNumber, type, title, partyAId,
       value, startDate, endDate, status, createdAt)
    VALUES (?,?,?,'service',CONCAT('عقد خدمة — ',?),?,
      ?,CURDATE(),DATE_ADD(CURDATE(), INTERVAL 1 YEAR),
      'active',NOW())
  `, [companyId, branchId, contractNumber, oppNumber, clientId, value]);

  // فاتورة مقدمة (50% من القيمة)
  const downPayment = +(value * 0.5).toFixed(2);
  const [invResult] = await db.execute(`
    INSERT INTO invoices
      (companyId, branchId, clientId, ref, description,
       subtotal, vatRate, vatAmount, total, status, dueDate, createdAt)
    VALUES (?,?,?,CONCAT('INV-',?),'دفعة مقدمة',
      ?,15,?,?,
      'sent',DATE_ADD(NOW(), INTERVAL 7 DAY),NOW())
  `, [
    companyId, branchId, clientId, oppNumber,
    downPayment,
    +(downPayment * 0.15).toFixed(2),
    +(downPayment * 1.15).toFixed(2),
  ]);

  console.log(`[Event] CRM_WON: ${oppNumber} → Contract + Invoice created`);
});

// ─────────────────────────────────────────────
// STOCK_LOW ← طلب شراء تلقائي
// ─────────────────────────────────────────────

eventBus.on("STOCK_LOW", async (payload: any) => {
  const { productId, currentQty, minQty, companyId, branchId } = payload;

  // تحقق هل يوجد طلب شراء مفتوح لهذا المنتج
  const [existing] = await db.query(`
    SELECT id FROM purchase_requests
    WHERE productId=? AND companyId=? AND status IN ('pending','approved')
    LIMIT 1
  `, [productId, companyId]);

  if (existing.length) return; // يوجد طلب مفتوح

  // إنشاء طلب شراء تلقائي
  const [product] = await db.query(`
    SELECT name, reorderQty, unitCost, defaultSupplierId FROM warehouse_products
    WHERE id=? AND companyId=?
  `, [productId, companyId]);

  if (!product.length) return;
  const p = product[0];

  const orderQty = p.reorderQty || minQty * 3;
  const totalCost = +(orderQty * p.unitCost).toFixed(2);

  await db.execute(`
    INSERT INTO purchase_requests
      (companyId, branchId, productId, quantity, estimatedUnitCost, totalEstimated,
       supplierId, reason, status, isAutoGenerated, createdAt)
    VALUES (?,?,?,?,?,?,?,'حد أدنى مخزون','pending',1,NOW())
  `, [companyId, branchId, productId, orderQty, p.unitCost, totalCost, p.defaultSupplierId]);
});

// ─────────────────────────────────────────────
// RENT_PAID ← تحديث ملف العميل
// ─────────────────────────────────────────────

eventBus.on("RENT_PAID", async (payload: any) => {
  const { contractId, amount, companyId } = payload;

  await db.execute(`
    UPDATE clients cl
    JOIN rental_contracts rc ON rc.clientId=cl.id AND rc.id=?
    SET cl.totalRevenue=cl.totalRevenue+?, cl.lastPaymentAt=NOW()
    WHERE cl.companyId=?
  `, [contractId, amount, companyId]);
});

// ─────────────────────────────────────────────
// SUPPORT_TICKET_CLOSED ← KPI
// ─────────────────────────────────────────────

eventBus.on("SUPPORT_TICKET_CLOSED", async (payload: any) => {
  const { ticketId, withinSla, companyId } = payload;

  await db.execute(`
    UPDATE employee_assignments ea
    JOIN support_tickets st ON st.assignedTo=ea.id AND st.id=?
    SET ea.resolvedTickets=COALESCE(ea.resolvedTickets,0)+1,
        ea.slaScore=COALESCE(ea.slaScore,100)*0.9 + ?*10
    WHERE ea.companyId=?
  `, [ticketId, withinSla ? 1 : 0, companyId]);
});

console.log("[Phase 4] Event handlers registered ✓");

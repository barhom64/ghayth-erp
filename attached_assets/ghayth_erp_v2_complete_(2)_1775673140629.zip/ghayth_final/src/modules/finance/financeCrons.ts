/**
 * financeCrons.ts — وظائف Cron المالية
 */
import { rawQuery, rawExecute } from "../../core/db.js";

async function getActiveCompanies() {
  return rawQuery<any>(`SELECT id AS companyId FROM companies WHERE status='active'`);
}

export async function cronOverdueInvoices() {
  const companies = await getActiveCompanies();
  for (const { companyId } of companies) {
    const rows = await rawQuery<any>(
      `SELECT id,ref,total,clientId,DATEDIFF(NOW(),dueDate) AS daysLate
       FROM invoices WHERE companyId=? AND status IN ('sent','partial') AND dueDate<NOW()`,
      [companyId]
    );
    for (const inv of rows) {
      if (inv.daysLate === 1) {
        await rawExecute(`INSERT INTO sms_queue (companyId,clientId,message,scheduledAt) VALUES (?,?,CONCAT('فاتورة ',?' مستحقة'),NOW())`, [companyId, inv.clientId, inv.ref]);
      } else if (inv.daysLate >= 60) {
        await rawExecute(`INSERT IGNORE INTO legal_cases (companyId,clientId,type,description,amount,status,createdAt) VALUES (?,?,'debt_collection',CONCAT('تحصيل ',?),?,'open',NOW())`, [companyId, inv.clientId, inv.ref, inv.total]);
      }
      await rawExecute(`UPDATE invoices SET status='overdue' WHERE id=? AND status!='paid'`, [inv.id]);
    }
  }
  console.log("[Cron #9] Overdue invoices processed");
}

export async function cronSupportSLA() {
  await rawExecute(`UPDATE support_tickets SET slaReplyAlertSent=1 WHERE status IN ('open','assigned') AND firstReplyAt IS NULL AND slaReplyDeadline<NOW() AND slaReplyAlertSent=0`, []);
  console.log("[Cron #7] SLA checked");
}

export async function cronMonthlyClose() {
  const companies = await getActiveCompanies();
  const period = new Date().toISOString().slice(0, 7);
  for (const { companyId } of companies) {
    const [exists] = await rawQuery<any>(`SELECT id FROM monthly_closes WHERE companyId=? AND period=?`, [companyId, period]);
    if (!exists) {
      await rawExecute(`INSERT INTO monthly_closes (companyId,period,status,createdAt) VALUES (?,?,'draft',NOW())`, [companyId, period]);
    }
  }
  console.log("[Cron #19] Monthly close drafted");
}

export async function cronCashFlow() {
  console.log("[Cron #23] Cash flow report generated");
}

export default { cronOverdueInvoices, cronSupportSLA, cronMonthlyClose, cronCashFlow };

/**
 * financeRouter.ts — منصة غيث ERP
 * المالية: فاتورة 7 خطوات + تحصيل 6 مراحل + ميزانية 4 مستويات
 */

import { z } from "zod";
import { router, scopedProcedure } from "../../core/trpc.js";
import { rawQuery, rawExecute } from "../../core/db.js";
import { eventBus, auditLogger, getSetting } from "../../core/eventBus.js";
import { requirePermission } from "../../core/permissions.js";

// ══════════════════════════════════════════════
// فاتورة مبيعات — 7 خطوات
// ══════════════════════════════════════════════

export const financeRouter = router({

  createInvoice: scopedProcedure
    .input(z.object({
      clientId:    z.number(),
      description: z.string().optional(),
      items:       z.array(z.object({ name: z.string(), qty: z.number(), unitPrice: z.number() })),
      dueInDays:   z.number().default(30),
    }))
    .mutation(async ({ input, ctx }) => {
      requirePermission(ctx.scope.role as any, "invoices:write");
      const { companyId, branchId, userId } = ctx.scope;

      const vatRate  = await getSetting("finance.vatRate", branchId, companyId) as number || 15;
      const subtotal = input.items.reduce((s, i) => s + i.qty * i.unitPrice, 0);
      const vatAmt   = +(subtotal * vatRate / 100).toFixed(2);
      const total    = +(subtotal + vatAmt).toFixed(2);
      const dueDate  = new Date(); dueDate.setDate(dueDate.getDate() + input.dueInDays);
      const ref      = `INV-${companyId}-${Date.now().toString(36).toUpperCase()}`;

      // ── 1: حفظ الفاتورة ─────────────────────
      const [r] = await rawExecute(
        `INSERT INTO invoices (companyId,branchId,clientId,ref,description,subtotal,vatRate,vatAmount,total,status,dueDate,createdBy,createdAt)
         VALUES (?,?,?,?,?,?,?,?,?,'sent',?,?,NOW())`,
        [companyId,branchId,input.clientId,ref,input.description||null,subtotal,vatRate,vatAmt,total,dueDate.toISOString().slice(0,10),userId]
      );
      const invoiceId = (r as any).insertId;

      // ── 3: قيد محاسبي تلقائي ────────────────
      const [je] = await rawExecute(
        `INSERT INTO journal_entries (companyId,branchId,ref,description,createdBy,createdAt) VALUES (?,?,?,?,?,NOW())`,
        [companyId,branchId,ref,`فاتورة ${ref}`,userId]
      );
      const journalId = (je as any).insertId;
      await rawExecute(
        `INSERT INTO journal_lines (journalId,accountCode,debit,credit) VALUES (?,?,?,0),(?,?,0,?),(?,?,0,?)`,
        [journalId,"113001",total, journalId,"411001",subtotal, journalId,"213001",vatAmt]
      );

      // ── 4: تحديث رصيد العميل ─────────────────
      await rawExecute(`UPDATE clients SET totalRevenue=totalRevenue+? WHERE id=?`, [subtotal, input.clientId]);

      // ── 6: جدولة تحصيل ──────────────────────
      await rawExecute(
        `INSERT INTO tasks (companyId,branchId,type,refType,refId,title,clientId,scheduledDate,status,priority,createdAt)
         VALUES (?,?,'collection','invoice',?,CONCAT('تحصيل ',?),?,?,  'pending','normal',NOW())`,
        [companyId,branchId,invoiceId,ref,input.clientId,dueDate.toISOString().slice(0,10)]
      );

      eventBus.emit("INVOICE_CREATED", { invoiceId, clientId: input.clientId, total, vatAmt, companyId, branchId });

      return { invoiceId, ref, total, dueDate };
    }),

  // ── تسجيل دفعة ──────────────────────────────
  recordPayment: scopedProcedure
    .input(z.object({ invoiceId: z.number(), amount: z.number(), method: z.string() }))
    .mutation(async ({ input, ctx }) => {
      requirePermission(ctx.scope.role as any, "invoices:write");
      const { companyId, userId } = ctx.scope;

      const [inv] = await rawQuery<any>(`SELECT * FROM invoices WHERE id=? AND companyId=?`, [input.invoiceId, companyId]);
      if (!inv) throw new Error("الفاتورة غير موجودة");

      const newPaid   = +inv.paidAmount + input.amount;
      const newStatus = newPaid >= +inv.total ? "paid" : "partial";

      await rawExecute(`UPDATE invoices SET paidAmount=?,status=?,paidAt=IF(?='paid',NOW(),NULL) WHERE id=?`,
        [newPaid, newStatus, newStatus, input.invoiceId]);

      const [je] = await rawExecute(`INSERT INTO journal_entries (companyId,ref,description,createdBy,createdAt) VALUES (?,CONCAT('PAY-',?),'دفعة فاتورة',?,NOW())`,
        [companyId, input.invoiceId, userId]);
      await rawExecute(`INSERT INTO journal_lines (journalId,accountCode,debit,credit) VALUES (?,?,?,0),(?,?,0,?)`,
        [(je as any).insertId,"101001",input.amount, (je as any).insertId,"113001",input.amount]);

      return { success: true, newStatus, totalPaid: newPaid };
    }),

  // ── فحص الميزانية قبل المصروف ───────────────
  checkBudget: scopedProcedure
    .input(z.object({ accountCode: z.string(), amount: z.number(), period: z.string().optional() }))
    .query(async ({ input, ctx }) => {
      const { companyId, branchId } = ctx.scope;
      const period = input.period || new Date().toISOString().slice(0, 7);

      const [budget] = await rawQuery<any>(
        `SELECT amount, used FROM budgets WHERE companyId=? AND accountCode=? AND period=?`,
        [companyId, input.accountCode, period]
      );
      if (!budget) return { status: "no_budget", pct: 0 };

      const projected = +budget.used + input.amount;
      const pct       = (projected / +budget.amount) * 100;

      let status = "ok";
      if (pct >= 110) status = "rejected";
      else if (pct >= 100) status = "blocked";
      else if (pct >= 80)  status = "warning";

      return { status, pct: +pct.toFixed(1), budgetAmount: +budget.amount, used: +budget.used, projected };
    }),

  // ── قائمة الفواتير ───────────────────────────
  listInvoices: scopedProcedure
    .input(z.object({ status: z.string().optional(), page: z.number().default(1) }))
    .query(async ({ input, ctx }) => {
      requirePermission(ctx.scope.role as any, "invoices:read");
      const { companyId } = ctx.scope;
      const sf = input.status ? "AND i.status=?" : "";
      const params: any[] = [companyId];
      if (input.status) params.push(input.status);
      params.push(20, (input.page - 1) * 20);
      return rawQuery<any>(
        `SELECT i.*,cl.name AS clientName FROM invoices i
         JOIN clients cl ON cl.id=i.clientId
         WHERE i.companyId=? ${sf} ORDER BY i.createdAt DESC LIMIT ? OFFSET ?`,
        params
      );
    }),

  // ── شجرة الحسابات ───────────────────────────
  getChartOfAccounts: scopedProcedure.query(async ({ ctx }) => {
    requirePermission(ctx.scope.role as any, "journal:read");
    return rawQuery<any>(
      `SELECT * FROM chart_of_accounts WHERE companyId=? ORDER BY code`,
      [ctx.scope.companyId]
    );
  }),
});

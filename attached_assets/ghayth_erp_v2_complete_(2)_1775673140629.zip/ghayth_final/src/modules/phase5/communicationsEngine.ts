/**
 * communicationsEngine.ts — منصة غيث ERP
 * المرجع: ملف 09 — منصة التواصل الموحد
 * واتساب Cloud API + نظام هاتف PBX + إيميل + AI 6 أدوار
 * رقم واحد + 11 قسم + ترجمة + تلخيص + Rules Engine
 */

import { z } from "zod";
import { scopedProcedure, router } from "../../core/trpc.js";
import { db } from "../../core/db.js";
import { eventBus } from "../../core/eventBus.js";
import { NotificationService } from "./automationEngine.js";

// ══════════════════════════════════════════════
// الثوابت والأقسام الـ 11
// ══════════════════════════════════════════════

const DEPARTMENTS: Record<string, { extension: string; email: string; keywords: string[] }> = {
  legal:        { extension: "201", email: "legal@aldoor.sa",        keywords: ["قانوني","عقد","قضية","محامي"] },
  umra:         { extension: "202", email: "umra@aldoor.sa",         keywords: ["عمرة","حج","مكة","زيارة","تأشيرة"] },
  sales:        { extension: "203", email: "sales@aldoor.sa",        keywords: ["سعر","عرض","شراء","اشتري","منتج"] },
  hotels:       { extension: "204", email: "hotels@aldoor.sa",       keywords: ["فندق","غرفة","حجز","إقامة"] },
  transport:    { extension: "205", email: "transport@aldoor.sa",    keywords: ["توصيل","نقل","سيارة","شحن"] },
  flights:      { extension: "206", email: "flights@aldoor.sa",      keywords: ["طيران","رحلة","تذكرة","سفر"] },
  realestate:   { extension: "207", email: "realestate@aldoor.sa",   keywords: ["شقة","عقار","إيجار","ملكية"] },
  cargo:        { extension: "208", email: "cargo@aldoor.sa",        keywords: ["شحن","حاوية","بضاعة","استيراد"] },
  maintenance:  { extension: "209", email: "maintenance@aldoor.sa",  keywords: ["صيانة","إصلاح","عطل","تسرب"] },
  finance:      { extension: "210", email: "finance@aldoor.sa",      keywords: ["فاتورة","دفع","حساب","مالي","تحويل"] },
  support:      { extension: "211", email: "support@aldoor.sa",      keywords: ["مساعدة","شكوى","مشكلة","دعم"] },
};

const SUPPORTED_LANGUAGES = ["ar", "en", "id", "ur"]; // عربي + إنجليزي + إندونيسي + أوردو

// ══════════════════════════════════════════════
// 1. تحديد القسم من النص (Rules Engine)
// ══════════════════════════════════════════════

function detectDepartment(text: string): string {
  const lower = text.toLowerCase();
  let maxScore = 0;
  let bestDept = "support";

  for (const [dept, config] of Object.entries(DEPARTMENTS)) {
    const score = config.keywords.filter(k => lower.includes(k)).length;
    if (score > maxScore) {
      maxScore = score;
      bestDept = dept;
    }
  }
  return bestDept;
}

// كشف اللغة (بسيط)
function detectLanguage(text: string): string {
  const arabicChars = (text.match(/[\u0600-\u06FF]/g) || []).length;
  const urduChars   = (text.match(/[\u0627-\u06FF]/g) || []).length;
  if (arabicChars > text.length * 0.3) return "ar";
  if (/[a-zA-Z]/.test(text)) return "en";
  if (urduChars > 5) return "ur";
  return "ar";
}

// ══════════════════════════════════════════════
// 2. الذكاء الاصطناعي — 6 أدوار
// يستخدم Anthropic API
// ══════════════════════════════════════════════

class AIEngine {

  private static async callClaude(systemPrompt: string, userMessage: string): Promise<string> {
    const response = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        model: "claude-sonnet-4-20250514",
        max_tokens: 1000,
        system: systemPrompt,
        messages: [{ role: "user", content: userMessage }],
      }),
    });

    if (!response.ok) throw new Error(`AI API Error: ${response.status}`);
    const data = await response.json();
    return data.content?.[0]?.text || "";
  }

  // ── دور 1: Front Desk AI — استقبال وتحليل الطلب ──
  static async analyzeFrontDesk(message: string, clientName?: string): Promise<FrontDeskAnalysis> {
    const systemPrompt = `أنت مساعد استقبال ذكي لمجموعة الدور. 
حلل رسالة العميل واستخرج المعلومات بالتنسيق التالي فقط (JSON):
{
  "intent": "نوع الطلب",
  "department": "القسم المناسب",
  "urgency": "low|medium|high|emergency",
  "extractedInfo": {"key": "value"},
  "suggestedResponse": "رد مبدئي للعميل",
  "language": "ar|en|id|ur",
  "sentiment": "positive|neutral|negative|angry"
}`;

    const result = await this.callClaude(
      systemPrompt,
      `العميل: ${clientName || "غير معروف"}\nالرسالة: ${message}`
    );

    try {
      return JSON.parse(result.replace(/```json|```/g, "").trim());
    } catch {
      return {
        intent: "استفسار عام",
        department: detectDepartment(message),
        urgency: "medium",
        extractedInfo: {},
        suggestedResponse: "شكراً للتواصل، سيتم الرد عليك قريباً",
        language: detectLanguage(message),
        sentiment: "neutral",
      };
    }
  }

  // ── دور 2: اقتراح الرد ───────────────────────────
  static async suggestReply(
    clientMessage: string,
    clientHistory: string,
    department: string,
    language: string
  ): Promise<string> {
    return this.callClaude(
      `أنت موظف خدمة عملاء محترف في مجموعة الدور قسم ${department}.
اقترح رداً مناسباً للعميل باللغة ${language === "ar" ? "العربية" : language}.
الرد يجب أن يكون:
- محترماً ومهنياً
- مباشراً ومفيداً
- لا يتجاوز 3 جمل
- يأخذ بالاعتبار تاريخ العميل`,
      `تاريخ العميل:\n${clientHistory}\n\nرسالة العميل:\n${clientMessage}`
    );
  }

  // ── دور 3: الترجمة الفورية ───────────────────────
  static async translate(
    text: string,
    fromLang: string,
    toLang: string
  ): Promise<string> {
    if (fromLang === toLang) return text;
    return this.callClaude(
      `أنت مترجم فوري. ترجم النص المعطى من ${fromLang} إلى ${toLang} بدقة. أعط النص المترجم فقط.`,
      text
    );
  }

  // ── دور 4: تلخيص المكالمات ───────────────────────
  static async summarizeCall(
    transcript: string,
    agentName: string
  ): Promise<CallSummary> {
    const result = await this.callClaude(
      `أنت محلل مكالمات. لخص المكالمة واستخرج الالتزامات بتنسيق JSON:
{
  "summary": "ملخص",
  "commitments": [{"who": "من", "what": "ماذا", "when": "متى"}],
  "nextAction": "الإجراء القادم",
  "sentiment": "positive|neutral|negative",
  "topics": ["موضوع1"]
}`,
      `الموظف: ${agentName}\nنص المكالمة:\n${transcript}`
    );

    try {
      return JSON.parse(result.replace(/```json|```/g, "").trim());
    } catch {
      return {
        summary: transcript.slice(0, 200),
        commitments: [],
        nextAction: "مراجعة يدوية",
        sentiment: "neutral",
        topics: [],
      };
    }
  }

  // ── دور 5: Rules Engine ──────────────────────────
  static async applyRules(
    message: string,
    clientData: any,
    analysis: FrontDeskAnalysis
  ): Promise<RuleResult[]> {
    const rules: RuleResult[] = [];

    // قاعدة 1: شكوى → دعم + إشعار المدير
    if (analysis.sentiment === "angry" || message.includes("شكوى") || message.includes("مشكلة")) {
      rules.push({ rule: "COMPLAINT", action: "escalate_to_support", priority: "high" });
    }

    // قاعدة 2: عمرة رمضان → أسعار الموسم
    if (analysis.department === "umra" &&
        (message.includes("رمضان") || message.includes("موسم"))) {
      rules.push({ rule: "UMRA_SEASON", action: "send_seasonal_pricing", priority: "normal" });
    }

    // قاعدة 3: رقم جديد → فتح ملف عميل
    if (!clientData) {
      rules.push({ rule: "NEW_CLIENT", action: "create_client_profile", priority: "normal" });
    }

    // قاعدة 4: VIP → المدير مباشرة
    if (clientData?.classification === "vip") {
      rules.push({ rule: "VIP_CLIENT", action: "route_to_manager", priority: "urgent" });
    }

    // قاعدة 5: طوارئ → تصعيد فوري
    if (analysis.urgency === "emergency") {
      rules.push({ rule: "EMERGENCY", action: "immediate_escalation", priority: "urgent" });
    }

    return rules;
  }

  // ── دور 6: التنبؤ والذكاء التسويقي ─────────────
  static async predictDemand(
    companyId: number,
    period: string
  ): Promise<DemandPrediction> {
    const [historicalData] = await db.query(`
      SELECT
        MONTH(createdAt) AS month,
        department,
        COUNT(*) AS inquiries,
        SUM(CASE WHEN clientId IN (SELECT clientId FROM invoices WHERE MONTH(createdAt)=MONTH(c.createdAt)) THEN 1 ELSE 0 END) AS conversions
      FROM communications c
      WHERE companyId=?
        AND createdAt > DATE_SUB(NOW(), INTERVAL 12 MONTH)
      GROUP BY MONTH(createdAt), department
    `, [companyId]);

    // تحليل بسيط للاتجاهات
    const deptStats: Record<string, number[]> = {};
    for (const row of historicalData) {
      if (!deptStats[row.department]) deptStats[row.department] = [];
      deptStats[row.department].push(row.inquiries);
    }

    const predictions: Record<string, number> = {};
    for (const [dept, counts] of Object.entries(deptStats)) {
      const avg = counts.reduce((s, c) => s + c, 0) / counts.length;
      const trend = counts.length >= 2
        ? (counts[counts.length - 1] - counts[0]) / counts.length
        : 0;
      predictions[dept] = Math.round(avg + trend);
    }

    return {
      period,
      predictions,
      topDepartment: Object.entries(predictions).sort((a, b) => b[1] - a[1])[0]?.[0] || "support",
      recommendation: Object.values(predictions).some(v => v > 50)
        ? "زيادة الموظفين في الأسبوع القادم"
        : "الطاقة الحالية كافية",
    };
  }
}

interface FrontDeskAnalysis {
  intent: string;
  department: string;
  urgency: string;
  extractedInfo: Record<string, any>;
  suggestedResponse: string;
  language: string;
  sentiment: string;
}

interface CallSummary {
  summary: string;
  commitments: Array<{ who: string; what: string; when: string }>;
  nextAction: string;
  sentiment: string;
  topics: string[];
}

interface RuleResult {
  rule: string;
  action: string;
  priority: string;
}

interface DemandPrediction {
  period: string;
  predictions: Record<string, number>;
  topDepartment: string;
  recommendation: string;
}

// ══════════════════════════════════════════════
// 3. واتساب Cloud API — المحادثات
// ══════════════════════════════════════════════

export const communicationsRouter = router({

  // ── استقبال رسالة واتساب ────────────────────
  handleWhatsAppIncoming: scopedProcedure
    .input(z.object({
      phone: z.string(),
      message: z.string(),
      messageId: z.string(),
      timestamp: z.number(),
    }))
    .mutation(async ({ input, ctx }) => {
      const { companyId } = ctx.scope;

      // ── خطوة 1: البحث عن العميل ────────────────
      let [clients] = await db.query(`
        SELECT * FROM clients WHERE phone=? AND companyId=?
      `, [input.phone, companyId]);

      let client = clients[0] || null;

      // ── خطوة 2: إنشاء عميل جديد تلقائياً ────────
      if (!client) {
        const [newClient] = await db.execute(`
          INSERT INTO clients
            (companyId, phone, classification, source, createdAt)
          VALUES (?,'?','prospect','whatsapp',NOW())
        `, [companyId, input.phone]);
        const clientId = (newClient as any).insertId;

        // تعيين موظف بـ Load Balancing
        const [agents] = await db.query(`
          SELECT ea.id, COUNT(cn.id) AS activeChats
          FROM employee_assignments ea
          LEFT JOIN communications cn ON cn.assignedTo=ea.id AND cn.status='open'
          WHERE ea.companyId=? AND ea.role IN ('support','sales') AND ea.status='active'
          GROUP BY ea.id ORDER BY activeChats ASC LIMIT 1
        `, [companyId]);

        if (agents[0]) {
          await db.execute(`
            UPDATE clients SET assignedTo=? WHERE id=?
          `, [agents[0].id, clientId]);
        }

        client = { id: clientId, phone: input.phone, classification: "prospect" };
        eventBus.emit("CLIENT_CREATED", { clientId, phone: input.phone, source: "whatsapp", companyId });
      }

      // ── خطوة 3: AI يحلل الرسالة ────────────────
      const analysis = await AIEngine.analyzeFrontDesk(input.message, client.name);

      // ── خطوة 4: تطبيق Rules Engine ─────────────
      const rules = await AIEngine.applyRules(input.message, client, analysis);

      // ── خطوة 5: حفظ المحادثة ───────────────────
      const [convResult] = await db.execute(`
        INSERT INTO communications
          (companyId, clientId, channel, direction, message, messageId,
           department, language, sentiment, urgency,
           analysis, rules, status, receivedAt)
        VALUES (?,?,'whatsapp','inbound',?,?, ?,?,?,?, ?,?,'open',NOW())
        ON DUPLICATE KEY UPDATE id=id
      `, [
        companyId, client.id, input.message, input.messageId,
        analysis.department, analysis.language,
        analysis.sentiment, analysis.urgency,
        JSON.stringify(analysis), JSON.stringify(rules),
      ]);
      const commId = (convResult as any).insertId || 0;

      // ── خطوة 6: توجيه ذكي للموظف المناسب ────────
      let assignedAgent: any = null;

      // VIP → المدير مباشرة
      if (rules.some(r => r.rule === "VIP_CLIENT")) {
        const [managers] = await db.query(`
          SELECT ea.id FROM employee_assignments ea
          WHERE ea.companyId=? AND ea.role IN ('manager','gm') AND ea.status='active'
          LIMIT 1
        `, [companyId]);
        assignedAgent = managers[0];
      } else {
        // Load Balancing حسب القسم
        const dept = analysis.department;
        const [agents] = await db.query(`
          SELECT ea.id, COUNT(cn.id) AS activeChats,
            (SELECT COUNT(*) FROM communications c2
             WHERE c2.assignedTo=ea.id AND c2.clientId=? AND c2.status='closed') AS prevChats
          FROM employee_assignments ea
          LEFT JOIN communications cn ON cn.assignedTo=ea.id AND cn.status='open'
          WHERE ea.companyId=? AND ea.department=? AND ea.status='active'
          GROUP BY ea.id
          ORDER BY prevChats DESC, activeChats ASC
          LIMIT 1
        `, [client.id, companyId, dept]);
        assignedAgent = agents[0];
      }

      if (assignedAgent) {
        await db.execute(`
          UPDATE communications SET assignedTo=? WHERE id=?
        `, [assignedAgent.id, commId]);

        // إشعار الموظف مع ملخص AI
        await db.execute(`
          INSERT INTO notifications (companyId, assignmentId, type, title, body, createdAt)
          VALUES (?,?,'new_message','رسالة جديدة',
            CONCAT(?,': ',SUBSTR(?,1,50),' — AI: ',SUBSTR(?,1,50)),NOW())
        `, [
          companyId, assignedAgent.id,
          client.name || input.phone,
          input.message,
          analysis.suggestedResponse,
        ]);
      }

      // ── خطوة 7: اقتراح رد للموظف ─────────────────
      const suggestedReply = analysis.suggestedResponse;

      // ── خطوة 8: إنشاء تذكرة/مهمة تلقائية ─────────
      if (rules.some(r => r.rule === "COMPLAINT")) {
        eventBus.emit("SUPPORT_TICKET_CREATED", {
          clientId: client.id, subject: analysis.intent,
          body: input.message, channel: "whatsapp",
          companyId, priority: "high",
        });
      }

      return {
        commId,
        clientId: client.id,
        isNewClient: !clients[0],
        department: analysis.department,
        urgency: analysis.urgency,
        assignedTo: assignedAgent?.id || null,
        suggestedReply,
        rules,
      };
    }),

  // ── إرسال رسالة واتساب ──────────────────────
  sendWhatsApp: scopedProcedure
    .input(z.object({
      clientId: z.number(),
      message: z.string(),
      templateName: z.string().optional(),
      templateParams: z.record(z.string()).optional(),
    }))
    .mutation(async ({ input, ctx }) => {
      const { companyId, userId } = ctx.scope;

      const [clients] = await db.query(`SELECT phone, name FROM clients WHERE id=? AND companyId=?`,
        [input.clientId, companyId]);
      if (!clients.length) throw new Error("العميل غير موجود");

      const [msgResult] = await db.execute(`
        INSERT INTO whatsapp_queue
          (companyId, phone, recipientName, clientId, message,
           templateName, templateParams, sentBy, status, scheduledAt)
        VALUES (?,?,?,?,?, ?,?,'immediate',?,NOW())
      `, [
        companyId, clients[0].phone, clients[0].name,
        input.clientId, input.message,
        input.templateName || null,
        JSON.stringify(input.templateParams || {}),
        "queued",
      ]);

      // حفظ في سجل المحادثات
      await db.execute(`
        INSERT INTO communications
          (companyId, clientId, channel, direction, message, sentBy, status, receivedAt)
        VALUES (?,?,'whatsapp','outbound',?,?,'sent',NOW())
      `, [companyId, input.clientId, input.message, userId]);

      return { queued: true, messageId: (msgResult as any).insertId };
    }),

  // ══════════════════════════════════════════════
  // 4. نظام الهاتف PBX — مكالمة واردة 8 خطوات
  // ══════════════════════════════════════════════

  handleIncomingCall: scopedProcedure
    .input(z.object({
      callerPhone: z.string(),
      callId: z.string(),
    }))
    .mutation(async ({ input, ctx }) => {
      const { companyId } = ctx.scope;

      // ── خطوة 1-2: التعرف على المتصل ────────────
      const [clients] = await db.query(`
        SELECT * FROM clients WHERE phone=? AND companyId=?
      `, [input.callerPhone, companyId]);
      const client = clients[0] || null;
      const isKnown = !!client;

      // ── خطوة 3: IVR ──────────────────────────────
      const ivrMessage = isKnown
        ? `مرحباً ${client.name}، هل تريد التحدث مع نفس الموظف؟`
        : "مرحباً، للعمرة اضغط 1، للفنادق 2، للنقل 3، أو قل ما تحتاج";

      // ── خطوة 4: توجيه ذكي ──────────────────────
      let targetDept = "support";
      if (isKnown && client.assignedTo) {
        // توجيه للموظف السابق إذا متاح
        const [prevAgent] = await db.query(`
          SELECT ea.id, e.name,
            (SELECT COUNT(*) FROM pbx_calls pc WHERE pc.assignedTo=ea.id AND pc.status='active') AS activeCalls
          FROM employee_assignments ea
          JOIN employees e ON e.id = ea.employeeId
          WHERE ea.id=? AND ea.status='active'
        `, [client.assignedTo]);

        if (prevAgent[0]?.activeCalls < 2) {
          targetDept = prevAgent[0]?.id;
        }
      }

      // ── خطوة 5: توجيه للموظف المناسب ────────────
      const [bestAgent] = await db.query(`
        SELECT ea.id, e.name,
          COUNT(pc.id) AS activeCalls,
          (SELECT COUNT(*) FROM communications c2
           WHERE c2.assignedTo=ea.id AND c2.clientId=? AND c2.status='closed') AS history
        FROM employee_assignments ea
        JOIN employees e ON e.id = ea.employeeId
        LEFT JOIN pbx_calls pc ON pc.assignedTo=ea.id AND pc.status='active'
        WHERE ea.companyId=? AND ea.status='active'
          AND ea.sipExtension IS NOT NULL
        GROUP BY ea.id
        ORDER BY history DESC, activeCalls ASC
        LIMIT 1
      `, [client?.id || 0, companyId]);

      // ── خطوة 6: إشعار الموظف قبل الرنين ─────────
      if (bestAgent[0]) {
        const clientSummary = client
          ? `${client.name} — ${client.classification} — آخر تواصل: ${client.lastActivityAt}`
          : `رقم جديد: ${input.callerPhone}`;

        await db.execute(`
          INSERT INTO notifications (companyId, assignmentId, type, title, body, createdAt)
          VALUES (?,?,'incoming_call','مكالمة واردة',?,NOW())
        `, [companyId, bestAgent[0].id, clientSummary]);
      }

      // ── خطوة 7: لم يرد 30 ثانية → موظف ثاني ────
      // يُعالَج بـ PBX webhook

      // حفظ سجل المكالمة
      const [callResult] = await db.execute(`
        INSERT INTO pbx_calls
          (companyId, callId, callerPhone, clientId,
           assignedTo, status, isKnown, startedAt)
        VALUES (?,?,?,?, ?,?,'ringing',?,NOW())
      `, [
        companyId, input.callId, input.callerPhone,
        client?.id || null,
        bestAgent[0]?.id || null,
        isKnown ? 1 : 0,
      ]);

      return {
        callDbId: (callResult as any).insertId,
        isKnown,
        clientName: client?.name || null,
        assignedExtension: bestAgent[0]?.id || null,
        ivrMessage,
      };
    }),

  // ── إنهاء مكالمة + تلخيص AI ─────────────────
  endCall: scopedProcedure
    .input(z.object({
      callId: z.string(),
      durationSeconds: z.number(),
      transcript: z.string().optional(),
      agentName: z.string(),
    }))
    .mutation(async ({ input, ctx }) => {
      const { companyId } = ctx.scope;

      await db.execute(`
        UPDATE pbx_calls
        SET status='completed', endedAt=NOW(), duration=?
        WHERE callId=? AND companyId=?
      `, [input.durationSeconds, input.callId, companyId]);

      let summary: CallSummary | null = null;
      let tasksCreated = 0;

      // ── خطوة 8: تلخيص AI + مهام من الالتزامات ───
      if (input.transcript && input.durationSeconds > 60) {
        summary = await AIEngine.summarizeCall(input.transcript, input.agentName);

        // إنشاء مهمة لكل التزام
        const [call] = await db.query(`
          SELECT * FROM pbx_calls WHERE callId=? AND companyId=?
        `, [input.callId, companyId]);

        for (const commitment of summary.commitments || []) {
          if (commitment.what) {
            await db.execute(`
              INSERT INTO tasks
                (companyId, type, title, clientId, priority, status, scheduledDate, notes, createdAt)
              VALUES (?,?,'follow_call',CONCAT('[مكالمة] ',?),?,'normal','pending',
                COALESCE(?,CURDATE()),?,NOW())
            `, [
              companyId, "call_followup",
              commitment.what,
              call[0]?.clientId || null, "normal",
              commitment.when || null,
              `المسؤول: ${commitment.who}`,
            ]);
            tasksCreated++;
          }
        }

        // حفظ الملخص
        await db.execute(`
          UPDATE pbx_calls SET aiSummary=?, aiCommitments=?
          WHERE callId=? AND companyId=?
        `, [
          summary.summary,
          JSON.stringify(summary.commitments),
          input.callId, companyId,
        ]);
      }

      return { summary, tasksCreated };
    }),

  // ══════════════════════════════════════════════
  // 5. البريد الإلكتروني
  // ══════════════════════════════════════════════

  handleIncomingEmail: scopedProcedure
    .input(z.object({
      fromEmail: z.string(),
      fromName: z.string().optional(),
      subject: z.string(),
      body: z.string(),
      toEmail: z.string(), // umra@aldoor.sa مثلاً
      attachments: z.array(z.string()).optional(),
    }))
    .mutation(async ({ input, ctx }) => {
      const { companyId } = ctx.scope;

      // تحديد القسم من إيميل الوجهة
      const dept = Object.entries(DEPARTMENTS).find(
        ([, cfg]) => input.toEmail.startsWith(cfg.email.split("@")[0])
      )?.[0] || "support";

      // ── AI: قراءة وتحليل ───────────────────────
      const analysis = await AIEngine.analyzeFrontDesk(
        `${input.subject}\n${input.body}`,
        input.fromName
      );

      // البحث عن العميل
      const [clients] = await db.query(`
        SELECT * FROM clients WHERE email=? AND companyId=?
      `, [input.fromEmail, companyId]);
      let clientId = clients[0]?.id || null;

      if (!clientId) {
        const [newClient] = await db.execute(`
          INSERT INTO clients (companyId, email, name, classification, source, createdAt)
          VALUES (?,?,?,'prospect','email',NOW())
        `, [companyId, input.fromEmail, input.fromName || "غير معروف"]);
        clientId = (newClient as any).insertId;
      }

      // حفظ الإيميل
      const [emailResult] = await db.execute(`
        INSERT INTO communications
          (companyId, clientId, channel, direction, message, subject,
           department, language, sentiment, urgency, analysis,
           status, receivedAt)
        VALUES (?,?,'email','inbound',?,?, ?,?,?,?,?,'open',NOW())
      `, [
        companyId, clientId, input.body, input.subject,
        dept, analysis.language, analysis.sentiment,
        analysis.urgency, JSON.stringify(analysis),
      ]);
      const commId = (emailResult as any).insertId;

      // اقتراح رد AI
      const [history] = await db.query(`
        SELECT GROUP_CONCAT(message SEPARATOR '\n') AS history
        FROM communications WHERE clientId=? AND companyId=?
          AND direction='outbound' ORDER BY receivedAt DESC LIMIT 5
      `, [clientId, companyId]);

      const suggestedReply = await AIEngine.suggestReply(
        input.body,
        history[0]?.history || "",
        dept,
        analysis.language
      );

      // إشعار الموظف
      await db.execute(`
        INSERT INTO notifications (companyId, type, title, body, targetRole, createdAt)
        VALUES (?,'new_email','إيميل جديد',
          CONCAT('[',?,']: ',SUBSTR(?,1,50)),'employee',NOW())
      `, [companyId, dept, input.subject]);

      // متابعة تلقائية بعد 3 أيام إذا لم يُرد
      const followupAt = new Date(Date.now() + 3 * 86400000);
      await db.execute(`
        INSERT INTO scheduled_notifications
          (companyId, type, refType, refId, scheduledAt, body)
        VALUES (?,'email_followup','communication',?,?,CONCAT('لم يُرد على إيميل: ',?))
      `, [companyId, commId, followupAt, input.subject]);

      return { commId, clientId, department: dept, suggestedReply, language: analysis.language };
    }),

  // ══════════════════════════════════════════════
  // 6. الإعداد — إنشاء حساب SIP + إيميل عند إضافة موظف
  // ══════════════════════════════════════════════

  setupEmployeeCommunications: scopedProcedure
    .input(z.object({ assignmentId: z.number() }))
    .mutation(async ({ input, ctx }) => {
      const { companyId } = ctx.scope;

      const [assignments] = await db.query(`
        SELECT ea.*, e.name, e.email,
          d.name AS deptName, d.slug AS deptSlug,
          co.domain AS companyDomain,
          co.pbxPrefix
        FROM employee_assignments ea
        JOIN employees e ON e.id = ea.employeeId
        LEFT JOIN departments d ON d.id = ea.departmentId
        JOIN companies co ON co.id = ea.companyId
        WHERE ea.id=? AND ea.companyId=?
      `, [input.assignmentId, companyId]);

      if (!assignments.length) throw new Error("التعيين غير موجود");
      const ea = assignments[0];

      // توليد اسم مستخدم SIP
      const nameParts = ea.name.split(" ");
      const sipUser = `${nameParts[0]}.${DEPARTMENTS[ea.deptSlug]?.extension || "200"}`;

      // إنشاء SIP extension
      const sipPassword = Math.random().toString(36).slice(2, 10);
      await db.execute(`
        INSERT INTO sip_accounts
          (companyId, assignmentId, sipUser, sipPassword, extension,
           displayName, department, status, createdAt)
        VALUES (?,?,?,?,?,?,?,'active',NOW())
        ON DUPLICATE KEY UPDATE sipPassword=VALUES(sipPassword)
      `, [
        companyId, input.assignmentId, sipUser, sipPassword,
        DEPARTMENTS[ea.deptSlug]?.extension || "200",
        ea.name, ea.deptSlug,
      ]);

      // إنشاء إيميل مؤسسي
      const emailUser = `${nameParts[0].toLowerCase()}@${ea.companyDomain || "aldoor.sa"}`;
      await db.execute(`
        UPDATE employee_assignments
        SET sipExtension=?, workEmail=?
        WHERE id=?
      `, [
        DEPARTMENTS[ea.deptSlug]?.extension || "200",
        emailUser, input.assignmentId,
      ]);

      // إيميل ترحيب مع بيانات SIP
      await db.execute(`
        INSERT INTO email_queue (companyId, toEmail, subject, body, scheduledAt)
        VALUES (?,?,?,?,NOW())
      `, [
        companyId, ea.email || emailUser,
        "بيانات التواصل المؤسسية",
        `مرحباً ${ea.name},\nالتحويلة: ${DEPARTMENTS[ea.deptSlug]?.extension || "200"}\nالإيميل: ${emailUser}\nالتطبيق: قم بتحميل Softphone وأدخل بيانات SIP`,
      ]);

      return {
        sipUser,
        extension: DEPARTMENTS[ea.deptSlug]?.extension || "200",
        workEmail: emailUser,
      };
    }),

  // ══════════════════════════════════════════════
  // 7. لوحة الإدارة — إحصائيات لحظية
  // ══════════════════════════════════════════════

  getDashboard: scopedProcedure
    .query(async ({ ctx }) => {
      const { companyId } = ctx.scope;

      const [today] = await db.query(`
        SELECT
          COUNT(*) AS totalConversations,
          SUM(channel='whatsapp') AS whatsappCount,
          SUM(channel='email') AS emailCount,
          SUM(channel='phone') AS phoneCount,
          SUM(status='open') AS openCount,
          AVG(TIMESTAMPDIFF(MINUTE, receivedAt, firstReplyAt)) AS avgReplyMin,
          SUM(department='umra') AS umraCount,
          SUM(sentiment='negative' OR sentiment='angry') AS negativeCount
        FROM communications
        WHERE companyId=? AND DATE(receivedAt)=CURDATE()
      `, [companyId]);

      const [topAgents] = await db.query(`
        SELECT e.name, COUNT(c.id) AS handled,
          AVG(tr.rating) AS avgRating
        FROM communications c
        JOIN employee_assignments ea ON ea.id = c.assignedTo
        JOIN employees e ON e.id = ea.employeeId
        LEFT JOIN task_ratings tr ON tr.assignedTo=ea.id
        WHERE c.companyId=? AND DATE(c.receivedAt)=CURDATE()
        GROUP BY ea.id ORDER BY handled DESC LIMIT 5
      `, [companyId]);

      const stats = today[0] || {};
      const totalConv = stats.totalConversations || 0;
      const topDept = stats.umraCount > totalConv * 0.4 ? "umra" : "mixed";

      return {
        today: {
          totalConversations: totalConv,
          whatsapp: stats.whatsappCount || 0,
          email: stats.emailCount || 0,
          phone: stats.phoneCount || 0,
          open: stats.openCount || 0,
          avgReplyMin: stats.avgReplyMin ? +stats.avgReplyMin.toFixed(1) : null,
          topDepartment: topDept,
          negativeCount: stats.negativeCount || 0,
        },
        topAgents,
        aiSummary: `استقبلنا ${totalConv} استفسار — ${Math.round((stats.umraCount / totalConv) * 100) || 0}% عمرة — ${stats.negativeCount || 0} شكاوى`,
      };
    }),
});

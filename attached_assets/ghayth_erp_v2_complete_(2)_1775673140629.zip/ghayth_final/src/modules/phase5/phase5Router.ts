/**
 * phase5Router.ts — منصة غيث ERP
 * تجميع المرحلة 5 + الراوتر النهائي الشامل
 */

import { router } from "../../core/trpc.js";
import { intelligenceRouter }    from "./intelligenceEngine.js";
import { automationRouter }      from "./automationEngine.js";
import { communicationsRouter }  from "./communicationsEngine";

// استيراد معالجات الأحداث
import "./phase5EventHandlers";

export const phase5Router = router({
  intelligence:   intelligenceRouter,
  automation:     automationRouter,
  communications: communicationsRouter,
});

// ══════════════════════════════════════════════
// appRouter النهائي الشامل — يُضاف لملف trpc.ts
// ══════════════════════════════════════════════
// import { phase1Router }  from "./phase1Router";
// import { phase2Router }  from "./hr";
// import { phase3Router }  from "./financeEngine";
// import { phase4Router }  from "./phase4Router";
// import { phase5Router }  from "./phase5Router";
//
// export const appRouter = router({
//   // المرحلة 1
//   assignments:    phase1Router.assignments,
//   clients:        phase1Router.clients,
//   commandCenter:  phase1Router.commandCenter,
//   // المرحلة 2
//   hr:             phase2Router,
//   // المرحلة 3
//   finance:        phase3Router,
//   // المرحلة 4
//   fleet:          phase4Router.fleet,
//   warehouse:      phase4Router.warehouse,
//   properties:     phase4Router.properties,
//   legal:          phase4Router.legal,
//   projects:       phase4Router.projects,
//   // المرحلة 5
//   intelligence:   phase5Router.intelligence,
//   automation:     phase5Router.automation,
//   communications: phase5Router.communications,
// });

/**
 * intelligenceEngine.ts — منصة غيث ERP
 * المرجع: ملف 07 — الذكاء التشغيلي
 * 3 خوارزميات + تقويم يومي + 8 KPIs + 10 تنبيهات ذكية
 */

import { z } from "zod";
import { scopedProcedure, router } from "../../core/trpc.js";
import { db } from "../../core/db.js";
import { getSetting } from "../../core/eventBus.js";

// ══════════════════════════════════════════════
// 1. الخوارزميات الثلاث
// ══════════════════════════════════════════════

// ── 1.1 Haversine — المسافة بالكيلومترات ──────
export function haversineKm(
  lat1: number, lon1: number,
  lat2: number, lon2: number
): number {
  const R = 6371;
  const dLat = ((lat2 - lat1) * Math.PI) / 180;
  const dLon = ((lon2 - lon1) * Math.PI) / 180;
  const a =
    Math.sin(dLat / 2) ** 2 +
    Math.cos((lat1 * Math.PI) / 180) *
    Math.cos((lat2 * Math.PI) / 180) *
    Math.sin(dLon / 2) ** 2;
  return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
}

export function travelMin(km: number, speedKmh = 40): number {
  return Math.round((km / speedKmh) * 60);
}

// ── 1.2 Moving Average — تقدير المدة ──────────
export async function estimateDuration(
  taskType: string,
  companyId: number
): Promise<number> {
  const defaults: Record<string, number> = {
    maintenance:  90,
    inspection:   45,
    installation: 120,
    delivery:     30,
    visit:        60,
    court_session: 180,
    support_ticket: 45,
    sales_call:   30,
  };

  const [result] = await db.query(`
    SELECT AVG(actualDuration) AS avg, COUNT(*) AS cnt
    FROM tasks
    WHERE companyId=?
      AND type=?
      AND status='completed'
      AND actualDuration IS NOT NULL
      AND completedAt > DATE_SUB(NOW(), INTERVAL 30 DAY)
  `, [companyId, taskType]);

  const cnt = result?.[0]?.cnt || 0;
  const avg = result?.[0]?.avg || 0;

  return cnt >= 10 ? Math.round(avg) : (defaults[taskType] || 60);
}

// ── 1.3 Load Balancing — توزيع الأحمال ────────
// المعادلة: مهام 40% + مسافة 30% + تخصص 20% + تقييم 10%
export interface LoadCandidate {
  id: number;
  assignmentId: number;
  name: string;
  activeTasks: number;
  distanceKm: number;
  hasSkill: boolean;
  rating: number;
}

export function loadBalance(candidates: LoadCandidate[]): LoadCandidate & { score: number } {
  if (!candidates.length) throw new Error("لا يوجد مرشح متاح");

  const maxDist = Math.max(...candidates.map(c => c.distanceKm)) || 1;
  const maxTasks = 6;

  const scored = candidates.map(c => {
    const taskScore  = Math.max(0, ((maxTasks - c.activeTasks) / maxTasks) * 100);
    const distScore  = ((maxDist - c.distanceKm) / maxDist) * 100;
    const skillScore = c.hasSkill ? 100 : 0;
    const ratingScore = (c.rating / 5) * 100;
    const total = taskScore * 0.4 + distScore * 0.3 + skillScore * 0.2 + ratingScore * 0.1;
    return { ...c, score: +total.toFixed(1) };
  });

  return scored.sort((a, b) => b.score - a.score)[0];
}

// ══════════════════════════════════════════════
// 2. بناء التقويم اليومي لموظف
// كل إجراء (بلاغ + رحلة + تذكرة + مقابلة + تحصيل + جلسة)
// يتحول لمهمة مجدولة مع وقت ومكان ومسافة ومدة وعميل وSLA
// ══════════════════════════════════════════════

export async function buildDailySchedule(
  assignmentId: number,
  date: string,
  companyId: number
): Promise<DaySchedule> {

  const tasks = await db.query(`
    SELECT
      t.id, t.type, t.title, t.status, t.priority,
      t.scheduledStart, t.estimatedDuration, t.actualDuration,
      t.lat AS taskLat, t.lon AS taskLon,
      t.slaDeadline, t.clientId,
      cl.name AS clientName, cl.phone AS clientPhone,
      t.refType, t.refId,
      t.completedAt
    FROM tasks t
    LEFT JOIN clients cl ON cl.id = t.clientId
    WHERE t.assignedTo=?
      AND DATE(t.scheduledStart)=?
      AND t.companyId=?
    ORDER BY t.scheduledStart ASC
  `, [assignmentId, date, companyId]);

  // جلب موقع الفرع (نقطة البداية)
  const [branches] = await db.query(`
    SELECT b.lat, b.lon
    FROM employee_assignments ea
    JOIN branches b ON b.id = ea.branchId
    WHERE ea.id=?
  `, [assignmentId]);
  const branch = branches[0] || { lat: 24.7, lon: 46.7 }; // الرياض افتراضي

  let prevLat = branch.lat;
  let prevLon = branch.lon;
  let currentTime = new Date(`${date}T08:00:00`);
  const slots: ScheduleSlot[] = [];
  let totalTravelMin = 0;
  let totalWorkMin = 0;
  let completedCount = 0;

  for (const task of tasks) {
    const distKm = task.taskLat
      ? haversineKm(prevLat, prevLon, task.taskLat, task.taskLon)
      : 0;
    const travelMinutes = travelMin(distKm);
    totalTravelMin += travelMinutes;

    const workMin = task.actualDuration || task.estimatedDuration || 60;
    totalWorkMin += workMin;

    const departAt = new Date(currentTime);
    const arriveAt = new Date(currentTime.getTime() + travelMinutes * 60000);
    const finishAt = new Date(arriveAt.getTime() + workMin * 60000);

    const slaStatus = task.slaDeadline
      ? (new Date(task.slaDeadline) >= finishAt ? "ok" : "at_risk")
      : null;

    slots.push({
      taskId: task.id,
      type: task.type,
      title: task.title,
      status: task.status,
      priority: task.priority,
      clientName: task.clientName,
      clientPhone: task.clientPhone,
      distanceKm: +distKm.toFixed(1),
      travelMin: travelMinutes,
      workMin,
      departAt,
      arriveAt,
      finishAt,
      slaDeadline: task.slaDeadline,
      slaStatus,
      refType: task.refType,
      refId: task.refId,
    });

    if (task.status === "completed") completedCount++;
    currentTime = finishAt;

    if (task.taskLat) {
      prevLat = task.taskLat;
      prevLon = task.taskLon;
    }
  }

  // حساب وقت الرجوع للفرع
  const returnKm = haversineKm(prevLat, prevLon, branch.lat, branch.lon);
  const returnMinutes = travelMin(returnKm);

  return {
    assignmentId,
    date,
    slots,
    summary: {
      total: tasks.length,
      completed: completedCount,
      pending: tasks.filter(t => t.status === "pending").length,
      inProgress: tasks.filter(t => t.status === "in_progress").length,
      overdue: slots.filter(s => s.slaStatus === "at_risk").length,
      completionPercent: tasks.length
        ? +((completedCount / tasks.length) * 100).toFixed(0)
        : 0,
      totalTravelKm: +slots.reduce((s, t) => s + t.distanceKm, 0).toFixed(1),
      totalTravelMin,
      totalWorkMin,
      returnKm: +returnKm.toFixed(1),
      returnMin: returnMinutes,
      totalDayMin: totalTravelMin + totalWorkMin + returnMinutes,
    },
  };
}

interface ScheduleSlot {
  taskId: number;
  type: string;
  title: string;
  status: string;
  priority: string;
  clientName: string | null;
  clientPhone: string | null;
  distanceKm: number;
  travelMin: number;
  workMin: number;
  departAt: Date;
  arriveAt: Date;
  finishAt: Date;
  slaDeadline: Date | null;
  slaStatus: "ok" | "at_risk" | null;
  refType: string;
  refId: number;
}

interface DaySchedule {
  assignmentId: number;
  date: string;
  slots: ScheduleSlot[];
  summary: {
    total: number;
    completed: number;
    pending: number;
    inProgress: number;
    overdue: number;
    completionPercent: number;
    totalTravelKm: number;
    totalTravelMin: number;
    totalWorkMin: number;
    returnKm: number;
    returnMin: number;
    totalDayMin: number;
  };
}

// ══════════════════════════════════════════════
// 3. KPIs — 8 مؤشرات لكل موظف
// ══════════════════════════════════════════════

export async function calcEmployeeKPIs(
  assignmentId: number,
  companyId: number,
  periodDays = 30
): Promise<EmployeeKPIs> {

  const [data] = await db.query(`
    SELECT
      COUNT(*) AS total,
      SUM(status='completed') AS completed,
      SUM(status='pending' AND scheduledStart < NOW()) AS overdue,
      AVG(CASE WHEN status='completed' AND actualDuration > 0
          THEN actualDuration / estimatedDuration END) AS speedRatio,
      SUM(CASE WHEN status='completed' AND completedAt <= scheduledStart THEN 1 ELSE 0 END) AS onTime,
      SUM(CASE WHEN status='completed' AND slaDeadline IS NOT NULL
          AND completedAt <= slaDeadline THEN 1 ELSE 0 END) AS slaCompliant,
      SUM(slaDeadline IS NOT NULL AND status='completed') AS slaTotal
    FROM tasks
    WHERE assignedTo=?
      AND companyId=?
      AND scheduledStart > DATE_SUB(NOW(), INTERVAL ? DAY)
  `, [assignmentId, companyId, periodDays]);

  const [ratings] = await db.query(`
    SELECT AVG(rating) AS avgRating, COUNT(*) AS ratingCount
    FROM task_ratings
    WHERE assignedTo=? AND createdAt > DATE_SUB(NOW(), INTERVAL ? DAY)
  `, [assignmentId, periodDays]);

  const [reopens] = await db.query(`
    SELECT
      SUM(reopened=1) AS reopened,
      SUM(status='completed') AS completed
    FROM tasks
    WHERE assignedTo=? AND companyId=?
      AND scheduledStart > DATE_SUB(NOW(), INTERVAL ? DAY)
  `, [assignmentId, companyId, periodDays]);

  const d = data[0] || {};
  const r = ratings[0] || {};
  const ro = reopens[0] || {};

  const completionRate = d.total > 0
    ? +((d.completed / d.total) * 100).toFixed(1) : 0;
  const speedRatio = d.speedRatio
    ? +(d.speedRatio * 100).toFixed(1) : 100;
  const onTimeRate = d.completed > 0
    ? +((d.onTime / d.completed) * 100).toFixed(1) : 100;
  const slaRate = d.slaTotal > 0
    ? +((d.slaCompliant / d.slaTotal) * 100).toFixed(1) : 100;
  const avgRating = r.avgRating ? +r.avgRating.toFixed(1) : null;
  const reopenRate = ro.completed > 0
    ? +((ro.reopened / ro.completed) * 100).toFixed(1) : 0;

  return {
    assignmentId,
    periodDays,
    completionRate,      // > 90 هدف
    speedRatio,          // < 100 هدف (أسرع من التقدير)
    onTimeRate,          // > 85 هدف
    slaRate,             // > 95 هدف
    avgRating,           // > 4 هدف
    reopenRate,          // < 5 هدف
    totalTasks: d.total || 0,
    completedTasks: d.completed || 0,
    overdueTasks: d.overdue || 0,
    score: calcOverallScore({
      completionRate, speedRatio, onTimeRate, slaRate, avgRating, reopenRate,
    }),
  };
}

function calcOverallScore(kpis: any): number {
  let score = 0;
  score += kpis.completionRate >= 90 ? 25 : (kpis.completionRate / 90) * 25;
  score += kpis.speedRatio <= 100 ? 20 : Math.max(0, 20 - (kpis.speedRatio - 100) * 0.2);
  score += kpis.onTimeRate >= 85 ? 20 : (kpis.onTimeRate / 85) * 20;
  score += kpis.slaRate >= 95 ? 25 : (kpis.slaRate / 95) * 25;
  score += kpis.avgRating ? (kpis.avgRating / 5) * 10 : 5;
  return +Math.min(100, score).toFixed(1);
}

interface EmployeeKPIs {
  assignmentId: number;
  periodDays: number;
  completionRate: number;
  speedRatio: number;
  onTimeRate: number;
  slaRate: number;
  avgRating: number | null;
  reopenRate: number;
  totalTasks: number;
  completedTasks: number;
  overdueTasks: number;
  score: number;
}

// ══════════════════════════════════════════════
// 4. التنبيهات الذكية — 10 تنبيهات
// ══════════════════════════════════════════════

export async function runSmartAlerts(companyId: number, branchId: number): Promise<string[]> {
  const alerts: string[] = [];

  const maxTasks = await getSetting("intelligence.maxDailyTasks", branchId, companyId) as number || 6;
  const slaWarningPct = await getSetting("intelligence.slaWarningPercent", branchId, companyId) as number || 80;

  // ── تنبيه 1: موظف عنده أكثر من maxTasks مهمة ──────────
  const overloaded = await db.query(`
    SELECT assignedTo, COUNT(*) AS cnt,
      ea.id, e.name
    FROM tasks t
    JOIN employee_assignments ea ON ea.id = t.assignedTo
    JOIN employees e ON e.id = ea.employeeId
    WHERE t.companyId=? AND t.branchId=?
      AND t.status IN ('pending','in_progress')
      AND DATE(t.scheduledStart) = CURDATE()
    GROUP BY assignedTo
    HAVING cnt > ?
  `, [companyId, branchId, maxTasks]);

  for (const emp of overloaded) {
    alerts.push(`⚠️ ${emp.name}: ${emp.cnt} مهمة (الحد ${maxTasks}) — إعادة توزيع`);
    await db.execute(`
      INSERT INTO notifications (companyId, assignmentId, type, title, body, createdAt)
      VALUES (?,?,'overload','تحميل زائد',
        CONCAT(?,': ',?,' مهام اليوم — يُنصح بإعادة التوزيع'),NOW())
    `, [companyId, emp.id, emp.name, emp.cnt]);
  }

  // ── تنبيه 2: مهمة أطول بـ 50% من التقدير ───────────────
  const longTasks = await db.query(`
    SELECT t.id, t.title, t.assignedTo, t.estimatedDuration,
      TIMESTAMPDIFF(MINUTE, t.scheduledStart, NOW()) AS elapsed,
      e.name, ea.id AS assignmentId
    FROM tasks t
    JOIN employee_assignments ea ON ea.id = t.assignedTo
    JOIN employees e ON e.id = ea.employeeId
    WHERE t.companyId=? AND t.branchId=?
      AND t.status = 'in_progress'
      AND t.estimatedDuration > 0
      AND TIMESTAMPDIFF(MINUTE, t.scheduledStart, NOW()) > t.estimatedDuration * 1.5
  `, [companyId, branchId]);

  for (const t of longTasks) {
    alerts.push(`⏱️ مهمة ${t.title}: تجاوزت التقدير بـ ${t.elapsed - t.estimatedDuration} دقيقة`);
    await db.execute(`
      INSERT INTO notifications (companyId, assignmentId, type, title, body, createdAt)
      VALUES (?,?,'long_task','مهمة تأخرت',
        CONCAT(?,': ',?,' دقيقة بدلاً من ',?),NOW())
    `, [companyId, t.assignmentId, t.title, t.elapsed, t.estimatedDuration]);
  }

  // ── تنبيه 3: 3 بلاغات لنفس العقار ────────────────────
  const repeatProperties = await db.query(`
    SELECT unitId, COUNT(*) AS cnt, u.unitNumber
    FROM maintenance_requests mr
    JOIN property_units u ON u.id = mr.unitId
    WHERE mr.companyId=? AND mr.branchId=?
      AND mr.createdAt > DATE_SUB(NOW(), INTERVAL 30 DAY)
    GROUP BY unitId
    HAVING cnt >= 3
  `, [companyId, branchId]);

  for (const p of repeatProperties) {
    alerts.push(`🏠 ${p.unitNumber}: ${p.cnt} بلاغات في 30 يوم — فحص شامل مطلوب`);
    await db.execute(`
      INSERT INTO tasks (companyId, branchId, type, title, priority, status, createdAt)
      VALUES (?,?,'inspection',CONCAT('فحص شامل: ',?),'high','pending',NOW())
      ON DUPLICATE KEY UPDATE id=id
    `, [companyId, branchId, p.unitNumber]);
  }

  // ── تنبيه 4: تقييم أقل من 3 نجوم ──────────────────────
  const lowRatings = await db.query(`
    SELECT ea.id, e.name, AVG(tr.rating) AS avgRating
    FROM task_ratings tr
    JOIN employee_assignments ea ON ea.id = tr.assignedTo
    JOIN employees e ON e.id = ea.employeeId
    WHERE tr.companyId=? AND tr.createdAt > DATE_SUB(NOW(), INTERVAL 30 DAY)
    GROUP BY ea.id
    HAVING avgRating < 3
  `, [companyId]);

  for (const emp of lowRatings) {
    alerts.push(`⭐ ${emp.name}: تقييم ${emp.avgRating.toFixed(1)} — اجتماع تقييم أداء`);
    await db.execute(`
      INSERT INTO tasks (companyId, type, title, priority, status, createdAt)
      VALUES (?,'performance_meeting',CONCAT('اجتماع أداء: ',?),'normal','pending',NOW())
    `, [companyId, emp.name]);
  }

  // ── تنبيه 5: فرع أقل من 80% SLA ───────────────────────
  const [branchSla] = await db.query(`
    SELECT
      SUM(status='completed' AND slaDeadline IS NOT NULL AND completedAt<=slaDeadline) AS met,
      SUM(status='completed' AND slaDeadline IS NOT NULL) AS total
    FROM tasks
    WHERE companyId=? AND branchId=?
      AND createdAt > DATE_SUB(NOW(), INTERVAL 7 DAY)
  `, [companyId, branchId]);

  if (branchSla[0]?.total >= 5) {
    const slaPercent = (branchSla[0].met / branchSla[0].total) * 100;
    if (slaPercent < slaWarningPct) {
      alerts.push(`📊 الفرع: SLA ${slaPercent.toFixed(0)}% أقل من الهدف ${slaWarningPct}% — مراجعة التوظيف`);
      await db.execute(`
        INSERT INTO notifications (companyId, type, title, body, targetRole, createdAt)
        VALUES (?,'branch_sla','SLA الفرع منخفض',
          CONCAT('SLA ',ROUND(?),'% — هل تحتاج موظفين إضافيين؟'),'branch_manager',NOW())
      `, [companyId, slaPercent]);
    }
  }

  // ── تنبيه 6: 3 ساعات بدون تحديث ──────────────────────
  const stuckTasks = await db.query(`
    SELECT t.id, t.title, t.assignedTo,
      e.name, ea.id AS assignmentId,
      TIMESTAMPDIFF(MINUTE, t.lastUpdatedAt, NOW()) AS silentMin
    FROM tasks t
    JOIN employee_assignments ea ON ea.id = t.assignedTo
    JOIN employees e ON e.id = ea.employeeId
    WHERE t.companyId=? AND t.branchId=?
      AND t.status = 'in_progress'
      AND t.lastUpdatedAt < DATE_SUB(NOW(), INTERVAL 3 HOUR)
      AND t.silentAlertSent = 0
  `, [companyId, branchId]);

  for (const t of stuckTasks) {
    alerts.push(`📡 ${t.name}: لا تحديث منذ ${Math.round(t.silentMin / 60)} ساعة`);
    await db.execute(`
      INSERT INTO notifications (companyId, assignmentId, type, title, body, createdAt)
      VALUES (?,?,'no_update','يرجى تحديث المهمة',
        CONCAT(?,': لم يُحدَّث منذ ',?,' ساعة'),NOW())
    `, [companyId, t.assignmentId, t.title, Math.round(t.silentMin / 60)]);
    await db.execute(`UPDATE tasks SET silentAlertSent=1 WHERE id=?`, [t.id]);
  }

  // ── تنبيه 7: مركبة بدون رحلة 3 أيام ──────────────────
  const idleVehicles = await db.query(`
    SELECT v.id, v.plate,
      DATEDIFF(NOW(), MAX(t.completedAt)) AS idleDays
    FROM fleet_vehicles v
    LEFT JOIN fleet_trips t ON t.vehicleId=v.id AND t.status='completed'
    WHERE v.companyId=? AND v.status='available'
    GROUP BY v.id
    HAVING idleDays > 3 OR idleDays IS NULL
  `, [companyId]);

  for (const v of idleVehicles) {
    alerts.push(`🚗 المركبة ${v.plate}: خاملة ${v.idleDays || '∞'} أيام`);
  }

  // ── تنبيه 8: عميل VIP لم يتواصل 30 يوم ───────────────
  const inactiveVips = await db.query(`
    SELECT id, name, phone,
      DATEDIFF(NOW(), lastActivityAt) AS daysSilent
    FROM clients
    WHERE companyId=?
      AND classification IN ('vip','premium')
      AND lastActivityAt < DATE_SUB(NOW(), INTERVAL 30 DAY)
      AND isBlacklisted=0
  `, [companyId]);

  for (const c of inactiveVips) {
    alerts.push(`👑 ${c.name} (VIP): لم يتواصل منذ ${c.daysSilent} يوم`);
    await db.execute(`
      INSERT INTO tasks (companyId, type, title, clientId, priority, status, scheduledDate, createdAt)
      VALUES (?,'client_checkup',CONCAT('تواصل مع عميل: ',?),?,'normal','pending',CURDATE(),NOW())
      ON DUPLICATE KEY UPDATE id=id
    `, [companyId, c.name, c.id]);
  }

  // ── تنبيه 9: ميزانية مشروع > 80% ─────────────────────
  const overspentProjects = await db.query(`
    SELECT id, name, projectCode, budget, budgetUsed,
      ROUND(budgetUsed/budget*100) AS pct
    FROM projects
    WHERE companyId=?
      AND status NOT IN ('completed','cancelled')
      AND budgetUsed >= budget * 0.8
  `, [companyId]);

  for (const p of overspentProjects) {
    alerts.push(`💰 مشروع ${p.projectCode}: ميزانية ${p.pct}% — تحذير`);
    await db.execute(`
      INSERT INTO notifications (companyId, type, title, body, targetRole, createdAt)
      VALUES (?,'budget_warning','تحذير ميزانية مشروع',
        CONCAT(?,': ',?,'% من الميزانية'),'pm',NOW())
    `, [companyId, p.projectCode, p.pct]);
  }

  // ── تنبيه 10: فاتورة متأخرة > 60 يوم → قانونية ────────
  const criticalInvoices = await db.query(`
    SELECT i.id, i.ref, i.total, cl.name AS clientName,
      DATEDIFF(NOW(), i.dueDate) AS daysLate
    FROM invoices i
    JOIN clients cl ON cl.id = i.clientId
    WHERE i.companyId=?
      AND i.status IN ('sent','overdue')
      AND DATEDIFF(NOW(), i.dueDate) >= 60
      AND NOT EXISTS (
        SELECT 1 FROM legal_cases lc
        WHERE lc.clientId=i.clientId AND lc.type='debt_collection' AND lc.status='open'
      )
  `, [companyId]);

  for (const inv of criticalInvoices) {
    alerts.push(`⚖️ فاتورة ${inv.ref}: ${inv.daysLate} يوم — تحويل قانونية`);
    await db.execute(`
      INSERT INTO legal_cases
        (companyId, clientId, type, description, amount, status, createdAt)
      VALUES (?,?,'debt_collection',CONCAT('تحصيل فاتورة ',?),?,'open',NOW())
    `, [companyId, inv.id, inv.ref, inv.total]);
  }

  return alerts;
}

// ══════════════════════════════════════════════
// Router
// ══════════════════════════════════════════════

export const intelligenceRouter = router({

  getDailySchedule: scopedProcedure
    .input(z.object({
      assignmentId: z.number(),
      date: z.string().optional(),
    }))
    .query(async ({ input, ctx }) => {
      const { companyId } = ctx.scope;
      const date = input.date || new Date().toISOString().slice(0, 10);
      return buildDailySchedule(input.assignmentId, date, companyId);
    }),

  getEmployeeKPIs: scopedProcedure
    .input(z.object({
      assignmentId: z.number(),
      periodDays: z.number().default(30),
    }))
    .query(async ({ input, ctx }) => {
      const { companyId } = ctx.scope;
      return calcEmployeeKPIs(input.assignmentId, companyId, input.periodDays);
    }),

  getBranchKPIs: scopedProcedure
    .query(async ({ ctx }) => {
      const { companyId, branchId } = ctx.scope;

      const employees = await db.query(`
        SELECT id FROM employee_assignments
        WHERE companyId=? AND branchId=? AND status='active'
      `, [companyId, branchId]);

      const kpis = await Promise.all(
        employees.map((e: any) => calcEmployeeKPIs(e.id, companyId, 30))
      );

      const avgScore = kpis.length
        ? +(kpis.reduce((s, k) => s + k.score, 0) / kpis.length).toFixed(1)
        : 0;

      return {
        branchId, employeeCount: employees.length,
        avgScore, kpis,
        topPerformer: kpis.sort((a, b) => b.score - a.score)[0] || null,
      };
    }),

  runSmartAlerts: scopedProcedure
    .mutation(async ({ ctx }) => {
      const { companyId, branchId } = ctx.scope;
      const alerts = await runSmartAlerts(companyId, branchId);
      return { alerts, count: alerts.length, runAt: new Date() };
    }),

  estimateTask: scopedProcedure
    .input(z.object({
      taskType: z.string(),
      fromLat: z.number(), fromLon: z.number(),
      toLat: z.number(), toLon: z.number(),
    }))
    .query(async ({ input, ctx }) => {
      const { companyId } = ctx.scope;
      const distKm = haversineKm(input.fromLat, input.fromLon, input.toLat, input.toLon);
      const travel = travelMin(distKm);
      const work = await estimateDuration(input.taskType, companyId);
      return {
        distanceKm: +distKm.toFixed(1),
        travelMin: travel,
        estimatedWorkMin: work,
        totalMin: travel + work,
      };
    }),
});

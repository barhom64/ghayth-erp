/**
 * phase5EventHandlers.ts — منصة غيث ERP
 * معالجات الأحداث للمرحلة 5 — ربط التواصل بكل الوحدات
 */

import { eventBus } from "../../core/eventBus.js";
import { db } from "../../core/db.js";
import { NotificationService } from "./automationEngine.js";

// ── موظف جديد → حساب SIP + إيميل تلقائي ────────
eventBus.on("EMPLOYEE_CREATED", async (payload: any) => {
  const { employeeId, assignmentId, companyId } = payload;

  // تُنفَّذ setupEmployeeCommunications تلقائياً
  await db.execute(`
    INSERT INTO system_jobs
      (companyId, jobType, refType, refId, status, scheduledAt)
    VALUES (?,'setup_communications','employee_assignment',?,  'pending',NOW())
  `, [companyId, assignmentId]);
});

// ── عميل جديد → مرحباً تلقائي عبر واتساب ──────
eventBus.on("CLIENT_CREATED", async (payload: any) => {
  const { clientId, phone, source, companyId } = payload;
  if (source !== "whatsapp") return;

  await NotificationService.send({
    companyId, clientId,
    type: "welcome",
    title: "مرحباً",
    body: "مرحباً بك في مجموعة الدور 🌟\nيسعدنا خدمتك. كيف نقدر نساعدك؟",
    channels: ["whatsapp"],
    priority: "normal",
  });
});

// ── فاتورة منشأة → إرسال تلقائي للعميل ─────────
eventBus.on("INVOICE_CREATED", async (payload: any) => {
  const { invoiceId, clientId, total, companyId } = payload;

  const [invoices] = await db.query(`SELECT ref FROM invoices WHERE id=?`, [invoiceId]);
  const invoiceRef = invoices[0]?.ref || `INV-${invoiceId}`;

  await NotificationService.send({
    companyId, clientId,
    type: "invoice_sent",
    title: "فاتورة جديدة",
    body: `فاتورة ${invoiceRef} بمبلغ ${total.toFixed(0)} ريال — يمكنك الدفع عبر بوابتك`,
    channels: ["whatsapp", "email"],
    priority: "normal",
  });
});

// ── مهمة صيانة مكتملة → تقييم العميل ───────────
eventBus.on("MAINTENANCE_COMPLETED", async (payload: any) => {
  const { mrId, companyId } = payload;

  const [mrs] = await db.query(`
    SELECT clientId FROM maintenance_requests WHERE id=?
  `, [mrId]);
  if (!mrs[0]) return;

  await NotificationService.send({
    companyId, clientId: mrs[0].clientId,
    type: "rating_request",
    title: "كيف كانت الخدمة؟",
    body: `تم إنجاز طلب الصيانة #${mrId} ✓\nقيّم تجربتك: https://rate.door.sa/mr/?id=${mrId}`,
    channels: ["whatsapp"],
    priority: "low",
  });
});

// ── تذكرة دعم مغلقة → استبيان ──────────────────
eventBus.on("SUPPORT_TICKET_CLOSED", async (payload: any) => {
  const { ticketId, companyId } = payload;

  const [tickets] = await db.query(`
    SELECT clientId FROM support_tickets WHERE id=?
  `, [ticketId]);
  if (!tickets[0]) return;

  await NotificationService.send({
    companyId, clientId: tickets[0].clientId,
    type: "survey",
    title: "شاركنا رأيك",
    body: `تم حل طلب الدعم #${ticketId}\nكيف كانت تجربتك؟ https://rate.door.sa/support/?id=${ticketId}`,
    channels: ["whatsapp"],
    priority: "low",
  });
});

// ── فرصة بيع رُبحت → إشعار فريق المبيعات ────────
eventBus.on("CRM_OPPORTUNITY_WON", async (payload: any) => {
  const { oppNumber, value, companyId } = payload;

  await NotificationService.sendToRole(companyId, "sales", {
    type: "opportunity_won",
    title: "🎉 فرصة جديدة مُربحة!",
    body: `تم إغلاق فرصة ${oppNumber} بقيمة ${value.toFixed(0)} ريال ✅`,
    channels: ["in_app", "whatsapp"],
    priority: "high",
  });
});

console.log("[Phase 5] Event handlers registered ✓");

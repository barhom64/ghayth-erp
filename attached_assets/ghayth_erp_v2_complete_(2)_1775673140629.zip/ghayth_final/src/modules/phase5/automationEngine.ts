/**
 * automationEngine.ts — منصة غيث ERP
 * المرجع: ملف 08 — الأتمتة الشاملة
 * 26 وظيفة Cron الكاملة + NotificationService 4 قنوات
 * الوظائف 1-9 في hrCronJobs.ts، 10-17 في phase4CronJobs.ts
 * هنا: الوظائف الباقية + NotificationService + لوحة التحكم
 */

import { z } from "zod";
import { scopedProcedure, router } from "../../core/trpc.js";
import { db } from "../../core/db.js";
import { eventBus } from "../../core/eventBus.js";
import { runSmartAlerts } from "./intelligenceEngine.js";

// ══════════════════════════════════════════════
// NotificationService — 4 قنوات
// ══════════════════════════════════════════════

export interface NotificationPayload {
  companyId: number;
  assignmentId?: number;
  clientId?: number;
  type: string;
  title: string;
  body: string;
  channels: NotificationChannel[];
  priority?: "low" | "normal" | "high" | "urgent";
  actionUrl?: string;
  refType?: string;
  refId?: number;
}

type NotificationChannel = "in_app" | "email" | "sms" | "whatsapp";

export class NotificationService {

  static async send(payload: NotificationPayload): Promise<void> {
    const channels = payload.channels;
    const promises: Promise<void>[] = [];

    for (const channel of channels) {
      switch (channel) {
        case "in_app":
          promises.push(this.sendInApp(payload));
          break;
        case "email":
          promises.push(this.sendEmail(payload));
          break;
        case "sms":
          promises.push(this.sendSMS(payload));
          break;
        case "whatsapp":
          promises.push(this.sendWhatsApp(payload));
          break;
      }
    }

    await Promise.allSettled(promises);

    // سجل التدقيق
    await db.execute(`
      INSERT INTO notification_log
        (companyId, assignmentId, clientId, type, title, channels, sentAt)
      VALUES (?,?,?,?,?,?,NOW())
    `, [
      payload.companyId,
      payload.assignmentId || null,
      payload.clientId || null,
      payload.type, payload.title,
      JSON.stringify(channels),
    ]);
  }

  // ── قناة 1: داخل التطبيق ─────────────────────
  private static async sendInApp(p: NotificationPayload): Promise<void> {
    await db.execute(`
      INSERT INTO notifications
        (companyId, assignmentId, type, title, body, priority, actionUrl, refType, refId, createdAt)
      VALUES (?,?,?,?,?,?,?,?,?,NOW())
    `, [
      p.companyId, p.assignmentId || null,
      p.type, p.title, p.body,
      p.priority || "normal",
      p.actionUrl || null,
      p.refType || null, p.refId || null,
    ]);
  }

  // ── قناة 2: البريد الإلكتروني ─────────────────
  private static async sendEmail(p: NotificationPayload): Promise<void> {
    if (!p.assignmentId && !p.clientId) return;

    const [recipient] = await db.query(`
      SELECT
        COALESCE(e.email, cl.email) AS toEmail,
        COALESCE(e.name, cl.name) AS recipientName
      FROM (
        SELECT ea.id, emp.email, emp.name
        FROM employee_assignments ea
        JOIN employees emp ON emp.id = ea.employeeId
        WHERE ea.id = ?
        UNION
        SELECT NULL, cl.email, cl.name
        FROM clients cl WHERE cl.id = ?
      ) AS r(id, email, name)
      LIMIT 1
    `, [p.assignmentId || null, p.clientId || null]);

    if (!recipient[0]?.toEmail) return;

    await db.execute(`
      INSERT INTO email_queue
        (companyId, toEmail, recipientName, subject, body, priority, scheduledAt)
      VALUES (?,?,?,?,?,?,NOW())
    `, [
      p.companyId,
      recipient[0].toEmail,
      recipient[0].recipientName,
      p.title, p.body,
      p.priority || "normal",
    ]);
  }

  // ── قناة 3: SMS ───────────────────────────────
  private static async sendSMS(p: NotificationPayload): Promise<void> {
    let phone: string | null = null;

    if (p.clientId) {
      const [cl] = await db.query(`SELECT phone FROM clients WHERE id=?`, [p.clientId]);
      phone = cl[0]?.phone || null;
    } else if (p.assignmentId) {
      const [ea] = await db.query(`
        SELECT e.phone FROM employee_assignments ea
        JOIN employees e ON e.id = ea.employeeId WHERE ea.id=?
      `, [p.assignmentId]);
      phone = ea[0]?.phone || null;
    }

    if (!phone) return;

    // SMS محدود: 160 حرف
    const smsBody = p.body.length > 155 ? p.body.slice(0, 152) + "..." : p.body;

    await db.execute(`
      INSERT INTO sms_queue (companyId, phone, clientId, assignmentId, message, scheduledAt)
      VALUES (?,?,?,?,?,NOW())
    `, [p.companyId, phone, p.clientId || null, p.assignmentId || null, smsBody]);
  }

  // ── قناة 4: واتساب ────────────────────────────
  private static async sendWhatsApp(p: NotificationPayload): Promise<void> {
    let phone: string | null = null;
    let name = "";

    if (p.clientId) {
      const [cl] = await db.query(`SELECT phone, name FROM clients WHERE id=?`, [p.clientId]);
      phone = cl[0]?.phone || null;
      name  = cl[0]?.name  || "";
    } else if (p.assignmentId) {
      const [ea] = await db.query(`
        SELECT e.phone, e.name FROM employee_assignments ea
        JOIN employees e ON e.id = ea.employeeId WHERE ea.id=?
      `, [p.assignmentId]);
      phone = ea[0]?.phone || null;
      name  = ea[0]?.name  || "";
    }

    if (!phone) return;

    await db.execute(`
      INSERT INTO whatsapp_queue
        (companyId, phone, recipientName, clientId, assignmentId, message,
         templateName, status, scheduledAt)
      VALUES (?,?,?,?,?,?, NULL, 'queued', NOW())
    `, [
      p.companyId, phone, name,
      p.clientId || null, p.assignmentId || null,
      `*${p.title}*\n${p.body}`,
    ]);
  }

  // ── إرسال جماعي لدور معين ─────────────────────
  static async sendToRole(
    companyId: number,
    role: string,
    payload: Omit<NotificationPayload, "companyId" | "assignmentId">
  ): Promise<void> {
    const assignments = await db.query(`
      SELECT id FROM employee_assignments
      WHERE companyId=? AND role=? AND status='active'
    `, [companyId, role]);

    for (const ea of assignments) {
      await this.send({ ...payload, companyId, assignmentId: ea.id });
    }
  }
}

// ══════════════════════════════════════════════
// بقية الـ 26 وظيفة Cron (المكملة)
// ══════════════════════════════════════════════

// ── Cron #18 — يوم 25: تذكير رواتب ────────────
export async function cronPayrollReminder() {
  const companies = await db.query(`SELECT id FROM companies WHERE status='active'`);
  for (const { id: companyId } of companies) {
    await NotificationService.sendToRole(companyId, "hr", {
      type: "payroll_reminder",
      title: "تذكير: مسير الرواتب",
      body: "مسير رواتب الشهر يحتاج تشغيل وتحضير — تأكد من اكتمال البيانات",
      channels: ["in_app", "whatsapp"],
      priority: "high",
    });
  }
  console.log("[Cron #18] Payroll reminders sent");
}

// ── Cron #19 — يوم 28: إقفال شهر ──────────────
export async function cronMonthlyClose() {
  const companies = await db.query(`SELECT id FROM companies WHERE status='active'`);
  for (const { id: companyId } of companies) {
    const month = new Date();
    month.setDate(1);
    const monthStr = month.toISOString().slice(0, 7);

    // تحقق من عدم وجود إقفال مسبق
    const [existing] = await db.query(`
      SELECT id FROM monthly_closes WHERE companyId=? AND period=?
    `, [companyId, monthStr]);
    if (existing.length) continue;

    // جمع الأرصدة الختامية
    const [balances] = await db.query(`
      SELECT
        SUM(CASE WHEN jl.debit > 0 THEN jl.debit ELSE 0 END) AS totalDebits,
        SUM(CASE WHEN jl.credit > 0 THEN jl.credit ELSE 0 END) AS totalCredits,
        COUNT(DISTINCT je.id) AS journalCount
      FROM journal_entries je
      JOIN journal_lines jl ON jl.journalId = je.id
      WHERE je.companyId=?
        AND MONTH(je.createdAt)=MONTH(NOW()-INTERVAL 0 DAY)
        AND YEAR(je.createdAt)=YEAR(NOW())
    `, [companyId]);

    await db.execute(`
      INSERT INTO monthly_closes
        (companyId, period, totalDebits, totalCredits, journalCount, status, createdAt)
      VALUES (?,?,?,?,?,'draft',NOW())
    `, [
      companyId, monthStr,
      balances[0]?.totalDebits || 0,
      balances[0]?.totalCredits || 0,
      balances[0]?.journalCount || 0,
    ]);

    await NotificationService.sendToRole(companyId, "finance_manager", {
      type: "month_close",
      title: "إقفال الشهر",
      body: `الشهر ${monthStr} جاهز للمراجعة والاعتماد — القيود: ${balances[0]?.journalCount || 0}`,
      channels: ["in_app", "email"],
      priority: "high",
    });
  }
  console.log("[Cron #19] Monthly close drafted");
}

// ── Cron #20-22 — الاثنين: تقارير أسبوعية ──────
export async function cronWeeklyReports() {
  const companies = await db.query(`SELECT id FROM companies WHERE status='active'`);

  for (const { id: companyId } of companies) {
    const weekStart = new Date();
    weekStart.setDate(weekStart.getDate() - 7);

    // تقرير HR أسبوعي
    const [hrStats] = await db.query(`
      SELECT
        COUNT(DISTINCT a.employeeId) AS presentCount,
        COUNT(DISTINCT v.id) AS violations,
        COUNT(DISTINCT lr.id) AS leaveRequests,
        AVG(a.lateMinutes) AS avgLate
      FROM attendance a
      LEFT JOIN employee_violations v ON v.companyId=a.companyId
        AND v.createdAt >= ?
      LEFT JOIN hr_leave_requests lr ON lr.companyId=a.companyId
        AND lr.createdAt >= ?
      WHERE a.companyId=? AND a.date >= ?
    `, [weekStart, weekStart, companyId, weekStart]);

    // تقرير الأسطول أسبوعي
    const [fleetStats] = await db.query(`
      SELECT COUNT(*) AS trips, SUM(totalCost) AS totalCost, AVG(actualDistanceKm) AS avgDistance
      FROM fleet_trips WHERE companyId=? AND completedAt >= ?
    `, [companyId, weekStart]);

    // تقرير الدعم أسبوعي
    const [supportStats] = await db.query(`
      SELECT COUNT(*) AS tickets,
        SUM(resolvedWithinSla) AS slamet,
        COUNT(*) AS total
      FROM support_tickets WHERE companyId=? AND createdAt >= ?
    `, [companyId, weekStart]);

    const reportBody = [
      `📊 تقرير الأسبوع`,
      `👥 HR: ${hrStats[0]?.presentCount || 0} حضور | ${hrStats[0]?.violations || 0} مخالفة`,
      `🚗 الأسطول: ${fleetStats[0]?.trips || 0} رحلة | ${fleetStats[0]?.totalCost?.toFixed(0) || 0} ريال`,
      `🎫 الدعم: ${supportStats[0]?.tickets || 0} تذكرة | SLA ${supportStats[0]?.total > 0 ? ((supportStats[0]?.slamet / supportStats[0]?.total) * 100).toFixed(0) : 100}%`,
    ].join("\n");

    await NotificationService.sendToRole(companyId, "gm", {
      type: "weekly_report",
      title: "التقرير الأسبوعي",
      body: reportBody,
      channels: ["in_app", "whatsapp"],
    });
  }
  console.log("[Cron #20-22] Weekly reports sent");
}

// ── Cron #23 — أسبوعي: تدفق نقدي ─────────────
export async function cronCashFlow() {
  const companies = await db.query(`SELECT id FROM companies WHERE status='active'`);

  for (const { id: companyId } of companies) {
    // الإيرادات المتوقعة الأسبوعين القادمين
    const [upcoming] = await db.query(`
      SELECT
        SUM(CASE WHEN type='receivable' THEN amount ELSE 0 END) AS expectedIn,
        SUM(CASE WHEN type='payable'    THEN amount ELSE 0 END) AS expectedOut
      FROM cash_flow_items
      WHERE companyId=?
        AND expectedDate BETWEEN NOW() AND DATE_ADD(NOW(), INTERVAL 14 DAY)
    `, [companyId]);

    const net = (upcoming[0]?.expectedIn || 0) - (upcoming[0]?.expectedOut || 0);
    const status = net >= 0 ? "✅ إيجابي" : "⚠️ سلبي";

    await NotificationService.sendToRole(companyId, "finance_manager", {
      type: "cashflow_report",
      title: "تقرير التدفق النقدي",
      body: `14 يوم القادمة:\nداخل: ${upcoming[0]?.expectedIn?.toFixed(0) || 0} ريال\nخارج: ${upcoming[0]?.expectedOut?.toFixed(0) || 0} ريال\nصافي: ${net.toFixed(0)} ريال ${status}`,
      channels: ["in_app", "email"],
    });
  }
  console.log("[Cron #23] Cash flow reports sent");
}

// ── Cron #24 — أسبوعي: إيرادات عقارية ─────────
export async function cronPropertyRevenue() {
  const companies = await db.query(`SELECT id FROM companies WHERE status='active'`);

  for (const { id: companyId } of companies) {
    const [stats] = await db.query(`
      SELECT
        COUNT(*) AS totalUnits,
        SUM(status='occupied') AS occupied,
        SUM(status='vacant') AS vacant,
        SUM(rp.amount) AS weeklyRevenue,
        COUNT(DISTINCT rc.id) AS overdueContracts
      FROM property_units pu
      LEFT JOIN rental_contracts rc ON rc.unitId=pu.id AND rc.status='active'
      LEFT JOIN rent_payments rp ON rp.contractId=rc.id
        AND rp.paidAt > DATE_SUB(NOW(), INTERVAL 7 DAY)
      WHERE pu.companyId=?
    `, [companyId]);

    const occupancyRate = stats[0]?.totalUnits > 0
      ? ((stats[0].occupied / stats[0].totalUnits) * 100).toFixed(0)
      : 0;

    await NotificationService.sendToRole(companyId, "property_manager", {
      type: "property_report",
      title: "تقرير الأملاك الأسبوعي",
      body: `🏠 الوحدات: ${stats[0]?.totalUnits || 0} | مُؤجَّر: ${occupancyRate}%\n💰 إيرادات الأسبوع: ${stats[0]?.weeklyRevenue?.toFixed(0) || 0} ريال`,
      channels: ["in_app"],
    });
  }
  console.log("[Cron #24] Property revenue reports sent");
}

// ── Cron #25 — شهري: تقرير مخزون ──────────────
export async function cronMonthlyInventory() {
  const companies = await db.query(`SELECT id FROM companies WHERE status='active'`);

  for (const { id: companyId } of companies) {
    const branches = await db.query(`
      SELECT id FROM branches WHERE companyId=? AND status='active'
    `, [companyId]);

    for (const { id: branchId } of branches) {
      const [stats] = await db.query(`
        SELECT
          COUNT(*) AS totalProducts,
          SUM(currentQty * unitCost) AS totalValue,
          SUM(currentQty <= minQty) AS lowStockCount,
          SUM(currentQty = 0) AS outOfStockCount
        FROM warehouse_products
        WHERE companyId=? AND branchId=?
      `, [companyId, branchId]);

      await db.execute(`
        INSERT INTO inventory_snapshots
          (companyId, branchId, period, totalProducts, totalValue,
           lowStockCount, outOfStockCount, snapshotAt)
        VALUES (?,?,DATE_FORMAT(NOW(),'%Y-%m'),?,?,?,?,NOW())
        ON DUPLICATE KEY UPDATE
          totalValue=VALUES(totalValue),
          lowStockCount=VALUES(lowStockCount)
      `, [
        companyId, branchId,
        stats[0]?.totalProducts || 0,
        stats[0]?.totalValue    || 0,
        stats[0]?.lowStockCount || 0,
        stats[0]?.outOfStockCount || 0,
      ]);
    }
  }
  console.log("[Cron #25] Monthly inventory snapshots done");
}

// ── Cron #26 — 1 يناير: تجديد أرصدة إجازات ────
// موجود في hrCronJobs.ts

// ── Cron كل ساعة: التنبيهات الذكية ────────────
export async function cronSmartAlerts() {
  const activeBranches = await db.query(`
    SELECT c.id AS companyId, b.id AS branchId
    FROM companies c
    JOIN branches b ON b.companyId = c.id AND b.status = 'active'
    WHERE c.status = 'active'
  `);

  let total = 0;
  for (const { companyId, branchId } of activeBranches) {
    const alerts = await runSmartAlerts(companyId, branchId);
    total += alerts.length;
  }
  console.log(`[Cron Smart] ${total} تنبيه ذكي`);
}

// ══════════════════════════════════════════════
// جدول كامل الـ 26 وظيفة
// ══════════════════════════════════════════════

export const fullCronSchedule = [
  // ── من hrCronJobs.ts ──
  { id:  1, name: "cronDocumentExpiry",     time: "0 6 * * *",     unit: "HR" },
  { id:  2, name: "cronEmployeeContracts",  time: "0 6 * * *",     unit: "HR" },
  { id:  4, name: "cronLeaveBalance",       time: "0 7 * * *",     unit: "HR" },
  { id:  5, name: "cronAbsentees",          time: "0 11 * * *",    unit: "HR" },
  { id:  6, name: "cronEscalateApprovals",  time: "0 * * * *",     unit: "All" },
  { id:  7, name: "cronSupportSLA",         time: "0 * * * *",     unit: "Support" },
  { id:  8, name: "cronAttendanceDeductions",time:"0 23 * * *",    unit: "HR" },
  { id:  9, name: "cronOverdueInvoices",    time: "0 9 * * *",     unit: "Finance" },
  // ── من phase4CronJobs.ts ──
  { id:  3, name: "cronFleetAlerts",        time: "0 6 * * *",     unit: "Fleet" },
  { id: 10, name: "cronFuelAnomalies",      time: "0 20 * * *",    unit: "Fleet" },
  { id: 11, name: "cronWarehouseMinStock",  time: "0 7 * * *",     unit: "Warehouse" },
  { id: 12, name: "cronRentalContracts",    time: "0 7 * * *",     unit: "Properties" },
  { id: 13, name: "cronLegalAlerts",        time: "0 6 * * *",     unit: "Legal" },
  { id: 14, name: "cronProjectDelays",      time: "0 8 * * *",     unit: "Projects" },
  { id: 15, name: "cronCrmFollowups",       time: "0 9 * * *",     unit: "CRM" },
  { id: 16, name: "cronSlaBreaches",        time: "0 * * * *",     unit: "All" },
  { id: 17, name: "cronMonthlyRentProcessing",time:"0 8 1 * *",    unit: "Properties" },
  // ── من هنا ──
  { id: 18, name: "cronPayrollReminder",    time: "0 8 25 * *",    unit: "HR" },
  { id: 19, name: "cronMonthlyClose",       time: "0 8 28 * *",    unit: "Finance" },
  { id: 20, name: "cronWeeklyReports",      time: "0 8 * * 1",     unit: "Multi" },
  { id: 21, name: "cronWeeklyReports",      time: "0 8 * * 1",     unit: "Multi" },
  { id: 22, name: "cronWeeklyReports",      time: "0 8 * * 1",     unit: "Multi" },
  { id: 23, name: "cronCashFlow",           time: "0 9 * * 0",     unit: "Finance" },
  { id: 24, name: "cronPropertyRevenue",    time: "0 9 * * 0",     unit: "Properties" },
  { id: 25, name: "cronMonthlyInventory",   time: "0 1 1 * *",     unit: "Warehouse" },
  { id: 26, name: "cronLeaveRenewal",       time: "0 0 1 1 *",     unit: "HR" },
];

// ══════════════════════════════════════════════
// لوحة تحكم الأتمتة
// ══════════════════════════════════════════════

export const automationRouter = router({

  // عرض حالة كل الـ Cron
  getCronStatus: scopedProcedure
    .query(async ({ ctx }) => {
      const { companyId } = ctx.scope;

      const logs = await db.query(`
        SELECT jobName, lastRunAt, lastStatus, lastDuration, lastCount
        FROM cron_logs
        WHERE companyId=?
        ORDER BY lastRunAt DESC
      `, [companyId]);

      const logMap: Record<string, any> = {};
      for (const l of logs) logMap[l.jobName] = l;

      return fullCronSchedule.map(cron => ({
        ...cron,
        lastRun:      logMap[cron.name]?.lastRunAt  || null,
        lastStatus:   logMap[cron.name]?.lastStatus || "never",
        lastDuration: logMap[cron.name]?.lastDuration || null,
        lastCount:    logMap[cron.name]?.lastCount  || 0,
      }));
    }),

  // تشغيل يدوي لوظيفة Cron
  runCronManually: scopedProcedure
    .input(z.object({ cronId: z.number() }))
    .mutation(async ({ input, ctx }) => {
      const { companyId } = ctx.scope;
      const cron = fullCronSchedule.find(c => c.id === input.cronId);
      if (!cron) throw new Error("الوظيفة غير موجودة");

      const start = Date.now();
      // تُستدعى الوظيفة من السيرفر مباشرة عبر worker
      await db.execute(`
        INSERT INTO cron_manual_triggers
          (companyId, cronId, cronName, triggeredBy, createdAt)
        VALUES (?,?,?,?,NOW())
      `, [companyId, input.cronId, cron.name, ctx.scope.userId]);

      return { cronId: input.cronId, name: cron.name, triggered: true };
    }),

  // إحصائيات الإشعارات
  getNotificationStats: scopedProcedure
    .input(z.object({ days: z.number().default(7) }))
    .query(async ({ input, ctx }) => {
      const { companyId } = ctx.scope;

      return db.query(`
        SELECT
          channel,
          COUNT(*) AS sent,
          SUM(status='delivered') AS delivered,
          SUM(status='failed') AS failed,
          ROUND(AVG(CASE WHEN status='delivered' THEN 1 ELSE 0 END)*100,1) AS deliveryRate
        FROM notification_log
        WHERE companyId=?
          AND sentAt > DATE_SUB(NOW(), INTERVAL ? DAY)
        GROUP BY channel
      `, [companyId, input.days]);
    }),

  // إرسال إشعار يدوي
  sendManualNotification: scopedProcedure
    .input(z.object({
      assignmentIds: z.array(z.number()).optional(),
      clientIds: z.array(z.number()).optional(),
      role: z.string().optional(),
      title: z.string(),
      body: z.string(),
      channels: z.array(z.enum(["in_app","email","sms","whatsapp"])),
      priority: z.enum(["low","normal","high","urgent"]).default("normal"),
    }))
    .mutation(async ({ input, ctx }) => {
      const { companyId } = ctx.scope;
      let sent = 0;

      // إرسال لـ assignmentIds
      for (const assignmentId of input.assignmentIds || []) {
        await NotificationService.send({
          companyId, assignmentId,
          type: "manual",
          title: input.title,
          body: input.body,
          channels: input.channels as NotificationChannel[],
          priority: input.priority,
        });
        sent++;
      }

      // إرسال لـ clientIds
      for (const clientId of input.clientIds || []) {
        await NotificationService.send({
          companyId, clientId,
          type: "manual",
          title: input.title,
          body: input.body,
          channels: input.channels as NotificationChannel[],
          priority: input.priority,
        });
        sent++;
      }

      // إرسال لدور معين
      if (input.role) {
        await NotificationService.sendToRole(companyId, input.role, {
          type: "manual",
          title: input.title,
          body: input.body,
          channels: input.channels as NotificationChannel[],
          priority: input.priority,
        });
        sent++;
      }

      return { sent };
    }),
});

export default { cronFleetAlerts: cronFleetAlerts ?? function(){}, cronFuelAnomalies: cronFuelAnomalies ?? function(){}, cronWarehouseMinStock: cronWarehouseMinStock ?? function(){}, cronRentalContracts: cronRentalContracts ?? function(){}, cronLegalAlerts: cronLegalAlerts ?? function(){}, cronProjectDelays: cronProjectDelays ?? function(){}, cronCrmFollowups: cronCrmFollowups ?? function(){}, cronSlaBreaches: cronSlaBreaches ?? function(){}, cronMonthlyRentProcessing: cronMonthlyRentProcessing ?? function(){} };

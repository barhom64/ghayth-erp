/**
 * hrRouter.ts — منصة غيث ERP
 * الموارد البشرية: موظف 11 خطوة + حضور 17 + إجازة 18 + رواتب 12
 */

import { z } from "zod";
import { router, scopedProcedure } from "../../core/trpc.js";
import { rawQuery, rawExecute, withTransaction } from "../../core/db.js";
import { eventBus, auditLogger, getSetting } from "../../core/eventBus.js";
import { requirePermission } from "../../core/permissions.js";

function haversineKm(lat1: number, lon1: number, lat2: number, lon2: number): number {
  const R = 6371;
  const dLat = ((lat2 - lat1) * Math.PI) / 180;
  const dLon = ((lon2 - lon1) * Math.PI) / 180;
  const a = Math.sin(dLat / 2) ** 2
    + Math.cos((lat1 * Math.PI) / 180) * Math.cos((lat2 * Math.PI) / 180)
    * Math.sin(dLon / 2) ** 2;
  return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
}

// ══════════════════════════════════════════════
// إضافة موظف — 11 خطوة
// ══════════════════════════════════════════════

async function createEmployeePipeline(input: any, companyId: number, branchId: number, userId: number) {
  return withTransaction(async (conn) => {
    // 1. حفظ الموظف
    const [empR] = await conn.execute(
      `INSERT INTO employees (nationalId,name,phone,email,gender,nationality,status,createdAt)
       VALUES (?,?,?,?,?,?,'active',NOW())`,
      [input.nationalId||null, input.name, input.phone, input.email||null, input.gender||null, input.nationality||null]
    ) as any;
    const employeeId = empR.insertId;

    // 2. توليد الرقم الوظيفي
    const [[cntRow]] = await conn.execute(`SELECT COUNT(*) AS cnt FROM employees WHERE id<=?`, [employeeId]) as any;
    const empNumber = `EMP-${new Date().getFullYear()}-${String(cntRow.cnt).padStart(3,"0")}`;
    await conn.execute(`UPDATE employees SET empNumber=? WHERE id=?`, [empNumber, employeeId]);

    // 3. أول تعيين
    const [asmR] = await conn.execute(
      `INSERT INTO employee_assignments (employeeId,companyId,branchId,departmentId,jobTitle,role,salary,isPrimary,hireDate,status,createdAt)
       VALUES (?,?,?,?,?,?,?,1,?,'active',NOW())`,
      [employeeId,companyId,branchId,input.departmentId||null,input.jobTitle,input.role||"employee",input.salary||0,input.hireDate]
    ) as any;
    const assignmentId = asmR.insertId;

    // 4. أرصدة إجازات
    const [leaveTypes] = await conn.execute(`SELECT id,annualDays FROM hr_leave_types WHERE companyId=? AND status='active'`, [companyId]) as any;
    for (const lt of leaveTypes) {
      await conn.execute(
        `INSERT INTO hr_leave_balances (companyId,employeeId,assignmentId,leaveTypeId,year,entitled,used) VALUES (?,?,?,?,YEAR(NOW()),?,0)`,
        [companyId,employeeId,assignmentId,lt.id,lt.annualDays]
      );
    }

    // 5. وردية افتراضية
    const [[shift]] = await conn.execute(`SELECT id FROM shifts WHERE branchId=? AND isDefault=1 LIMIT 1`, [branchId]) as any;
    if (shift) {
      await conn.execute(`INSERT INTO employee_shift_assignments (assignmentId,shiftId,startDate) VALUES (?,?,?)`, [assignmentId,shift.id,input.hireDate]);
    }

    // 6. فترة التجربة
    const probEnd = new Date(input.hireDate); probEnd.setDate(probEnd.getDate()+90);
    await conn.execute(`UPDATE employee_assignments SET probationEndDate=? WHERE id=?`, [probEnd.toISOString().slice(0,10), assignmentId]);

    // 7. 4 مهام Onboarding
    for (const title of ["تسليم أجهزة IT","توقيع عقد العمل","تعريف المدير","دورة التعريف"]) {
      await conn.execute(
        `INSERT INTO tasks (companyId,branchId,type,title,scheduledDate,status,priority,createdAt) VALUES (?,?,'onboarding',?,DATE_ADD(?,INTERVAL 3 DAY),'pending','normal',NOW())`,
        [companyId,branchId,title,input.hireDate]
      );
    }

    // 8. إشعار HR والمدير
    await conn.execute(
      `INSERT INTO notifications (companyId,assignmentId,type,title,body,createdAt)
       SELECT ?,ea.id,'new_employee','موظف جديد',CONCAT(?,': ',?,' يباشر ',?),NOW()
       FROM employee_assignments ea WHERE ea.companyId=? AND ea.role IN ('hr','branch_manager') AND ea.status='active'`,
      [companyId,empNumber,input.name,input.hireDate,companyId]
    );

    // 9. إيميل ترحيب
    if (input.email) {
      await conn.execute(
        `INSERT INTO email_queue (companyId,toEmail,subject,body,scheduledAt) VALUES (?,?,?,?,NOW())`,
        [companyId,input.email,`مرحباً ${input.name}`,`رقمك: ${empNumber} | القسم: ${input.jobTitle} | اليوم الأول: ${input.hireDate}`]
      );
    }

    // 10. سجل التدقيق
    await conn.execute(
      `INSERT INTO audit_logs (companyId,branchId,userId,action,entity,entityId,after,createdAt) VALUES (?,?,?,'EMPLOYEE_CREATED','employees',?,?,NOW())`,
      [companyId,branchId,userId,employeeId,JSON.stringify({empNumber,assignmentId})]
    );

    // 11. حدث
    eventBus.emit("EMPLOYEE_CREATED", {employeeId,assignmentId,companyId,branchId});
    return {employeeId,assignmentId,empNumber};
  });
}

// ══════════════════════════════════════════════
// تسجيل الحضور — 17 خطوة
// ══════════════════════════════════════════════

async function checkInPipeline(assignmentId: number, lat: number, lon: number, companyId: number, branchId: number) {
  const today = new Date().toISOString().slice(0,10);
  const now   = new Date();

  const [existing] = await rawQuery<any>(`SELECT id FROM attendance WHERE assignmentId=? AND date=?`, [assignmentId,today]);
  if (existing) throw new Error("تم تسجيل الحضور مسبقاً");

  const [shiftRow] = await rawQuery<any>(
    `SELECT s.startTime, ea.employeeId FROM employee_shift_assignments esa
     JOIN shifts s ON s.id=esa.shiftId JOIN employee_assignments ea ON ea.id=esa.assignmentId
     WHERE esa.assignmentId=? AND (esa.endDate IS NULL OR esa.endDate>=?)`,
    [assignmentId,today]
  );
  if (!shiftRow) throw new Error("لا توجد وردية");

  const [onLeave] = await rawQuery<any>(
    `SELECT id FROM hr_leave_requests WHERE employeeId=? AND status='approved' AND startDate<=? AND endDate>=?`,
    [shiftRow.employeeId,today,today]
  );
  if (onLeave) {
    await rawExecute(`INSERT INTO attendance (companyId,branchId,assignmentId,date,status,method,createdAt) VALUES (?,?,?,?,'leave','auto',NOW())`, [companyId,branchId,assignmentId,today]);
    return {status:"leave"};
  }

  const [sh,sm] = shiftRow.startTime.split(":").map(Number);
  const shiftStart = new Date(now); shiftStart.setHours(sh,sm,0,0);
  const lateMinutes = Math.max(0, Math.round((now.getTime()-shiftStart.getTime())/60000));

  const [branch] = await rawQuery<any>(`SELECT lat,lon FROM branches WHERE id=?`, [branchId]);
  const radius = await getSetting("hr.gpsRadiusMeters",branchId,companyId) as number || 200;
  const dist = haversineKm(+branch.lat,+branch.lon,lat,lon)*1000;
  if (dist>radius) throw new Error(`خارج نطاق العمل (${Math.round(dist)}م)`);

  const [attR] = await rawExecute(
    `INSERT INTO attendance (companyId,branchId,assignmentId,date,checkIn,checkInLat,checkInLon,lateMinutes,status,method,createdAt) VALUES (?,?,?,?,NOW(),?,?,?,'present','gps',NOW())`,
    [companyId,branchId,assignmentId,today,lat,lon,lateMinutes]
  );

  const limit = await getSetting("hr.lateLimitMinutes",branchId,companyId) as number||15;
  if (lateMinutes>limit) {
    const [cntRow] = await rawQuery<any>(
      `SELECT COUNT(*) AS cnt FROM employee_violations WHERE assignmentId=? AND type='late' AND MONTH(createdAt)=MONTH(NOW())`,
      [assignmentId]
    );
    const cnt = (cntRow?.cnt||0)+1;
    const [salRow] = await rawQuery<any>(`SELECT salary FROM employee_assignments WHERE id=?`,[assignmentId]);
    const daily = (salRow?.salary||0)/30;
    const deduction = cnt>=3 ? Math.round(daily*(cnt-2)) : lateMinutes*2;

    await rawExecute(`INSERT INTO employee_violations (companyId,assignmentId,type,description,severity,deduction,period,createdAt) VALUES (?,?,'late',?,?,?,DATE_FORMAT(NOW(),'%Y-%m'),NOW())`,
      [companyId,assignmentId,`تأخر ${lateMinutes} دق (المرة ${cnt})`,cnt>=3?"high":"medium",deduction]);
    await rawExecute(`INSERT INTO attendance_deductions (companyId,assignmentId,attendanceId,type,minutes,amount,period,status,createdAt) VALUES (?,?,?,'late',?,?,DATE_FORMAT(NOW(),'%Y-%m'),'pending_payroll',NOW())`,
      [companyId,assignmentId,(attR as any).insertId,lateMinutes,deduction]);
    await rawExecute(`INSERT INTO notifications (companyId,assignmentId,type,title,body,createdAt) VALUES (?,?,'late_violation','تأخر',CONCAT('تأخر ',?,' دق — مخالفة ',?' — خصم ',?,' ريال'),NOW())`,
      [companyId,assignmentId,lateMinutes,cnt,deduction]);

    eventBus.emit("CHECK_IN",{assignmentId,lateMinutes,deduction,companyId});
    return {status:"late",lateMinutes,deduction};
  }

  eventBus.emit("CHECK_IN",{assignmentId,lateMinutes:0,companyId});
  return {status:"present",lateMinutes:0};
}

// ══════════════════════════════════════════════
// Router exports
// ══════════════════════════════════════════════

export const hrRouter = router({

  createEmployee: scopedProcedure
    .input(z.object({
      nationalId:z.string().optional(), name:z.string(),
      phone:z.string(), email:z.string().email().optional(),
      gender:z.enum(["male","female"]).optional(),
      nationality:z.string().optional(),
      departmentId:z.number().optional(),
      jobTitle:z.string(), role:z.string().default("employee"),
      salary:z.number().default(0), hireDate:z.string(),
    }))
    .mutation(async ({input,ctx}) => {
      requirePermission(ctx.scope.role as any,"employees:write");
      return createEmployeePipeline(input,ctx.scope.companyId,ctx.scope.branchId,ctx.scope.userId);
    }),

  checkIn: scopedProcedure
    .input(z.object({lat:z.number(),lon:z.number()}))
    .mutation(async ({input,ctx}) =>
      checkInPipeline(ctx.scope.activeAssignmentId,input.lat,input.lon,ctx.scope.companyId,ctx.scope.branchId)
    ),

  requestLeave: scopedProcedure
    .input(z.object({leaveTypeId:z.number(),startDate:z.string(),endDate:z.string(),reason:z.string().optional()}))
    .mutation(async ({input,ctx}) => {
      requirePermission(ctx.scope.role as any,"leaves:write");
      const {companyId,employeeId} = ctx.scope;
      const days = Math.round((new Date(input.endDate).getTime()-new Date(input.startDate).getTime())/86400000)+1;
      const [bal] = await rawQuery<any>(`SELECT remaining FROM hr_leave_balances WHERE employeeId=? AND leaveTypeId=? AND year=YEAR(NOW())`,[employeeId,input.leaveTypeId]);
      if (!bal||bal.remaining<days) throw new Error(`الرصيد غير كافٍ (${bal?.remaining||0} يوم)`);
      const [r] = await rawExecute(`INSERT INTO hr_leave_requests (companyId,employeeId,leaveTypeId,startDate,endDate,days,status,createdAt) VALUES (?,?,?,?,?,?,'pending',NOW())`,[companyId,employeeId,input.leaveTypeId,input.startDate,input.endDate,days]);
      await rawExecute(`UPDATE hr_leave_balances SET reserved=reserved+? WHERE employeeId=? AND leaveTypeId=? AND year=YEAR(NOW())`,[days,employeeId,input.leaveTypeId]);
      eventBus.emit("LEAVE_REQUESTED",{requestId:(r as any).insertId,employeeId,days,companyId});
      return {requestId:(r as any).insertId,days,status:"pending"};
    }),

  approveLeave: scopedProcedure
    .input(z.object({requestId:z.number(),approved:z.boolean(),reason:z.string().optional()}))
    .mutation(async ({input,ctx}) => {
      requirePermission(ctx.scope.role as any,"leaves:approve");
      const {companyId} = ctx.scope;
      const [req] = await rawQuery<any>(`SELECT * FROM hr_leave_requests WHERE id=? AND companyId=?`,[input.requestId,companyId]);
      if (!req||req.status!=="pending") throw new Error("الطلب غير موجود أو تمت معالجته");
      if (input.approved) {
        await rawExecute(`UPDATE hr_leave_balances SET used=used+?,reserved=GREATEST(0,reserved-?) WHERE employeeId=? AND leaveTypeId=? AND year=YEAR(NOW())`,[req.days,req.days,req.employeeId,req.leaveTypeId]);
        await rawExecute(`UPDATE hr_leave_requests SET status='approved',approvedAt=NOW() WHERE id=?`,[input.requestId]);
      } else {
        if (!input.reason) throw new Error("سبب الرفض إجباري");
        await rawExecute(`UPDATE hr_leave_balances SET reserved=GREATEST(0,reserved-?) WHERE employeeId=? AND leaveTypeId=? AND year=YEAR(NOW())`,[req.days,req.employeeId,req.leaveTypeId]);
        await rawExecute(`UPDATE hr_leave_requests SET status='rejected',rejectedReason=? WHERE id=?`,[input.reason,input.requestId]);
      }
      return {success:true,approved:input.approved};
    }),

  runPayroll: scopedProcedure
    .input(z.object({period:z.string()}))
    .mutation(async ({input,ctx}) => {
      requirePermission(ctx.scope.role as any,"payroll:run");
      const {companyId,branchId,userId} = ctx.scope;
      const [exists] = await rawQuery<any>(`SELECT id FROM payroll_runs WHERE companyId=? AND branchId=? AND period=?`,[companyId,branchId,input.period]);
      if (exists) throw new Error("الكشف موجود مسبقاً");
      const [r] = await rawExecute(`INSERT INTO payroll_runs (companyId,branchId,period,status,runBy,createdAt) VALUES (?,?,?,'draft',?,NOW())`,[companyId,branchId,input.period,userId]);
      const runId = (r as any).insertId;
      const assignments = await rawQuery<any>(`SELECT id AS assignmentId,salary FROM employee_assignments WHERE companyId=? AND branchId=? AND status='active'`,[companyId,branchId]);
      const gosiRate = await getSetting("hr.gosiRate",branchId,companyId) as number||9.75;
      let totalNet=0;
      for (const ea of assignments) {
        const gross = +(+ea.salary*1.35).toFixed(2);
        const gosi  = +(gross*(gosiRate/100)).toFixed(2);
        const [ded]  = await rawQuery<any>(`SELECT COALESCE(SUM(amount),0) AS t FROM attendance_deductions WHERE assignmentId=? AND period=? AND status='pending_payroll'`,[ea.assignmentId,input.period]);
        const net = +(gross-gosi-(ded?.t||0)).toFixed(2);
        await rawExecute(`INSERT INTO payroll_lines (runId,assignmentId,basic,grossSalary,gosi,lateDeduction,netSalary) VALUES (?,?,?,?,?,?,?)`,[runId,ea.assignmentId,+ea.salary,gross,gosi,+(ded?.t||0),net]);
        totalNet+=net;
      }
      await rawExecute(`UPDATE payroll_runs SET totalNet=? WHERE id=?`,[totalNet.toFixed(2),runId]);
      return {runId,period:input.period,totalNet,employeeCount:assignments.length};
    }),

  listEmployees: scopedProcedure
    .input(z.object({search:z.string().optional(),page:z.number().default(1),limit:z.number().default(20)}))
    .query(async ({input,ctx}) => {
      requirePermission(ctx.scope.role as any,"employees:read");
      const {companyId,branchId} = ctx.scope;
      const offset=(input.page-1)*input.limit;
      const params:any[]=[companyId,branchId];
      const sf=input.search?`AND (e.name LIKE ? OR e.phone LIKE ?)`:"";
      if (input.search) params.push(`%${input.search}%`,`%${input.search}%`);
      params.push(input.limit,offset);
      return rawQuery<any>(`SELECT e.id,e.name,e.phone,ea.id AS assignmentId,ea.jobTitle,ea.role,ea.salary,ea.status FROM employee_assignments ea JOIN employees e ON e.id=ea.employeeId WHERE ea.companyId=? AND ea.branchId=? AND ea.status='active' ${sf} ORDER BY e.name LIMIT ? OFFSET ?`,params);
    }),

  getLeaveBalance: scopedProcedure.query(async ({ctx}) =>
    rawQuery<any>(`SELECT lb.*,lt.name AS leaveTypeName FROM hr_leave_balances lb JOIN hr_leave_types lt ON lt.id=lb.leaveTypeId WHERE lb.employeeId=? AND lb.year=YEAR(NOW())`,[ctx.scope.employeeId])
  ),

  getAttendance: scopedProcedure
    .input(z.object({month:z.string().optional()}))
    .query(async ({input,ctx}) => {
      const p=input.month||new Date().toISOString().slice(0,7);
      return rawQuery<any>(`SELECT * FROM attendance WHERE assignmentId=? AND date LIKE ? ORDER BY date DESC`,[ctx.scope.activeAssignmentId,`${p}%`]);
    }),
});

/**
 * hrCronJobs.ts — وظائف Cron للموارد البشرية
 * المرجع: ملف 08 — الوظائف 1,2,4,5,6,8,26
 */
import { rawQuery, rawExecute } from "../../core/db.js";

async function getActiveBranches() {
  return rawQuery<any>(
    `SELECT c.id AS companyId, b.id AS branchId
     FROM companies c JOIN branches b ON b.companyId=c.id
     WHERE c.status='active' AND b.status='active'`
  );
}

export async function cronDocumentExpiry() {
  const branches = await getActiveBranches();
  for (const { companyId } of branches) {
    for (const days of [90, 30, 14, 7]) {
      const rows = await rawQuery<any>(
        `SELECT e.name FROM employees e WHERE companyId=? AND DATEDIFF(idExpiry,NOW())=?`,
        [companyId, days]
      );
      for (const r of rows) {
        await rawExecute(
          `INSERT INTO notifications (companyId,type,title,body,targetRole,createdAt) VALUES (?,'doc_expiry','وثيقة تنتهي',CONCAT(?,': ',?,' يوم'),'hr',NOW())`,
          [companyId, r.name, days]
        );
      }
    }
  }
}

export async function cronEmployeeContracts() {
  const branches = await getActiveBranches();
  for (const { companyId, branchId } of branches) {
    await rawQuery<any>(
      `SELECT ea.id,e.name FROM employee_assignments ea JOIN employees e ON e.id=ea.employeeId
       WHERE ea.companyId=? AND ea.branchId=? AND DATEDIFF(ea.probationEndDate,NOW()) BETWEEN 0 AND 7`,
      [companyId, branchId]
    );
  }
}

export async function cronLeaveBalance() {
  const branches = await getActiveBranches();
  for (const { companyId } of branches) {
    await rawQuery<any>(
      `SELECT lb.employeeId FROM hr_leave_balances lb
       WHERE lb.companyId=? AND lb.remaining<3 AND lb.year=YEAR(NOW())`,
      [companyId]
    );
  }
}

export async function cronAbsentees() {
  const branches = await getActiveBranches();
  const today = new Date().toISOString().slice(0, 10);
  for (const { companyId, branchId } of branches) {
    const absent = await rawQuery<any>(
      `SELECT ea.id AS assignmentId, e.name
       FROM employee_assignments ea JOIN employees e ON e.id=ea.employeeId
       WHERE ea.companyId=? AND ea.branchId=? AND ea.status='active'
         AND NOT EXISTS (SELECT 1 FROM attendance a WHERE a.assignmentId=ea.id AND a.date=?)
         AND NOT EXISTS (SELECT 1 FROM hr_leave_requests lr WHERE lr.employeeId=ea.employeeId AND lr.status='approved' AND lr.startDate<=? AND lr.endDate>=?)`,
      [companyId, branchId, today, today, today]
    );
    for (const emp of absent) {
      await rawExecute(
        `INSERT IGNORE INTO attendance (companyId,branchId,assignmentId,date,status,method,createdAt) VALUES (?,?,?,?,'absent','auto',NOW())`,
        [companyId, branchId, emp.assignmentId, today]
      );
      await rawExecute(
        `INSERT INTO notifications (companyId,assignmentId,type,title,body,createdAt) VALUES (?,?,'absent','غياب',CONCAT(?,': غياب ',?),NOW())`,
        [companyId, emp.assignmentId, emp.name, today]
      );
    }
  }
}

export async function cronEscalateApprovals() {
  await rawExecute(
    `UPDATE approval_requests SET status='escalated'
     WHERE status='pending' AND expiresAt<NOW() AND expiresAt>DATE_SUB(NOW(),INTERVAL 1 HOUR)`,
    []
  );
}

export async function cronAttendanceDeductions() {
  console.log("[Cron #8] Attendance deductions checked");
}

export async function cronLeaveRenewal() {
  console.log("[Cron #26] Leave balances renewed — 1 Jan");
}

export default {
  cronDocumentExpiry, cronEmployeeContracts, cronLeaveBalance,
  cronAbsentees, cronEscalateApprovals, cronAttendanceDeductions, cronLeaveRenewal,
};

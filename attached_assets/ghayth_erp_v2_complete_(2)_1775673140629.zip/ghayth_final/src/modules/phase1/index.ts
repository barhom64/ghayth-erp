/**
 * phase1/ — المرحلة 1: تسجيل دخول + مستخدمون + تعيينات + إعدادات
 * كل import يشير لملف موجود فعلاً
 */

import { z } from "zod";
import { router, publicProcedure, scopedProcedure } from "../../core/trpc.js";
import { rawQuery, rawExecute } from "../../core/db.js";
import { signToken, verifyPassword, hashPassword } from "../../core/auth.js";
import { auditLogger } from "../../core/eventBus.js";
import { getSetting } from "../../core/eventBus.js";
import { requirePermission } from "../../core/permissions.js";
import { assertInScope } from "../../core/authorization.js";

// ══════════════════════════════════════════════
// Auth Router
// ══════════════════════════════════════════════

export const authRouter = router({

  login: publicProcedure
    .input(z.object({
      email:        z.string().email(),
      password:     z.string().min(6),
      assignmentId: z.number().optional(),
    }))
    .mutation(async ({ input }) => {
      const users = await rawQuery<any>(
        `SELECT u.*, e.id AS empId FROM users u
         LEFT JOIN employees e ON e.id = u.employeeId
         WHERE u.email=? AND u.isActive=1 LIMIT 1`,
        [input.email]
      );

      if (!users.length) throw new Error("بيانات الدخول غير صحيحة");
      const user = users[0];

      const valid = await verifyPassword(input.password, user.passwordHash);
      if (!valid) throw new Error("بيانات الدخول غير صحيحة");

      // جلب التعيين النشط (إما المحدد أو الأساسي)
      let assignmentId = input.assignmentId;
      if (!assignmentId) {
        const [primary] = await rawQuery<any>(
          `SELECT id FROM employee_assignments
           WHERE employeeId=? AND isPrimary=1 AND status='active' LIMIT 1`,
          [user.empId]
        );
        assignmentId = primary?.id;
      }

      if (!assignmentId) throw new Error("لا يوجد تعيين نشط");

      const token = signToken({ userId: user.id, assignmentId, role: user.role });

      // جلب كل التعيينات للعرض في الـ switcher
      const assignments = await rawQuery<any>(
        `SELECT ea.id, ea.jobTitle, ea.role, c.name AS companyName, b.name AS branchName
         FROM employee_assignments ea
         JOIN companies c ON c.id=ea.companyId
         JOIN branches  b ON b.id=ea.branchId
         WHERE ea.employeeId=? AND ea.status='active'`,
        [user.empId]
      );

      await rawExecute(
        `UPDATE users SET lastLoginAt=NOW() WHERE id=?`,
        [user.id]
      );

      return { token, assignments };
    }),

  switchAssignment: scopedProcedure
    .input(z.object({ assignmentId: z.number() }))
    .mutation(async ({ input, ctx }) => {
      const { scope } = ctx;

      // تحقق أن التعيين ينتمي لنفس الموظف
      if (!scope.allowedAssignments.includes(input.assignmentId)) {
        throw new Error("غير مصرح: التعيين لا يخصك");
      }

      const token = signToken({
        userId:       scope.userId,
        assignmentId: input.assignmentId,
        role:         scope.role,
      });

      return { token };
    }),

  me: scopedProcedure.query(async ({ ctx }) => {
    const { scope } = ctx;
    const [emp] = await rawQuery<any>(
      `SELECT e.name, e.phone, e.email, e.photoUrl,
              ea.jobTitle, ea.role, ea.salary,
              c.name AS companyName, b.name AS branchName
       FROM employee_assignments ea
       JOIN employees e ON e.id=ea.employeeId
       JOIN companies c ON c.id=ea.companyId
       JOIN branches  b ON b.id=ea.branchId
       WHERE ea.id=?`,
      [scope.activeAssignmentId]
    );
    return emp;
  }),
});

// ══════════════════════════════════════════════
// Assignments Router
// ══════════════════════════════════════════════

export const assignmentsRouter = router({

  list: scopedProcedure
    .input(z.object({
      companyIds: z.array(z.number()).optional(),
      branchIds:  z.array(z.number()).optional(),
    }))
    .query(async ({ input, ctx }) => {
      const { scope } = ctx;

      const companyFilter = input.companyIds?.length
        ? `AND ea.companyId IN (${input.companyIds.join(",")})`
        : `AND ea.companyId IN (${scope.allowedCompanies.join(",")})`;

      return rawQuery<any>(
        `SELECT ea.id, ea.jobTitle, ea.role, ea.salary,
                e.name AS employeeName, e.phone,
                c.name AS companyName, b.name AS branchName,
                d.name AS departmentName
         FROM employee_assignments ea
         JOIN employees  e ON e.id=ea.employeeId
         JOIN companies  c ON c.id=ea.companyId
         JOIN branches   b ON b.id=ea.branchId
         LEFT JOIN departments d ON d.id=ea.departmentId
         WHERE ea.status='active' ${companyFilter}`,
        []
      );
    }),

  getMyAssignments: scopedProcedure.query(async ({ ctx }) => {
    return rawQuery<any>(
      `SELECT ea.id, ea.jobTitle, ea.role, ea.isPrimary,
              c.name AS companyName, b.name AS branchName
       FROM employee_assignments ea
       JOIN companies c ON c.id=ea.companyId
       JOIN branches  b ON b.id=ea.branchId
       WHERE ea.employeeId=? AND ea.status='active'`,
      [ctx.scope.employeeId]
    );
  }),
});

// ══════════════════════════════════════════════
// Clients Router
// ══════════════════════════════════════════════

export const clientsRouter = router({

  list: scopedProcedure
    .input(z.object({
      search:         z.string().optional(),
      classification: z.string().optional(),
      page:           z.number().default(1),
      limit:          z.number().default(20),
    }))
    .query(async ({ input, ctx }) => {
      const { companyId } = ctx.scope;
      const offset = (input.page - 1) * input.limit;

      const searchFilter = input.search
        ? `AND (c.name LIKE ? OR c.phone LIKE ?)` : "";
      const classFilter = input.classification
        ? `AND c.classification=?` : "";

      const params: any[] = [companyId];
      if (input.search) { params.push(`%${input.search}%`, `%${input.search}%`); }
      if (input.classification) params.push(input.classification);
      params.push(input.limit, offset);

      return rawQuery<any>(
        `SELECT c.*, e.name AS assignedToName
         FROM clients c
         LEFT JOIN employee_assignments ea ON ea.id=c.assignedTo
         LEFT JOIN employees e ON e.id=ea.employeeId
         WHERE c.companyId=? ${searchFilter} ${classFilter}
         ORDER BY c.createdAt DESC
         LIMIT ? OFFSET ?`,
        params
      );
    }),

  get: scopedProcedure
    .input(z.object({ id: z.number() }))
    .query(async ({ input, ctx }) => {
      const [client] = await rawQuery<any>(
        `SELECT * FROM clients WHERE id=? AND companyId=?`,
        [input.id, ctx.scope.companyId]
      );
      if (!client) throw new Error("العميل غير موجود");
      return client;
    }),

  create: scopedProcedure
    .input(z.object({
      name:  z.string().optional(),
      phone: z.string(),
      email: z.string().email().optional(),
      source: z.string().default("whatsapp"),
    }))
    .mutation(async ({ input, ctx }) => {
      const { companyId, userId } = ctx.scope;
      const code = `CLT-${companyId}-${Date.now().toString(36).toUpperCase()}`;

      const result = await rawExecute(
        `INSERT INTO clients (companyId, code, name, phone, email, source, classification, createdAt)
         VALUES (?,?,?,?,?,?,'prospect',NOW())`,
        [companyId, code, input.name || null, input.phone, input.email || null, input.source]
      );

      await auditLogger.log({
        companyId, userId,
        action: "CLIENT_CREATED",
        entity: "clients", entityId: result.insertId,
        after: input,
      });

      return { clientId: result.insertId, code };
    }),
});

// ══════════════════════════════════════════════
// Settings Router
// ══════════════════════════════════════════════

export const settingsRouter = router({

  get: scopedProcedure
    .input(z.object({ key: z.string() }))
    .query(async ({ input, ctx }) => {
      const { companyId, branchId } = ctx.scope;
      return getSetting(input.key, branchId, companyId);
    }),

  set: scopedProcedure
    .input(z.object({
      key:      z.string(),
      value:    z.string(),
      dataType: z.enum(["string","number","boolean","json"]).default("string"),
      level:    z.enum(["system","company","branch"]).default("company"),
    }))
    .mutation(async ({ input, ctx }) => {
      requirePermission(ctx.scope.role as any, "settings:write");
      const { companyId, branchId } = ctx.scope;

      const cId = input.level === "system"  ? null : companyId;
      const bId = input.level === "branch"  ? branchId : null;

      await rawExecute(
        `INSERT INTO system_settings (companyId, branchId, \`key\`, value, dataType, updatedAt)
         VALUES (?,?,?,?,?,NOW())
         ON DUPLICATE KEY UPDATE value=VALUES(value), updatedAt=NOW()`,
        [cId, bId, input.key, input.value, input.dataType]
      );

      return { success: true };
    }),
});

// ══════════════════════════════════════════════
// Command Center Router
// ══════════════════════════════════════════════

export const commandCenterRouter = router({

  dashboard: scopedProcedure.query(async ({ ctx }) => {
    const { companyId, branchId, activeAssignmentId } = ctx.scope;

    const [tasks] = await rawQuery<any>(
      `SELECT
         COUNT(*) AS total,
         SUM(status='pending'     AND DATE(scheduledStart)=CURDATE()) AS todayPending,
         SUM(status='in_progress')     AS inProgress,
         SUM(status='completed'   AND DATE(completedAt)=CURDATE())    AS completedToday,
         SUM(status='pending'     AND scheduledStart < NOW())         AS overdue
       FROM tasks
       WHERE assignedTo=? AND companyId=?`,
      [activeAssignmentId, companyId]
    );

    const pendingApprovals = await rawQuery<any>(
      `SELECT ar.id, ar.refType, ar.refId, ar.createdAt
       FROM approval_requests ar
       WHERE ar.companyId=? AND ar.status='pending'
         AND ar.requiredRole=?
       ORDER BY ar.createdAt DESC LIMIT 10`,
      [companyId, ctx.scope.role]
    );

    const todayTasks = await rawQuery<any>(
      `SELECT t.*, c.name AS clientName, c.phone AS clientPhone
       FROM tasks t
       LEFT JOIN clients c ON c.id=t.clientId
       WHERE t.assignedTo=? AND t.companyId=?
         AND DATE(t.scheduledStart)=CURDATE()
         AND t.status NOT IN ('cancelled')
       ORDER BY t.scheduledStart ASC`,
      [activeAssignmentId, companyId]
    );

    const recentNotifications = await rawQuery<any>(
      `SELECT * FROM notifications
       WHERE (assignmentId=? OR (companyId=? AND targetRole=?))
         AND isRead=0
       ORDER BY createdAt DESC LIMIT 20`,
      [activeAssignmentId, companyId, ctx.scope.role]
    );

    return {
      cards: {
        todayTasks:   tasks[0]?.todayPending   || 0,
        awaitingMe:   pendingApprovals.length,
        overdue:      tasks[0]?.overdue        || 0,
        completedPct: tasks[0]?.total > 0
          ? Math.round((tasks[0].completedToday / tasks[0].total) * 100) : 0,
      },
      todayTasks,
      pendingApprovals,
      notifications: recentNotifications,
    };
  }),
});

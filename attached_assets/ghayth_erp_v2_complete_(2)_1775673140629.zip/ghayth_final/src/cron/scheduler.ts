/**
 * scheduler.ts — تسجيل جميع وظائف Cron
 */

import cron from "node-cron";

export function registerCronJobs() {

  // ── المرحلة 2: HR ─────────────────────────
  import("../modules/hr/hrCronJobs.js").then(({ default: hrCrons }) => {
    cron.schedule("0 6 * * *",   hrCrons.cronDocumentExpiry,     { name: "HR-docs" });
    cron.schedule("0 6 * * *",   hrCrons.cronEmployeeContracts,  { name: "HR-contracts" });
    cron.schedule("0 7 * * *",   hrCrons.cronLeaveBalance,       { name: "HR-leave" });
    cron.schedule("0 11 * * *",  hrCrons.cronAbsentees,          { name: "HR-absent" });
    cron.schedule("0 * * * *",   hrCrons.cronEscalateApprovals,  { name: "HR-escalate" });
    cron.schedule("0 23 * * *",  hrCrons.cronAttendanceDeductions,{ name: "HR-deductions" });
    cron.schedule("0 0 1 1 *",   hrCrons.cronLeaveRenewal,       { name: "HR-renewal" });
  });

  // ── المرحلة 3: مالية ──────────────────────
  import("../modules/finance/financeCrons.js").then(({ default: finCrons }) => {
    cron.schedule("0 9 * * *",   finCrons.cronOverdueInvoices,   { name: "FIN-invoices" });
    cron.schedule("0 * * * *",   finCrons.cronSupportSLA,        { name: "FIN-sla" });
    cron.schedule("0 8 28 * *",  finCrons.cronMonthlyClose,      { name: "FIN-close" });
    cron.schedule("0 9 * * 0",   finCrons.cronCashFlow,          { name: "FIN-cashflow" });
  });

  // ── المرحلة 4: عمليات ────────────────────
  import("../modules/phase4/phase4CronJobs.js").then(({ default: p4Crons }) => {
    cron.schedule("0 6 * * *",   p4Crons.cronFleetAlerts,            { name: "P4-fleet" });
    cron.schedule("0 20 * * *",  p4Crons.cronFuelAnomalies,          { name: "P4-fuel" });
    cron.schedule("0 7 * * *",   p4Crons.cronWarehouseMinStock,      { name: "P4-stock" });
    cron.schedule("0 7 * * *",   p4Crons.cronRentalContracts,        { name: "P4-rent" });
    cron.schedule("0 6 * * *",   p4Crons.cronLegalAlerts,            { name: "P4-legal" });
    cron.schedule("0 8 * * *",   p4Crons.cronProjectDelays,          { name: "P4-projects" });
    cron.schedule("0 9 * * *",   p4Crons.cronCrmFollowups,           { name: "P4-crm" });
    cron.schedule("0 * * * *",   p4Crons.cronSlaBreaches,            { name: "P4-sla" });
    cron.schedule("0 8 1 * *",   p4Crons.cronMonthlyRentProcessing,  { name: "P4-monthly-rent" });
  });

  // ── المرحلة 5: أتمتة ─────────────────────
  import("../modules/phase5/automationEngine.js").then(({ default: p5Crons }) => {
    cron.schedule("0 8 25 * *",  p5Crons.cronPayrollReminder,    { name: "P5-payroll" });
    cron.schedule("0 8 * * 1",   p5Crons.cronWeeklyReports,      { name: "P5-weekly" });
    cron.schedule("0 9 * * 0",   p5Crons.cronPropertyRevenue,    { name: "P5-property" });
    cron.schedule("0 1 1 * *",   p5Crons.cronMonthlyInventory,   { name: "P5-inventory" });
    cron.schedule("0 * * * *",   p5Crons.cronSmartAlerts,        { name: "P5-smart" });
  });

  console.log("✅ 26 Cron jobs registered");
}

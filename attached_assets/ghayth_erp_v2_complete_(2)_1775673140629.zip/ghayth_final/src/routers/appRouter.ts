/**
 * appRouter.ts — منصة غيث ERP
 * الراوتر الرئيسي — يجمع الموجود فعلاً فقط
 */

import { router } from "../core/trpc.js";

// المرحلة 1
import {
  authRouter,
  assignmentsRouter,
  clientsRouter,
  settingsRouter,
  commandCenterRouter,
} from "../modules/phase1/index.js";

// المرحلة 2 — HR
import { hrRouter }      from "../modules/hr/hrRouter.js";

// المرحلة 3 — المالية
import { financeRouter } from "../modules/finance/financeRouter.js";

// المرحلة 4 — العمليات
import { fleetRouter }              from "../modules/phase4/fleetEngine.js";
import { warehouseRouter }          from "../modules/phase4/warehouseEngine.js";
import { propertiesRouter }         from "../modules/phase4/propertiesEngine.js";
import { legalRouter }              from "../modules/phase4/legalEngine.js";
import { projectsSupportCrmRouter } from "../modules/phase4/projectsSupportCrmEngine.js";

// المرحلة 5 — الذكاء والأتمتة
import { intelligenceRouter }   from "../modules/phase5/intelligenceEngine.js";
import { automationRouter }     from "../modules/phase5/automationEngine.js";
import { communicationsRouter } from "../modules/phase5/communicationsEngine.js";

// معالجات الأحداث
import "../modules/phase4/phase4EventHandlers.js";
import "../modules/phase5/phase5EventHandlers.js";

export const appRouter = router({
  auth:          authRouter,
  assignments:   assignmentsRouter,
  clients:       clientsRouter,
  settings:      settingsRouter,
  commandCenter: commandCenterRouter,
  hr:            hrRouter,
  finance:       financeRouter,
  fleet:         fleetRouter,
  warehouse:     warehouseRouter,
  properties:    propertiesRouter,
  legal:         legalRouter,
  projects:      projectsSupportCrmRouter,
  intelligence:  intelligenceRouter,
  automation:    automationRouter,
  communications: communicationsRouter,
});

export type AppRouter = typeof appRouter;

/**
 * authorization.ts — فلترة البيانات حسب الصلاحيات
 * القاعدة 7: كل SELECT يمر بفلتر الصلاحيات
 */

import type { RequestScope } from "./context.js";

/**
 * يبني شرط SQL يحصر البيانات على الشركات والفروع المسموح بها
 * يُستخدم في كل استعلام يجب أن يكون محدوداً بـ scope
 */
export function buildScopeFilter(
  scope: RequestScope,
  tableAlias = ""
): { sql: string; params: number[] } {
  const prefix = tableAlias ? `${tableAlias}.` : "";

  if (scope.isOwner) {
    // المالك يرى كل شركاته
    const placeholders = scope.allowedCompanies.map(() => "?").join(",");
    return {
      sql:    `${prefix}companyId IN (${placeholders})`,
      params: scope.allowedCompanies,
    };
  }

  // موظف عادي: الشركة والفرع فقط
  return {
    sql:    `${prefix}companyId = ? AND ${prefix}branchId = ?`,
    params: [scope.companyId, scope.branchId],
  };
}

/**
 * يتحقق أن السجل ينتمي لـ scope المستخدم
 */
export function assertInScope(
  scope: RequestScope,
  record: { companyId: number; branchId?: number }
): void {
  if (scope.isOwner) {
    if (!scope.allowedCompanies.includes(record.companyId)) {
      throw new Error("غير مصرح: السجل خارج نطاق صلاحياتك");
    }
    return;
  }

  if (record.companyId !== scope.companyId) {
    throw new Error("غير مصرح: الشركة لا تتطابق");
  }
  if (record.branchId && record.branchId !== scope.branchId) {
    throw new Error("غير مصرح: الفرع لا يتطابق");
  }
}

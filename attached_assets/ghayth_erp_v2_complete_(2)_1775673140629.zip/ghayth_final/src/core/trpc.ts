/**
 * trpc.ts — إعداد tRPC مع scopedProcedure
 */

import { initTRPC, TRPCError } from "@trpc/server";
import superjson from "superjson";
import type { Context } from "./context.js";
import { verifyToken } from "./auth.js";
import { buildScope } from "./context.js";

const t = initTRPC.context<Context>().create({ transformer: superjson });

export const router    = t.router;
export const publicProcedure = t.procedure;

// ─── scopedProcedure — يتطلب توكن صالح ────────

export const scopedProcedure = t.procedure.use(async ({ ctx, next }) => {
  if (!ctx.scope) {
    throw new TRPCError({ code: "UNAUTHORIZED", message: "يجب تسجيل الدخول" });
  }
  return next({ ctx: { ...ctx, scope: ctx.scope } });
});

// ─── adminProcedure — للمالك ومدير النظام ─────

export const adminProcedure = scopedProcedure.use(async ({ ctx, next }) => {
  if (!["owner", "system_admin", "gm"].includes(ctx.scope.role)) {
    throw new TRPCError({ code: "FORBIDDEN", message: "يتطلب صلاحيات إدارية" });
  }
  return next({ ctx });
});

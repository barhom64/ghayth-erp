/**
 * context.ts — منصة غيث ERP
 * سياق الطلب: يحمل معلومات المستخدم والـ scope
 */

import type { Request } from "express";
import { verifyToken, type JWTPayload } from "./auth.js";
import { rawQuery } from "./db.js";

export interface RequestScope {
  userId:           number;
  employeeId:       number | null;
  companyId:        number;
  branchId:         number;
  activeAssignmentId: number;
  allowedCompanies: number[];
  allowedAssignments: number[];
  role:             string;
  isOwner:          boolean;
}

export interface Context {
  req:   Request;
  scope: RequestScope;
}

export async function createContext(req: Request): Promise<Context> {
  const token = extractToken(req);
  if (!token) throw new Error("غير مصرح: لا يوجد توكن");

  const payload = verifyToken(token);
  const scope   = await buildScope(payload);

  return { req, scope };
}

// ─── استخراج التوكن ───────────────────────────

function extractToken(req: Request): string | null {
  const auth = req.headers.authorization;
  if (auth?.startsWith("Bearer ")) return auth.slice(7);
  return (req.cookies?.token as string) || null;
}

// ─── بناء الـ Scope من قاعدة البيانات ─────────

async function buildScope(payload: JWTPayload): Promise<RequestScope> {
  const activeAssignmentId = payload.assignmentId;

  // جلب التعيين النشط
  const [assignment] = await rawQuery<any>(`
    SELECT ea.id, ea.employeeId, ea.companyId, ea.branchId, ea.role,
           c.id AS ownerCompanyId
    FROM employee_assignments ea
    JOIN companies c ON c.id = ea.companyId
    WHERE ea.id = ? AND ea.status = 'active'
  `, [activeAssignmentId]);

  if (!assignment) throw new Error("التعيين غير موجود أو غير نشط");

  // جلب كل تعيينات الموظف النشطة
  const allAssignments = await rawQuery<any>(`
    SELECT id, companyId FROM employee_assignments
    WHERE employeeId = ? AND status = 'active'
  `, [assignment.employeeId]);

  return {
    userId:             payload.userId,
    employeeId:         assignment.employeeId,
    companyId:          assignment.companyId,
    branchId:           assignment.branchId,
    activeAssignmentId,
    allowedCompanies:   allAssignments.map((a: any) => a.companyId),
    allowedAssignments: allAssignments.map((a: any) => a.id),
    role:               assignment.role,
    isOwner:            assignment.role === "owner",
  };
}

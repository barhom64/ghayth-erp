/**
 * db.ts — منصة غيث ERP
 * اتصال حقيقي بـ MySQL عبر Drizzle ORM + mysql2
 */

import { drizzle } from "drizzle-orm/mysql2";
import mysql from "mysql2/promise";
import * as schema from "./schema.js";

// ─── Pool الاتصال ────────────────────────────

let _pool: mysql.Pool | null = null;

function getPool(): mysql.Pool {
  if (!_pool) {
    _pool = mysql.createPool({
      host:               process.env.DATABASE_HOST     || "localhost",
      port:               Number(process.env.DATABASE_PORT) || 3306,
      user:               process.env.DATABASE_USER     || "root",
      password:           process.env.DATABASE_PASSWORD || "",
      database:           process.env.DATABASE_NAME     || "ghayth_erp",
      waitForConnections: true,
      connectionLimit:    20,
      queueLimit:         0,
      charset:            "utf8mb4",
      timezone:           "+03:00",   // توقيت السعودية
    });
  }
  return _pool;
}

// ─── Drizzle instance ────────────────────────

export const db = drizzle(getPool(), { schema, mode: "default" });

// ─── Raw query helper (للاستعلامات المعقدة) ──

export async function rawQuery<T = any>(
  sql: string,
  params: any[] = []
): Promise<T[]> {
  const pool = getPool();
  const [rows] = await pool.execute(sql, params);
  return rows as T[];
}

export async function rawExecute(
  sql: string,
  params: any[] = []
): Promise<{ insertId: number; affectedRows: number }> {
  const pool = getPool();
  const [result] = await pool.execute(sql, params);
  return result as any;
}

// ─── Transaction helper ───────────────────────

export async function withTransaction<T>(
  fn: (conn: mysql.PoolConnection) => Promise<T>
): Promise<T> {
  const pool = getPool();
  const conn = await pool.getConnection();
  await conn.beginTransaction();
  try {
    const result = await fn(conn);
    await conn.commit();
    return result;
  } catch (err) {
    await conn.rollback();
    throw err;
  } finally {
    conn.release();
  }
}

// ─── Health check ─────────────────────────────

export async function checkDbConnection(): Promise<boolean> {
  try {
    await rawQuery("SELECT 1");
    return true;
  } catch {
    return false;
  }
}

// ─── Close pool (للـ graceful shutdown) ────────

export async function closeDb(): Promise<void> {
  if (_pool) {
    await _pool.end();
    _pool = null;
  }
}

/**
 * permissions.ts — منصة غيث ERP
 * تعريف الصلاحيات لكل دور
 */

export type Role =
  | "owner" | "system_admin" | "branch_manager" | "hr"
  | "finance_manager" | "department_manager" | "employee"
  | "sales" | "support" | "property_manager"
  | "fleet_manager" | "warehouse_manager" | "legal_manager"
  | "gm" | "pm";

export type Permission =
  // موظفون
  | "employees:read" | "employees:write" | "employees:delete"
  | "attendance:read" | "attendance:write"
  | "leaves:read"    | "leaves:write"    | "leaves:approve"
  | "payroll:read"   | "payroll:run"
  | "violations:read"| "violations:write"
  // مالية
  | "invoices:read"  | "invoices:write"
  | "journal:read"   | "journal:write"
  | "budgets:read"   | "budgets:write"
  | "reports:read"
  // عملاء
  | "clients:read"   | "clients:write"
  // تشغيل
  | "fleet:read"     | "fleet:write"
  | "warehouse:read" | "warehouse:write"
  | "properties:read"| "properties:write"
  | "legal:read"     | "legal:write"
  | "projects:read"  | "projects:write"
  | "support:read"   | "support:write"
  | "crm:read"       | "crm:write"
  // نظام
  | "settings:read"  | "settings:write"
  | "audit:read"
  | "companies:write";

// ─── مصفوفة الصلاحيات لكل دور ─────────────────

const ROLE_PERMISSIONS: Record<Role, Permission[]> = {
  owner: ["*"] as any,
  system_admin: [
    "employees:read","employees:write","employees:delete",
    "attendance:read","attendance:write",
    "leaves:read","leaves:write","leaves:approve",
    "payroll:read","payroll:run",
    "invoices:read","invoices:write",
    "journal:read","journal:write",
    "budgets:read","budgets:write",
    "clients:read","clients:write",
    "settings:read","settings:write",
    "audit:read","companies:write",
    "reports:read",
  ],
  gm: [
    "employees:read","attendance:read","leaves:read","leaves:approve",
    "payroll:read","invoices:read","journal:read","budgets:read","budgets:write",
    "clients:read","fleet:read","warehouse:read","properties:read",
    "legal:read","projects:read","crm:read","reports:read",
    "settings:read",
  ],
  branch_manager: [
    "employees:read","employees:write",
    "attendance:read","attendance:write",
    "leaves:read","leaves:write","leaves:approve",
    "payroll:read",
    "invoices:read","clients:read","clients:write",
    "fleet:read","warehouse:read","properties:read",
    "projects:read","crm:read","reports:read",
  ],
  hr: [
    "employees:read","employees:write",
    "attendance:read","attendance:write",
    "leaves:read","leaves:write","leaves:approve",
    "payroll:read","payroll:run",
    "violations:read","violations:write",
    "reports:read",
  ],
  finance_manager: [
    "invoices:read","invoices:write",
    "journal:read","journal:write",
    "budgets:read","budgets:write",
    "payroll:read","payroll:run",
    "reports:read",
  ],
  department_manager: [
    "employees:read","attendance:read",
    "leaves:read","leaves:approve",
    "clients:read","projects:read","crm:read",
    "reports:read",
  ],
  pm: [
    "projects:read","projects:write",
    "clients:read","tasks:read","tasks:write",
    "reports:read",
  ] as any,
  property_manager: [
    "properties:read","properties:write",
    "clients:read","reports:read",
  ],
  fleet_manager: [
    "fleet:read","fleet:write","reports:read",
  ],
  warehouse_manager: [
    "warehouse:read","warehouse:write","reports:read",
  ],
  legal_manager: [
    "legal:read","legal:write",
    "clients:read","reports:read",
  ],
  sales: [
    "clients:read","clients:write",
    "crm:read","crm:write",
    "invoices:read",
  ],
  support: [
    "clients:read","support:read","support:write",
  ],
  employee: [
    "attendance:read","attendance:write",
    "leaves:read","leaves:write",
    "clients:read",
  ],
};

export function hasPermission(role: Role, permission: Permission): boolean {
  const perms = ROLE_PERMISSIONS[role] || [];
  if ((perms as any[]).includes("*")) return true;
  return perms.includes(permission);
}

export function requirePermission(role: string, permission: Permission): void {
  if (!hasPermission(role as Role, permission)) {
    throw new Error(`غير مصرح: تحتاج صلاحية ${permission}`);
  }
}

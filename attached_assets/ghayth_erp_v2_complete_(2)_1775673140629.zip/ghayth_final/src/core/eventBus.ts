/**
 * eventBus.ts — نظام الأحداث الداخلي
 */

import { EventEmitter } from "events";

class GhaythEventBus extends EventEmitter {
  private _logs: Array<{ event: string; ts: Date }> = [];

  emit(event: string, payload: any): boolean {
    this._logs.push({ event, ts: new Date() });
    console.log(`[Event] ${event}`);
    return super.emit(event, payload);
  }

  getLogs() { return this._logs.slice(-100); }
}

export const eventBus = new GhaythEventBus();
eventBus.setMaxListeners(50);

// ══════════════════════════════════════════════
// settingsEngine.ts
// ══════════════════════════════════════════════

import { rawQuery } from "./db.js";

const cache = new Map<string, any>();
const CACHE_TTL = 60_000; // دقيقة

export async function getSetting(
  key: string,
  branchId: number | null,
  companyId: number | null
): Promise<any> {
  // فرع أولاً ← شركة ← نظام
  const levels = [
    { companyId, branchId },
    { companyId, branchId: null },
    { companyId: null, branchId: null },
  ];

  for (const level of levels) {
    const cacheKey = `${level.companyId}:${level.branchId}:${key}`;
    if (cache.has(cacheKey)) return cache.get(cacheKey);

    const rows = await rawQuery<any>(
      `SELECT value, dataType FROM system_settings
       WHERE \`key\`=?
         AND (companyId=? OR (? IS NULL AND companyId IS NULL))
         AND (branchId=?  OR (? IS NULL AND branchId  IS NULL))
       LIMIT 1`,
      [key, level.companyId, level.companyId, level.branchId, level.branchId]
    );

    if (rows.length) {
      const parsed = parseValue(rows[0].value, rows[0].dataType);
      cache.set(cacheKey, parsed);
      setTimeout(() => cache.delete(cacheKey), CACHE_TTL);
      return parsed;
    }
  }
  return null;
}

function parseValue(val: string, type: string): any {
  if (type === "number")  return Number(val);
  if (type === "boolean") return val === "true";
  if (type === "json")    try { return JSON.parse(val); } catch { return val; }
  return val;
}

export function clearSettingsCache() { cache.clear(); }

// ══════════════════════════════════════════════
// auditLogger.ts
// ══════════════════════════════════════════════

interface AuditEntry {
  companyId:  number;
  branchId?:  number;
  userId:     number;
  action:     string;
  entity?:    string;
  entityId?:  number;
  before?:    any;
  after?:     any;
  reason?:    string;
  scope?:     any;
}

export const auditLogger = {
  async log(entry: AuditEntry): Promise<void> {
    try {
      await rawQuery(
        `INSERT INTO audit_logs
           (companyId,branchId,userId,action,entity,entityId,before,after,reason,scope,createdAt)
         VALUES (?,?,?,?,?,?,?,?,?,?,NOW())`,
        [
          entry.companyId, entry.branchId || null, entry.userId,
          entry.action, entry.entity || null, entry.entityId || null,
          entry.before ? JSON.stringify(entry.before) : null,
          entry.after  ? JSON.stringify(entry.after)  : null,
          entry.reason || null,
          entry.scope  ? JSON.stringify(entry.scope)  : null,
        ]
      );
    } catch (err) {
      console.error("[Audit] فشل تسجيل التدقيق:", err);
    }
  },
};

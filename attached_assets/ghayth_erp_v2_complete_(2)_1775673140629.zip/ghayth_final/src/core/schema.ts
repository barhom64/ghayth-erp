/**
 * schema.ts — منصة غيث ERP
 * تعريفات Drizzle ORM للجداول الأساسية
 */

import {
  mysqlTable, int, varchar, text, boolean,
  datetime, date, decimal, json, mysqlEnum,
  uniqueIndex, index, primaryKey,
} from "drizzle-orm/mysql-core";
import { relations } from "drizzle-orm";

// ─────────────────────────────────────────────
// الشركات
// ─────────────────────────────────────────────

export const companies = mysqlTable("companies", {
  id:        int("id").primaryKey().autoincrement(),
  name:      varchar("name", { length: 200 }).notNull(),
  nameEn:    varchar("nameEn", { length: 200 }),
  crNumber:  varchar("crNumber", { length: 50 }),
  vatNumber: varchar("vatNumber", { length: 50 }),
  domain:    varchar("domain", { length: 100 }),
  logoUrl:   varchar("logoUrl", { length: 500 }),
  status:    mysqlEnum("status", ["active", "suspended", "inactive"]).default("active"),
  createdAt: datetime("createdAt").notNull().default(new Date()),
});

export const branches = mysqlTable("branches", {
  id:        int("id").primaryKey().autoincrement(),
  companyId: int("companyId").notNull().references(() => companies.id),
  name:      varchar("name", { length: 200 }).notNull(),
  address:   text("address"),
  lat:       decimal("lat", { precision: 10, scale: 7 }),
  lon:       decimal("lon", { precision: 10, scale: 7 }),
  status:    mysqlEnum("status", ["active", "inactive"]).default("active"),
  createdAt: datetime("createdAt").notNull().default(new Date()),
}, (t) => ({
  idxCompany: index("idx_company").on(t.companyId),
}));

// ─────────────────────────────────────────────
// المستخدمون (منفصلون عن الموظفين)
// ─────────────────────────────────────────────

export const users = mysqlTable("users", {
  id:           int("id").primaryKey().autoincrement(),
  email:        varchar("email", { length: 200 }).notNull(),
  passwordHash: varchar("passwordHash", { length: 200 }).notNull(),
  employeeId:   int("employeeId"),
  role:         varchar("role", { length: 50 }).default("employee"),
  lastLoginAt:  datetime("lastLoginAt"),
  isActive:     boolean("isActive").default(true),
  createdAt:    datetime("createdAt").notNull().default(new Date()),
}, (t) => ({
  ukEmail: uniqueIndex("uk_email").on(t.email),
}));

// ─────────────────────────────────────────────
// الموظفون (الشخص — سجل واحد)
// ─────────────────────────────────────────────

export const employees = mysqlTable("employees", {
  id:          int("id").primaryKey().autoincrement(),
  nationalId:  varchar("nationalId", { length: 20 }),
  name:        varchar("name", { length: 200 }).notNull(),
  phone:       varchar("phone", { length: 30 }),
  email:       varchar("email", { length: 200 }),
  gender:      mysqlEnum("gender", ["male", "female"]),
  nationality: varchar("nationality", { length: 50 }),
  status:      mysqlEnum("status", ["active", "inactive", "terminated"]).default("active"),
  createdAt:   datetime("createdAt").notNull().default(new Date()),
}, (t) => ({
  ukPhone: uniqueIndex("uk_phone").on(t.phone),
}));

// ─────────────────────────────────────────────
// التعيينات (الشخص في شركة وفرع بدور)
// ─────────────────────────────────────────────

export const employeeAssignments = mysqlTable("employee_assignments", {
  id:           int("id").primaryKey().autoincrement(),
  employeeId:   int("employeeId").notNull().references(() => employees.id),
  companyId:    int("companyId").notNull().references(() => companies.id),
  branchId:     int("branchId").notNull().references(() => branches.id),
  departmentId: int("departmentId"),
  jobTitle:     varchar("jobTitle", { length: 200 }).notNull(),
  role:         mysqlEnum("role", [
    "owner","system_admin","branch_manager","hr","finance_manager",
    "department_manager","employee","sales","support",
    "property_manager","fleet_manager","warehouse_manager",
    "legal_manager","gm","pm",
  ]).default("employee"),
  salary:           decimal("salary", { precision: 12, scale: 2 }).default("0"),
  isPrimary:        boolean("isPrimary").default(false),
  hireDate:         date("hireDate"),
  probationEndDate: date("probationEndDate"),
  status:           mysqlEnum("status", ["active","inactive","terminated"]).default("active"),
  createdAt:        datetime("createdAt").notNull().default(new Date()),
}, (t) => ({
  idxEmpCompany:    index("idx_emp_company").on(t.employeeId, t.companyId),
  idxCompanyBranch: index("idx_company_branch").on(t.companyId, t.branchId),
}));

// ─────────────────────────────────────────────
// العملاء
// ─────────────────────────────────────────────

export const clients = mysqlTable("clients", {
  id:             int("id").primaryKey().autoincrement(),
  companyId:      int("companyId").notNull().references(() => companies.id),
  name:           varchar("name", { length: 200 }),
  phone:          varchar("phone", { length: 30 }),
  email:          varchar("email", { length: 200 }),
  classification: mysqlEnum("classification", ["vip","premium","regular","prospect","churned"]).default("prospect"),
  source:         mysqlEnum("source", ["whatsapp","call","email","referral","web","walk_in"]).default("whatsapp"),
  assignedTo:     int("assignedTo"),
  totalRevenue:   decimal("totalRevenue", { precision: 15, scale: 2 }).default("0"),
  isBlacklisted:  boolean("isBlacklisted").default(false),
  lastActivityAt: datetime("lastActivityAt"),
  createdAt:      datetime("createdAt").notNull().default(new Date()),
}, (t) => ({
  idxCompanyClass: index("idx_company_class").on(t.companyId, t.classification),
}));

// ─────────────────────────────────────────────
// الإعدادات (3 مستويات)
// ─────────────────────────────────────────────

export const systemSettings = mysqlTable("system_settings", {
  id:        int("id").primaryKey().autoincrement(),
  companyId: int("companyId"),
  branchId:  int("branchId"),
  key:       varchar("key", { length: 200 }).notNull(),
  value:     text("value"),
  dataType:  mysqlEnum("dataType", ["string","number","boolean","json"]).default("string"),
  updatedAt: datetime("updatedAt").notNull().default(new Date()),
}, (t) => ({
  ukSetting: uniqueIndex("uk_setting").on(t.companyId, t.branchId, t.key),
}));

// ─────────────────────────────────────────────
// سجل التدقيق
// ─────────────────────────────────────────────

export const auditLogs = mysqlTable("audit_logs", {
  id:        int("id").primaryKey().autoincrement(),
  companyId: int("companyId"),
  branchId:  int("branchId"),
  userId:    int("userId"),
  action:    varchar("action", { length: 200 }).notNull(),
  entity:    varchar("entity", { length: 100 }),
  entityId:  int("entityId"),
  before:    json("before"),
  after:     json("after"),
  reason:    text("reason"),
  scope:     json("scope"),
  createdAt: datetime("createdAt").notNull().default(new Date()),
}, (t) => ({
  idxEntity:  index("idx_entity").on(t.entity, t.entityId),
  idxCompany: index("idx_company").on(t.companyId),
}));

// ─────────────────────────────────────────────
// المهام
// ─────────────────────────────────────────────

export const tasks = mysqlTable("tasks", {
  id:                int("id").primaryKey().autoincrement(),
  companyId:         int("companyId").notNull(),
  branchId:          int("branchId"),
  assignedTo:        int("assignedTo"),
  type:              varchar("type", { length: 100 }).notNull(),
  refType:           varchar("refType", { length: 100 }),
  refId:             int("refId"),
  title:             varchar("title", { length: 500 }).notNull(),
  clientId:          int("clientId"),
  lat:               decimal("lat", { precision: 10, scale: 7 }),
  lon:               decimal("lon", { precision: 10, scale: 7 }),
  priority:          mysqlEnum("priority", ["low","normal","high","urgent"]).default("normal"),
  status:            mysqlEnum("status", ["pending","in_progress","completed","cancelled","blocked"]).default("pending"),
  scheduledStart:    datetime("scheduledStart"),
  estimatedDuration: int("estimatedDuration"),
  actualDuration:    int("actualDuration"),
  slaDeadline:       datetime("slaDeadline"),
  completedAt:       datetime("completedAt"),
  createdAt:         datetime("createdAt").notNull().default(new Date()),
}, (t) => ({
  idxAssigned:   index("idx_assigned").on(t.assignedTo),
  idxStatusDate: index("idx_status_date").on(t.status, t.scheduledStart),
}));

// ─────────────────────────────────────────────
// الإشعارات
// ─────────────────────────────────────────────

export const notifications = mysqlTable("notifications", {
  id:           int("id").primaryKey().autoincrement(),
  companyId:    int("companyId").notNull(),
  assignmentId: int("assignmentId"),
  type:         varchar("type", { length: 100 }).notNull(),
  title:        varchar("title", { length: 300 }).notNull(),
  body:         text("body"),
  priority:     mysqlEnum("priority", ["low","normal","high","urgent"]).default("normal"),
  isRead:       boolean("isRead").default(false),
  createdAt:    datetime("createdAt").notNull().default(new Date()),
}, (t) => ({
  idxAssignment: index("idx_assignment").on(t.assignmentId, t.isRead),
}));

// ─────────────────────────────────────────────
// Relations
// ─────────────────────────────────────────────

export const companiesRelations = relations(companies, ({ many }) => ({
  branches:    many(branches),
  assignments: many(employeeAssignments),
  clients:     many(clients),
}));

export const employeesRelations = relations(employees, ({ many }) => ({
  assignments: many(employeeAssignments),
}));

export const assignmentsRelations = relations(employeeAssignments, ({ one }) => ({
  employee: one(employees, { fields: [employeeAssignments.employeeId], references: [employees.id] }),
  company:  one(companies,  { fields: [employeeAssignments.companyId],  references: [companies.id]  }),
  branch:   one(branches,   { fields: [employeeAssignments.branchId],   references: [branches.id]   }),
}));

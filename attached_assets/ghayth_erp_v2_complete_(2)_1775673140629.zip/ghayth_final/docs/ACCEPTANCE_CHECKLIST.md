# ACCEPTANCE_CHECKLIST.md — قائمة قبول غيث ERP

## Pass / Fail — يراجع بها أي ZIP

| # | البند | الحالة |
|---|-------|--------|
| 1 | package.json موجود | ✅ |
| 2 | tsconfig.json موجود | ✅ |
| 3 | .env.example موجود | ✅ |
| 4 | README.md موجود ومكتمل | ✅ |
| 5 | src/core/db.ts — اتصال حقيقي بـ MySQL | ✅ |
| 6 | src/core/schema.ts — Drizzle ORM | ✅ |
| 7 | src/core/trpc.ts — scopedProcedure | ✅ |
| 8 | src/core/context.ts — RequestScope | ✅ |
| 9 | src/core/auth.ts — JWT + bcrypt | ✅ |
| 10 | src/core/permissions.ts — صلاحيات الأدوار | ✅ |
| 11 | src/core/authorization.ts — فلترة البيانات | ✅ |
| 12 | src/core/eventBus.ts — نظام الأحداث | ✅ |
| 13 | src/core/eventBus.ts — settingsEngine | ✅ |
| 14 | src/core/eventBus.ts — auditLogger | ✅ |
| 15 | User منفصل عن Employee | ✅ |
| 16 | Assignment منفصل عن Person | ✅ |
| 17 | Scope مرتبط بالتعيين والشركة والفرع | ✅ |
| 18 | Phase 1: auth + assignments + clients + settings + commandCenter | ✅ |
| 19 | Phase 2: HR — 11+17+18+12 خطوة | ✅ |
| 20 | Phase 3: Finance — فاتورة+تحصيل+ميزانية | ✅ |
| 21 | Phase 4: fleet+warehouse+properties+legal+projects+support+CRM | ✅ |
| 22 | Phase 5: intelligence+automation+communications+AI | ✅ |
| 23 | database/schema/*.sql — جداول مكتملة | ✅ |
| 24 | database/seeds/seed.ts — بيانات تجريبية | ✅ |
| 25 | src/routers/appRouter.ts — يجمع الكل | ✅ |
| 26 | src/server.ts — نقطة الدخول | ✅ |
| 27 | src/cron/scheduler.ts — 26 Cron | ✅ |
| 28 | لا imports مكسورة | ✅ |
| 29 | README يشرح التثبيت والتشغيل | ✅ |
| 30 | CHANGELOG + EVENT_CATALOG + ARCHITECTURE | ✅ |

**النتيجة: 30/30 — الحزمة كاملة ✅**

---

## اختبارات القبول اليدوية

### اختبار 1: تسجيل الدخول
```
POST /api/trpc/auth.login
{ "email": "ahmed@aldoor.sa", "password": "Admin@1234" }
المتوقع: token + قائمة التعيينات
```

### اختبار 2: تعدد التعيينات
```
GET /api/trpc/assignments.getMyAssignments
المتوقع: كل تعيينات الموظف في كل الشركات
```

### اختبار 3: Scope
```
GET /api/trpc/clients.list
المتوقع: عملاء الشركة فقط — لا عملاء شركة أخرى
```

### اختبار 4: Authorization
```
POST /api/trpc/settings.set (بمستخدم role=employee)
المتوقع: خطأ "غير مصرح: تحتاج صلاحية settings:write"
```

### اختبار 5: Audit
```
POST /api/trpc/clients.create
المتوقع: سجل في audit_logs مع before/after/userId
```

### اختبار 6: Settings Override
```
getSetting("hr.lateLimitMinutes", branchId=1, companyId=1)
المتوقع: قيمة الفرع إذا موجودة، وإلا الشركة، وإلا النظام
```

### اختبار 7: إضافة موظف — 11 خطوة
```
POST /api/trpc/hr.createEmployee
المتوقع: موظف + رقم + تعيين + أرصدة إجازات + وردية + مهام onboarding + إشعارات
```

### اختبار 8: بلاغ صيانة — 12 خطوة
```
POST /api/trpc/properties.submitMaintenanceRequest
{ "description": "تسرب مياه بغزارة" }
المتوقع: أولوية=high + SLA=4ساعات + أفضل فني + إشعارات + SMS
```

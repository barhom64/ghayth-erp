# EVENT_CATALOG.md — كتالوج الأحداث

## الأحداث المطلقة وعدد أفعالها

| الحدث | المصدر | الأفعال | المرجع |
|-------|--------|---------|--------|
| EMPLOYEE_CREATED | hr.createEmployee | 11 فعل: رقم+أرصدة+وردية+مهام+إشعارات+إيميل+SIP | ملف 02 |
| CHECK_IN | hr.checkIn | 17 فعل: تأخر+مخالفة+جزاء+خصم+إشعارات | ملف 02 |
| LEAVE_REQUESTED | hr.requestLeave | 8 أفعال: تأثير على كل التعيينات+توزيع مهام | ملف 02 |
| INVOICE_CREATED | finance.createInvoice | 7 أفعال: قيد+رصيد عميل+ميزانية+مهمة تحصيل | ملف 03 |
| MAINTENANCE_REQUESTED | properties.submitRequest | 12 فعل: أولوية+SLA+مسافة+فني+مهمة+إشعارات | ملف 05 |
| TASK_COMPLETED | tasks.complete | 5 أفعال: KPI+معدل+تقييم+قيد | ملف 07 |
| CLIENT_CREATED | clients.create | 8 أفعال: ملف+تعيين موظف+مرحبا واتساب | ملف 01 |
| FLEET_TRIP_CREATED | fleet.createTrip | حجز مركبة+سائق+مهمة+إشعارات | ملف 04 |
| FLEET_TRIP_COMPLETED | fleet.completeTrip | تكاليف+KPI+قيد محاسبي | ملف 04 |
| PROJECT_PHASE_COMPLETED | projects.completePhase | فاتورة تلقائية للعميل | ملف 06 |
| CRM_OPPORTUNITY_WON | crm.advanceOpportunity | عقد+فاتورة مقدمة | ملف 06 |
| STOCK_LOW | warehouse.issueStock | طلب شراء تلقائي | ملف 05 |
| RENT_PAID | properties.recordPayment | تحديث ملف العميل | ملف 05 |

---

# ARCHITECTURE.md — المعمارية

## المبادئ الأساسية

**1. الموظف شخص + تعيينات:**
- `employees` = الشخص (اسم، هاتف، هوية)
- `employee_assignments` = التعيين (شركة، فرع، دور، راتب)
- كل جدول تشغيلي يحمل `assignmentId` وليس `employeeId`

**2. الـ Scope:**
```typescript
{ userId, employeeId, companyId, branchId,
  activeAssignmentId, allowedCompanies[], allowedAssignments[], role }
```

**3. الـ Settings (3 مستويات):**
فرع → شركة → نظام. الأقرب يفوز.

**4. الـ Audit:**
كل write operation تسجل: من + متى + ماذا تغير.

**5. Event System:**
كل حفظ يطلق حدث → المستمعون يتصرفون تلقائياً.

## هيكل المجلدات
```
src/
  core/          ← البنية التحتية (db, trpc, auth, permissions...)
  modules/
    phase1/      ← auth + clients + settings + commandCenter
    hr/          ← الموارد البشرية
    finance/     ← المالية
    phase4/      ← عمليات (أسطول + مستودعات + أملاك + قانونية + مشاريع + دعم + CRM)
    phase5/      ← ذكاء + أتمتة + تواصل
  routers/       ← appRouter.ts
  cron/          ← scheduler.ts
database/
  schema/        ← ملفات SQL
  seeds/         ← seed.ts
docs/            ← توثيق
```

---

# CHANGELOG.md

## v1.0.0 — 2026-04

### المرحلة 1: البنية الأساسية ✅
- تعدد التعيينات (شخص + عدة أدوار)
- نظام الأحداث eventBus
- إعدادات 3 مستويات
- 16 عملية seed عند إنشاء شركة
- Scope + Authorization + Audit

### المرحلة 2: الموارد البشرية ✅
- إضافة موظف 11 خطوة تلقائية
- تسجيل حضور 17 خطوة (GPS + مخالفة + خصم)
- إجازة 18 خطوة و3 مسارات (موافقة/رفض/تصعيد)
- رواتب 12 بند مع تعدد التعيينات

### المرحلة 3: المالية ✅
- فاتورة 7 خطوات + قيد تلقائي
- تحصيل 6 مراحل تصاعدية
- ميزانية 4 مستويات (عادي/تحذير/حظر/رفض)
- دورة شراء P2P 8 خطوات

### المرحلة 4: العمليات ✅
- الأسطول: رحلة 10 خطوات + صيانة 8 خطوات + 7 تنبيهات
- المستودعات: حد أدنى 7 خطوات + FIFO
- الأملاك: بلاغ صيانة 12 خطوة + إيجار متأخر 6 مراحل
- القانونية: عقود + قضايا + جلسات
- المشاريع: 7 خطوات + Critical Path
- الدعم: تذكرة 8 خطوات + SLA
- CRM: فرصة 7 مراحل

### المرحلة 5: الذكاء والتواصل ✅
- 3 خوارزميات: Haversine + Moving Average + Load Balancing
- 8 KPIs لكل موظف
- 10 تنبيهات ذكية
- 26 وظيفة Cron
- NotificationService: 4 قنوات (in_app/email/SMS/WhatsApp)
- AI: 6 أدوار (استقبال/ردود/ترجمة/تلخيص/Rules/تنبؤ)
- PBX: مكالمات واردة 8 خطوات
